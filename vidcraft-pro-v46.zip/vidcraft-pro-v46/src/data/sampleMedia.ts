import { MediaAsset, LumetriGrade, TextConfig, Clip, Track, ProjectSettings } from '../types';

export const INITIAL_PROJECT: ProjectSettings = {
  name: 'Untitled Project',
  width: 1920,
  height: 1080,
  fps: 30,
  duration: 10,
  aspectRatio: '16:9'
};

export const INITIAL_TRACKS: Track[] = [
  { id: 'track-v3', name: 'V3 - Titles & Captions', type: 'video', index: 0, isMuted: false, isSolo: false, isLocked: false, isVisible: true, volume: 1, pan: 0, height: 44 },
  { id: 'track-v2', name: 'V2 - B-Roll & Overlay', type: 'video', index: 1, isMuted: false, isSolo: false, isLocked: false, isVisible: true, volume: 1, pan: 0, height: 52 },
  { id: 'track-v1', name: 'V1 - Main Footage', type: 'video', index: 2, isMuted: false, isSolo: false, isLocked: false, isVisible: true, volume: 1, pan: 0, height: 56 },
  { id: 'track-a1', name: 'A1 - Dialogue & VO', type: 'audio', index: 3, isMuted: false, isSolo: false, isLocked: false, isVisible: true, volume: 1, pan: 0, height: 48 },
  { id: 'track-a2', name: 'A2 - Sound Effects', type: 'audio', index: 4, isMuted: false, isSolo: false, isLocked: false, isVisible: true, volume: 0.85, pan: 0, height: 42 },
  { id: 'track-a3', name: 'A3 - Music Soundtrack', type: 'audio', index: 5, isMuted: false, isSolo: false, isLocked: false, isVisible: true, volume: 0.7, pan: 0, height: 44 },
];

export const DEFAULT_LUMETRI: LumetriGrade = {
  temperature: 0,
  tint: 0,
  exposure: 0,
  contrast: 0,
  highlights: 0,
  shadows: 0,
  whites: 0,
  blacks: 0,
  saturation: 100,
  vibrance: 0,
  vignette: 0,
  liftColor: '#000000',
  gammaColor: '#808080',
  gainColor: '#ffffff',
  presetName: 'Standard Rec.709'
};

export const LUT_PRESETS: { name: string; description: string; lumetri: Partial<LumetriGrade> }[] = [
  {
    name: 'Rec.709 Standard',
    description: 'Clean, neutral broadcast standard color space',
    lumetri: { ...DEFAULT_LUMETRI, presetName: 'Rec.709 Standard' }
  },
  {
    name: 'Hollywood Teal & Orange',
    description: 'Blockbuster movie contrast with warm skin tones and teal shadows',
    lumetri: {
      temperature: 12,
      tint: -8,
      exposure: 0.15,
      contrast: 22,
      highlights: -15,
      shadows: 18,
      whites: 10,
      blacks: -12,
      saturation: 115,
      vibrance: 25,
      vignette: -20,
      liftColor: '#072438',
      gammaColor: '#6e7a85',
      gainColor: '#ffbf69',
      presetName: 'Hollywood Teal & Orange'
    }
  },
  {
    name: 'Blade Runner Cyberpunk',
    description: 'Neon magenta highlights, cool blue-green shadows with high contrast',
    lumetri: {
      temperature: -24,
      tint: 32,
      exposure: 0.1,
      contrast: 35,
      highlights: 25,
      shadows: -15,
      whites: 20,
      blacks: -25,
      saturation: 130,
      vibrance: 40,
      vignette: -35,
      liftColor: '#0f172a',
      gammaColor: '#701a75',
      gainColor: '#06b6d4',
      presetName: 'Blade Runner Cyberpunk'
    }
  },
  {
    name: 'Kodak 35mm Vintage Film',
    description: 'Warm, soft roll-off, lifted blacks and golden retro tones',
    lumetri: {
      temperature: 28,
      tint: 6,
      exposure: 0.05,
      contrast: -8,
      highlights: -20,
      shadows: 25,
      whites: -10,
      blacks: 15,
      saturation: 90,
      vibrance: -10,
      vignette: -25,
      liftColor: '#2b2318',
      gammaColor: '#8a7d65',
      gainColor: '#faedd0',
      presetName: 'Kodak 35mm Vintage Film'
    }
  },
  {
    name: 'Moody Fincher Noir',
    description: 'Desaturated, atmospheric greenish undertones and deep shadows',
    lumetri: {
      temperature: -14,
      tint: -18,
      exposure: -0.2,
      contrast: 28,
      highlights: -30,
      shadows: -18,
      whites: -15,
      blacks: -20,
      saturation: 65,
      vibrance: -25,
      vignette: -40,
      liftColor: '#06130d',
      gammaColor: '#4a5b52',
      gainColor: '#cbd5e1',
      presetName: 'Moody Fincher Noir'
    }
  },
  {
    name: 'Golden Hour Sunset',
    description: 'Rich amber sunlight, soft highlights and warm glow',
    lumetri: {
      temperature: 42,
      tint: 15,
      exposure: 0.25,
      contrast: 15,
      highlights: 10,
      shadows: 12,
      whites: 15,
      blacks: -5,
      saturation: 120,
      vibrance: 30,
      vignette: -15,
      liftColor: '#2a1205',
      gammaColor: '#965a2d',
      gainColor: '#fed7aa',
      presetName: 'Golden Hour Sunset'
    }
  }
];

// Offline-first: the default/starter project ships with NO remote sample
// media (no video/audio/image URLs pointing at any external host). The
// editor starts as a clean empty project -- every asset a user sees comes
// from their own local import. Bundling real sample footage would mean
// either fetching it from the network on first run (breaking offline
// startup) or shipping large binary files in the package, so an empty
// starter project was the safer choice.
export const SAMPLE_ASSETS: MediaAsset[] = [];

// Empty to match SAMPLE_ASSETS above -- a clip referencing a sample asset
// that no longer exists would render as a broken/blank clip on the
// timeline, so these are cleared together.
export const INITIAL_CLIPS: Clip[] = [];

export const TITLE_TEMPLATES: { name: string; category: string; textConfig: TextConfig }[] = [
  {
    name: 'Cinematic Minimal Headline',
    category: 'Titles',
    textConfig: {
      text: 'THE ARCHITECTS OF TOMORROW',
      fontSize: 46,
      fontFamily: 'Plus Jakarta Sans',
      color: '#ffffff',
      align: 'center',
      animation: 'zoom-in',
      shadowColor: 'rgba(0,0,0,0.8)',
      shadowBlur: 16
    }
  },
  {
    name: 'Viral TikTok / Reels Subtitle',
    category: 'Captions',
    textConfig: {
      text: 'WATCH WHAT HAPPENS NEXT ⚡',
      fontSize: 38,
      fontFamily: 'Plus Jakarta Sans',
      color: '#facc15',
      backgroundColor: 'rgba(15, 23, 42, 0.9)',
      align: 'center',
      animation: 'bounce',
      strokeColor: '#000000',
      strokeWidth: 2,
      highlightWord: 'HAPPENS',
      highlightColor: '#22c55e'
    }
  },
  {
    name: 'Broadcast Lower Third',
    category: 'Lower Thirds',
    textConfig: {
      text: 'ALEXANDER CROSS | LEAD DIRECTOR',
      fontSize: 26,
      fontFamily: 'Plus Jakarta Sans',
      color: '#38bdf8',
      backgroundColor: 'rgba(18, 18, 24, 0.85)',
      align: 'left',
      animation: 'slide-up',
      shadowColor: 'rgba(0,0,0,0.5)',
      shadowBlur: 8
    }
  },
  {
    name: 'Cyberpunk Glitch Hook',
    category: 'Dynamic',
    textConfig: {
      text: 'CRITICAL SYSTEM OVERRIDE',
      fontSize: 40,
      fontFamily: 'Fira Code',
      color: '#ec4899',
      backgroundColor: 'rgba(0, 0, 0, 0.75)',
      align: 'center',
      animation: 'glitch',
      strokeColor: '#06b6d4',
      strokeWidth: 1.5
    }
  }
];
