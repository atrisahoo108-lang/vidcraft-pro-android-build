import { Clip, MediaAsset, Track, LumetriGrade, ProjectSettings, VideoFilter, TransitionType, ClipMask } from '../types';
import { getKeyframedTransform, getInstantaneousSpeed, getSpeedAdjustedSourceOffset } from './keyframes';
import { isTouchPrimaryDevice } from './deviceTier';

interface Rect { dx: number; dy: number; dw: number; dh: number; }

interface TransitionEffect {
  opacity: number;
  scaleMod: number;
  offsetX: number;
  offsetY: number;
  extraBlurPx: number;
  flashColor: string | null;
  maskPath: Path2D | null;
}

const IDENTITY_EFFECT: TransitionEffect = {
  opacity: 1, scaleMod: 1, offsetX: 0, offsetY: 0, extraBlurPx: 0, flashColor: null, maskPath: null
};

export class VideoCompositor {
  private videoElements: Map<string, HTMLVideoElement> = new Map();
  private imageElements: Map<string, HTMLImageElement> = new Map();

  // Reusable off-DOM "layer" canvas: every clip is first painted here (in
  // plain 0..width / 0..height space, filters + pixel FX applied), then
  // composited onto the real canvas with the clip's transform/blend/mask.
  // Reusing one canvas avoids a per-clip, per-frame allocation.
  private layerCanvas: HTMLCanvasElement = document.createElement('canvas');
  private layerCtx: CanvasRenderingContext2D = this.layerCanvas.getContext('2d')!;

  public getVideoElement(assetId: string, src: string): HTMLVideoElement {
    let video = this.videoElements.get(assetId);
    if (!video) {
      video = document.createElement('video');
      video.crossOrigin = 'anonymous';
      video.preload = 'auto';
      video.muted = true;
      video.playsInline = true;
      video.setAttribute('playsinline', '');
      video.setAttribute('webkit-playsinline', '');
      video.disablePictureInPicture = true;
      // v46: on Android WebView/Chrome a <video> that is never attached to
      // the document often decodes no frames (blank/black drawImage, or it
      // never loads past metadata). Park it in a 1px, invisible, non-
      // interactive host instead. Desktop browsers don't need this, so it
      // is limited to touch-primary devices.
      if (isTouchPrimaryDevice()) {
        this.getVideoHost().appendChild(video);
        // Force the first frame to decode so a paused scrub isn't blank.
        video.addEventListener('loadedmetadata', () => {
          if (video && video.paused && video.currentTime === 0) {
            try { video.currentTime = 0.01; } catch { /* ignore */ }
          }
        }, { once: true });
      }
      video.src = src;
      this.videoElements.set(assetId, video);
    }
    return video;
  }

  private videoHost: HTMLDivElement | null = null;
  private getVideoHost(): HTMLDivElement {
    if (!this.videoHost) {
      const host = document.createElement('div');
      host.setAttribute('aria-hidden', 'true');
      host.style.cssText =
        'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0.01;overflow:hidden;pointer-events:none;z-index:-1;';
      document.body.appendChild(host);
      this.videoHost = host;
    }
    return this.videoHost;
  }

  /** Resolves true once the asset's video has a decodable frame (or false on timeout). */
  public ensureVideoReady(assetId: string, src: string, timeoutMs: number = 8000): Promise<boolean> {
    const video = this.getVideoElement(assetId, src);
    if (video.readyState >= 2) return Promise.resolve(true);
    return new Promise(resolve => {
      let finished = false;
      const finish = (ok: boolean) => {
        if (finished) return;
        finished = true;
        window.clearTimeout(timer);
        video.removeEventListener('loadeddata', onReady);
        video.removeEventListener('canplay', onReady);
        resolve(ok);
      };
      const onReady = () => { if (video.readyState >= 2) finish(true); };
      video.addEventListener('loadeddata', onReady);
      video.addEventListener('canplay', onReady);
      const timer = window.setTimeout(() => finish(video.readyState >= 2), timeoutMs);
    });
  }

  /** Waits (bounded) until no cached video is mid-seek. */
  public async waitForVideosIdle(timeoutMs: number = 3000): Promise<void> {
    const deadline = performance.now() + timeoutMs;
    while (performance.now() < deadline) {
      let busy = false;
      this.videoElements.forEach(v => { if (v.seeking) busy = true; });
      if (!busy) return;
      await new Promise(r => setTimeout(r, 40));
    }
  }

  public getImageElement(assetId: string, src: string): HTMLImageElement {
    let img = this.imageElements.get(assetId);
    if (!img) {
      img = new Image();
      img.src = src;
      img.crossOrigin = 'anonymous';
      this.imageElements.set(assetId, img);
    }
    return img;
  }

  /** Frees the cached <video>/<img> elements for an asset that's no longer in the project. */
  public disposeAsset(assetId: string) {
    const video = this.videoElements.get(assetId);
    if (video) {
      video.pause();
      video.removeAttribute('src');
      video.load();
      video.remove();
      this.videoElements.delete(assetId);
    }
    const img = this.imageElements.get(assetId);
    if (img) {
      img.removeAttribute('src');
      this.imageElements.delete(assetId);
    }
  }

  /** Drops caches for assets not present in `keepAssetIds` — call periodically to prevent memory growth on long sessions. */
  public pruneUnusedAssets(keepAssetIds: Set<string>) {
    for (const id of Array.from(this.videoElements.keys())) {
      if (!keepAssetIds.has(id)) this.disposeAsset(id);
    }
    for (const id of Array.from(this.imageElements.keys())) {
      if (!keepAssetIds.has(id)) this.disposeAsset(id);
    }
  }

  public syncVideoPlayback(
    clip: Clip,
    asset: MediaAsset,
    currentTime: number,
    isPlaying: boolean
  ) {
    if (clip.type !== 'video' || !asset.src) return;

    const video = this.getVideoElement(asset.id, asset.src);
    const clipStart = clip.startTime;
    const clipEnd = clip.startTime + clip.duration;
    const isInside = currentTime >= clipStart && currentTime < clipEnd;

    if (isInside) {
      if (clip.freezeFrame) {
        // Hold on a single source frame for the clip's entire duration.
        if (Math.abs(video.currentTime - clip.inPoint) > 0.05) {
          video.currentTime = clip.inPoint;
        }
        if (!video.paused) video.pause();
        return;
      }

      const timeFromStart = currentTime - clipStart;
      const speed = getInstantaneousSpeed(clip, timeFromStart);
      const maxOffset = Math.max(0, clip.sourceDuration - 0.05);
      const targetOffset = Math.max(0, Math.min(maxOffset, clip.inPoint + getSpeedAdjustedSourceOffset(clip, timeFromStart)));

      // v46: on touch devices a seek can take several hundred ms; issuing a
      // new one every frame while the previous is unfinished keeps the
      // video permanently stalled. Skip while seeking, allow more drift
      // during playback, and be tighter when paused so scrubbing shows
      // the right frame. Desktop keeps the original 0.2s behavior.
      const touch = isTouchPrimaryDevice();
      const drift = touch ? (isPlaying ? 0.45 : 0.04) : 0.2;
      if (!(touch && video.seeking) && Math.abs(video.currentTime - targetOffset) > drift) {
        video.currentTime = targetOffset;
      }
      // Clamp to a sane range — extreme rates can stutter or throw in some browsers.
      video.playbackRate = Math.max(0.1, Math.min(4, speed));

      if (isPlaying && video.paused) {
        video.play().catch(() => {});
      } else if (!isPlaying && !video.paused) {
        video.pause();
      }
    } else {
      if (!video.paused) {
        video.pause();
      }
    }
  }

  public renderFrame(
    ctx: CanvasRenderingContext2D,
    canvasWidth: number,
    canvasHeight: number,
    currentTime: number,
    clips: Clip[],
    tracks: Track[],
    assets: MediaAsset[],
    project: ProjectSettings,
    selectedClipId?: string | null,
    showSafeMargins: boolean = false
  ) {
    // Clear Canvas
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    if (this.layerCanvas.width !== canvasWidth || this.layerCanvas.height !== canvasHeight) {
      this.layerCanvas.width = canvasWidth;
      this.layerCanvas.height = canvasHeight;
    }
    this.layerCtx.imageSmoothingEnabled = true;
    this.layerCtx.imageSmoothingQuality = 'high';

    // Sort tracks by index descending (bottom tracks first, top tracks render on top)
    const sortedTracks = [...tracks].sort((a, b) => b.index - a.index);

    for (const track of sortedTracks) {
      if (track.type !== 'video' || !track.isVisible) continue;

      // Find clips on this track active at currentTime
      const activeClips = clips.filter(
        c => c.trackId === track.id &&
             currentTime >= c.startTime &&
             currentTime < (c.startTime + c.duration)
      );

      for (const clip of activeClips) {
        const asset = assets.find(a => a.id === clip.assetId);
        this.renderClip(ctx, canvasWidth, canvasHeight, currentTime, clip, asset, selectedClipId === clip.id);
      }
    }

    // Render Safe Margins if enabled (Title Safe 80%, Action Safe 90%)
    if (showSafeMargins) {
      this.drawSafeMargins(ctx, canvasWidth, canvasHeight);
    }
  }

  private renderClip(
    ctx: CanvasRenderingContext2D,
    canvasWidth: number,
    canvasHeight: number,
    currentTime: number,
    clip: Clip,
    asset?: MediaAsset,
    isSelected: boolean = false
  ) {
    const timeFromStart = currentTime - clip.startTime;
    const timeToEnd = (clip.startTime + clip.duration) - currentTime;

    // Keyframed transform (falls back to the clip's static values when no
    // keyframes exist for a given property).
    const kf = getKeyframedTransform(clip, timeFromStart);

    // ---- Transitions: opacity / scale / slide-offset / masks / blur / flash ----
    let effect: TransitionEffect = { ...IDENTITY_EFFECT };

    if (clip.transitionIn && clip.transitionIn.type !== 'none' && timeFromStart < clip.transitionIn.duration) {
      const r = Math.min(1, Math.max(0, timeFromStart / clip.transitionIn.duration));
      effect = combineTransitionEffects(effect, computeTransitionEffect(clip.transitionIn.type, r, canvasWidth, canvasHeight));
    }

    if (clip.transitionOut && clip.transitionOut.type !== 'none' && timeToEnd < clip.transitionOut.duration) {
      const r = Math.min(1, Math.max(0, timeToEnd / clip.transitionOut.duration));
      effect = combineTransitionEffects(effect, computeTransitionEffect(clip.transitionOut.type, r, canvasWidth, canvasHeight));
    }

    // ---- Paint the clip's own content into the reusable layer canvas ----
    // Painting happens in plain 0..w / 0..h space so filters, pixel FX, and
    // cover-fit sizing are unaffected by the clip's position/rotation/scale.
    const layer = this.layerCanvas;
    const layerCtx = this.layerCtx;
    layerCtx.save();
    layerCtx.clearRect(0, 0, canvasWidth, canvasHeight);
    layerCtx.filter = buildFilterString(clip.lumetri, clip.filters, effect.extraBlurPx);

    if (clip.type === 'video' && asset && asset.src) {
      const video = this.getVideoElement(asset.id, asset.src);
      if (video.readyState >= 2) {
        const rect = coverRect(video.videoWidth || canvasWidth, video.videoHeight || canvasHeight, canvasWidth, canvasHeight);
        layerCtx.drawImage(video, rect.dx, rect.dy, rect.dw, rect.dh);
      } else {
        layerCtx.filter = 'none';
        layerCtx.fillStyle = '#1e1e24';
        layerCtx.fillRect(0, 0, canvasWidth, canvasHeight);
        layerCtx.fillStyle = '#71717a';
        layerCtx.font = '16px Plus Jakarta Sans, sans-serif';
        layerCtx.textAlign = 'center';
        layerCtx.fillText(`Loading ${clip.name}...`, canvasWidth / 2, canvasHeight / 2);
      }
    } else if (clip.type === 'image' && asset && asset.src) {
      const img = this.getImageElement(asset.id, asset.src);
      if (img.complete && img.naturalWidth > 0) {
        const rect = coverRect(img.naturalWidth, img.naturalHeight, canvasWidth, canvasHeight);
        layerCtx.drawImage(img, rect.dx, rect.dy, rect.dw, rect.dh);
      }
    } else if (clip.type === 'text' && clip.textConfig) {
      layerCtx.translate(canvasWidth / 2, canvasHeight / 2);
      this.renderTextClip(layerCtx, clip.textConfig, timeFromStart, clip.duration, timeToEnd);
      layerCtx.setTransform(1, 0, 0, 1, 0, 0);
    }

    // Vignette / lift-gain tint live in the layer's own (unrotated, unscaled)
    // space so they read as a consistent frame effect regardless of the
    // clip's position/rotation/scale — previously these warped with the clip transform.
    layerCtx.filter = 'none';
    this.renderVignetteAndTint(layerCtx, canvasWidth, canvasHeight, clip.lumetri);

    // Pixel-level filters that CSS `filter` can't express.
    applyPostPixelEffects(layerCtx, canvasWidth, canvasHeight, clip.filters, timeFromStart);

    // Shape mask: either crops the clip to a region, or selectively blurs
    // just that region (privacy blur / tilt-shift / spotlight-style looks).
    applyClipMask(layerCtx, canvasWidth, canvasHeight, clip.mask);

    layerCtx.restore();

    // ---- Composite the finished layer onto the real canvas with transform/blend ----
    ctx.save();
    ctx.globalCompositeOperation = (clip.blendMode as GlobalCompositeOperation) || 'source-over';
    ctx.globalAlpha = Math.max(0, Math.min(1, (kf.opacity / 100) * effect.opacity));

    const centerX = canvasWidth / 2 + kf.positionX + effect.offsetX;
    const centerY = canvasHeight / 2 + kf.positionY + effect.offsetY;

    ctx.translate(centerX, centerY);
    ctx.rotate((kf.rotation * Math.PI) / 180);
    const finalScale = (kf.scale / 100) * effect.scaleMod;
    ctx.scale(finalScale, finalScale);

    if (effect.flashColor) {
      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, (1 - effect.opacity) * (kf.opacity / 100)));
      ctx.fillStyle = effect.flashColor;
      ctx.fillRect(-canvasWidth / 2, -canvasHeight / 2, canvasWidth, canvasHeight);
      ctx.restore();
    }

    if (effect.maskPath) {
      ctx.clip(effect.maskPath);
    }

    ctx.drawImage(layer, -canvasWidth / 2, -canvasHeight / 2, canvasWidth, canvasHeight);

    if (isSelected) {
      this.drawSelectionGizmo(ctx, canvasWidth, canvasHeight, clip);
    }

    ctx.restore();
  }

  private renderVignetteAndTint(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    lumetri?: LumetriGrade
  ) {
    if (!lumetri) return;

    // Vignette (drawn in layer space: 0,0 top-left .. width,height bottom-right)
    if (lumetri.vignette && lumetri.vignette !== 0) {
      const radius = Math.max(width, height) * 0.7;
      const cx = width / 2;
      const cy = height / 2;
      const vignetteGrad = ctx.createRadialGradient(cx, cy, radius * 0.4, cx, cy, radius);
      const intensity = Math.min(1, Math.abs(lumetri.vignette) / 100);

      if (lumetri.vignette < 0) {
        vignetteGrad.addColorStop(0, 'rgba(0,0,0,0)');
        vignetteGrad.addColorStop(1, `rgba(0,0,0,${intensity * 0.75})`);
      } else {
        vignetteGrad.addColorStop(0, 'rgba(255,255,255,0)');
        vignetteGrad.addColorStop(1, `rgba(255,255,255,${intensity * 0.5})`);
      }
      ctx.fillStyle = vignetteGrad;
      ctx.fillRect(0, 0, width, height);
    }

    // Color Tint / Lift / Gain overlay
    if (lumetri.gainColor && lumetri.gainColor !== '#ffffff' && lumetri.gainColor !== '#fff') {
      ctx.save();
      ctx.globalCompositeOperation = 'soft-light';
      ctx.fillStyle = lumetri.gainColor;
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
    }
  }

  private renderTextClip(
    ctx: CanvasRenderingContext2D,
    textConfig: NonNullable<Clip['textConfig']>,
    timeFromStart: number,
    clipDuration: number,
    timeToEnd: number
  ) {
    const {
      text,
      fontSize = 40,
      fontFamily = 'Plus Jakarta Sans',
      color = '#ffffff',
      backgroundColor,
      strokeColor,
      strokeWidth = 0,
      align = 'center',
      animation = 'none',
      shadowColor = 'rgba(0,0,0,0.8)',
      shadowBlur = 8,
      highlightWord,
      highlightColor = '#38bdf8',
      captionWords
    } = textConfig;

    ctx.font = `700 ${fontSize}px ${fontFamily}, sans-serif`;
    ctx.textAlign = align;
    ctx.textBaseline = 'middle';

    let displayText = text;
    let animScale = 1;
    let animOffsetX = 0;
    let animOffsetY = 0;
    let animAlpha = 1;

    // Every kinetic preset animates IN over its own window near the clip's
    // start, and mirrors the same motion OUT over a window near the clip's
    // end — titles/captions should leave the frame as deliberately as they
    // enter it, not just hard-cut away.
    const ANIM_WINDOW = Math.min(0.6, clipDuration / 3);
    const inProg = ANIM_WINDOW > 0 ? Math.min(1, Math.max(0, timeFromStart / ANIM_WINDOW)) : 1;
    const outProg = ANIM_WINDOW > 0 ? Math.min(1, Math.max(0, timeToEnd / ANIM_WINDOW)) : 1;
    // 0 at the very start/end, 1 once fully settled in the middle.
    const settleProg = Math.min(inProg, outProg);

    if (animation === 'typewriter') {
      const charsToShow = Math.min(text.length, Math.floor((timeFromStart / 1.5) * text.length));
      displayText = text.substring(0, charsToShow);
    } else if (animation === 'bounce') {
      const bounceProg = 1 - settleProg;
      animScale = 1 + Math.sin(Math.min(1, bounceProg) * Math.PI) * 0.25 * bounceProg;
    } else if (animation === 'fade') {
      animAlpha = settleProg;
    } else if (animation === 'slide-up') {
      animOffsetY = (1 - settleProg) * 30 * (inProg < outProg ? 1 : -1);
      animAlpha = settleProg;
    } else if (animation === 'slide-down') {
      animOffsetY = -(1 - settleProg) * 30 * (inProg < outProg ? 1 : -1);
      animAlpha = settleProg;
    } else if (animation === 'slide-left') {
      animOffsetX = (1 - settleProg) * 60 * (inProg < outProg ? 1 : -1);
      animAlpha = settleProg;
    } else if (animation === 'slide-right') {
      animOffsetX = -(1 - settleProg) * 60 * (inProg < outProg ? 1 : -1);
      animAlpha = settleProg;
    } else if (animation === 'zoom-in') {
      animScale = 0.8 + settleProg * 0.2;
      animAlpha = settleProg;
    } else if (animation === 'glitch') {
      if (Math.random() > 0.85) {
        animOffsetY = (Math.random() - 0.5) * 6;
      }
    }

    ctx.globalAlpha *= Math.max(0, Math.min(1, animAlpha));
    ctx.scale(animScale, animScale);
    ctx.translate(animOffsetX, animOffsetY);

    const metrics = ctx.measureText(displayText);
    const textWidth = metrics.width;
    const paddingX = 20;
    const paddingY = 12;

    // Background Pill
    if (backgroundColor && backgroundColor !== 'transparent') {
      ctx.fillStyle = backgroundColor;
      const boxX = align === 'center' ? -textWidth / 2 - paddingX : align === 'left' ? -paddingX : -textWidth - paddingX;
      const boxY = -fontSize / 2 - paddingY;
      const boxW = textWidth + paddingX * 2;
      const boxH = fontSize + paddingY * 2;
      ctx.beginPath();
      ctx.roundRect(boxX, boxY, boxW, boxH, 8);
      ctx.fill();
    }

    // Shadow
    if (shadowBlur > 0) {
      ctx.shadowColor = shadowColor;
      ctx.shadowBlur = shadowBlur;
      ctx.shadowOffsetX = 2;
      ctx.shadowOffsetY = 3;
    }

    // Stroke (whole string — strokes look fine repeated per-segment below too,
    // but doing it once for the full string avoids double-stroking overlaps)
    if (strokeColor && strokeWidth > 0) {
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = strokeWidth;
      ctx.strokeText(displayText, 0, 0);
    }

    if (captionWords && captionWords.length > 0) {
      // Karaoke-style animated captions: draw the sentence as a sequence of
      // word segments, each colored independently based on whether playback
      // is currently inside that word's [start, end] window.
      this.renderCaptionWords(ctx, captionWords, timeFromStart, fontSize, align, color, highlightColor);
    } else if (highlightWord && displayText.includes(highlightWord)) {
      // Highlight just the matched word, not the whole line — draw the text
      // in three segments (before / word / after) at their correct x offsets
      // instead of repainting the full string in the highlight color.
      this.renderTextWithHighlight(ctx, displayText, highlightWord, textWidth, align, color, highlightColor);
    } else {
      ctx.fillStyle = color;
      ctx.fillText(displayText, 0, 0);
    }

    ctx.shadowBlur = 0;
  }

  // Draws `fullText` in `baseColor`, except for the first occurrence of
  // `word`, which is drawn in `highlightColor` — a real substring highlight
  // rather than repainting the entire line on top of itself.
  private renderTextWithHighlight(
    ctx: CanvasRenderingContext2D,
    fullText: string,
    word: string,
    fullWidth: number,
    align: 'left' | 'center' | 'right',
    baseColor: string,
    highlightColor: string
  ) {
    const idx = fullText.indexOf(word);
    const before = fullText.substring(0, idx);
    const after = fullText.substring(idx + word.length);

    // measureText respects the current ctx.textAlign, so measure each part
    // as a left-aligned string to get pure segment widths.
    const prevAlign = ctx.textAlign;
    ctx.textAlign = 'left';
    const beforeWidth = ctx.measureText(before).width;
    const wordWidth = ctx.measureText(word).width;

    // Starting x so the whole line still lands where ctx.textAlign would
    // have put it (left edge of the full string).
    let startX: number;
    if (align === 'center') startX = -fullWidth / 2;
    else if (align === 'right') startX = -fullWidth;
    else startX = 0;

    ctx.fillStyle = baseColor;
    if (before) ctx.fillText(before, startX, 0);
    ctx.fillStyle = highlightColor;
    ctx.fillText(word, startX + beforeWidth, 0);
    ctx.fillStyle = baseColor;
    if (after) ctx.fillText(after, startX + beforeWidth + wordWidth, 0);

    ctx.textAlign = prevAlign;
  }

  private renderCaptionWords(
    ctx: CanvasRenderingContext2D,
    words: NonNullable<Clip['textConfig']>['captionWords'],
    timeFromStart: number,
    fontSize: number,
    align: 'left' | 'center' | 'right',
    baseColor: string,
    highlightColor: string
  ) {
    if (!words || words.length === 0) return;
    const prevAlign = ctx.textAlign;
    ctx.textAlign = 'left';

    const spaceWidth = ctx.measureText(' ').width;
    const segments = words.map(w => ({ w, width: ctx.measureText(w.text).width }));
    const totalWidth = segments.reduce((sum, s) => sum + s.width, 0) + spaceWidth * Math.max(0, segments.length - 1);

    let startX: number;
    if (align === 'center') startX = -totalWidth / 2;
    else if (align === 'right') startX = -totalWidth;
    else startX = 0;

    let x = startX;
    for (const seg of segments) {
      const isActive = timeFromStart >= seg.w.start && timeFromStart <= seg.w.end;
      const isPast = timeFromStart > seg.w.end;
      ctx.fillStyle = isActive ? highlightColor : (isPast ? baseColor : `${baseColor}99`);
      if (isActive) {
        // A small pop on the currently-spoken word — the classic karaoke feel.
        ctx.save();
        ctx.translate(x + seg.width / 2, 0);
        ctx.scale(1.08, 1.08);
        ctx.fillText(seg.w.text, -seg.width / 2, 0);
        ctx.restore();
      } else {
        ctx.fillText(seg.w.text, x, 0);
      }
      x += seg.width + spaceWidth;
    }

    ctx.textAlign = prevAlign;
  }

  private drawSelectionGizmo(
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    clip: Clip
  ) {
    const boxW = clip.type === 'text' ? (clip.textConfig?.fontSize || 40) * 10 : width;
    const boxH = clip.type === 'text' ? (clip.textConfig?.fontSize || 40) * 2.5 : height;

    ctx.save();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(-boxW / 2, -boxH / 2, boxW, boxH);

    ctx.setLineDash([]);
    ctx.fillStyle = '#ffffff';
    const handleSize = 8;
    const corners = [
      [-boxW / 2, -boxH / 2],
      [boxW / 2, -boxH / 2],
      [boxW / 2, boxH / 2],
      [-boxW / 2, boxH / 2],
    ];

    for (const [cx, cy] of corners) {
      ctx.fillRect(cx - handleSize / 2, cy - handleSize / 2, handleSize, handleSize);
      ctx.strokeRect(cx - handleSize / 2, cy - handleSize / 2, handleSize, handleSize);
    }
    ctx.restore();
  }

  private drawSafeMargins(ctx: CanvasRenderingContext2D, width: number, height: number) {
    ctx.save();
    ctx.lineWidth = 1;

    ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
    const actionW = width * 0.9;
    const actionH = height * 0.9;
    ctx.strokeRect((width - actionW) / 2, (height - actionH) / 2, actionW, actionH);

    ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
    const titleW = width * 0.8;
    const titleH = height * 0.8;
    ctx.strokeRect((width - titleW) / 2, (height - titleH) / 2, titleW, titleH);

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    const crossSize = 16;
    ctx.beginPath();
    ctx.moveTo(width / 2 - crossSize, height / 2);
    ctx.lineTo(width / 2 + crossSize, height / 2);
    ctx.moveTo(width / 2, height / 2 - crossSize);
    ctx.lineTo(width / 2, height / 2 + crossSize);
    ctx.stroke();

    ctx.restore();
  }
}

// ---------------------------------------------------------------------------
// Free helper functions (pure — no `this`, easy to unit test independently)
// ---------------------------------------------------------------------------

/** "object-fit: cover"-style rect: fills the destination, cropping overflow, preserving source aspect ratio. */
function coverRect(srcW: number, srcH: number, dstW: number, dstH: number): Rect {
  if (!srcW || !srcH) return { dx: 0, dy: 0, dw: dstW, dh: dstH };
  const srcRatio = srcW / srcH;
  const dstRatio = dstW / dstH;
  let dw: number, dh: number;
  if (srcRatio > dstRatio) {
    dh = dstH;
    dw = dstH * srcRatio;
  } else {
    dw = dstW;
    dh = dstW / srcRatio;
  }
  return { dx: (dstW - dw) / 2, dy: (dstH - dh) / 2, dw, dh };
}

function buildFilterString(lumetri: LumetriGrade | undefined, filters: VideoFilter[] | undefined, extraBlurPx: number): string {
  const parts: string[] = [];

  if (lumetri) {
    const contrastPct = Math.max(0, 100 + lumetri.contrast);
    const brightnessPct = Math.max(0, 100 + lumetri.exposure * 25);
    const saturationPct = Math.max(0, lumetri.saturation);
    const hueRotateDeg = lumetri.tint * 0.9;
    const tempSepia = Math.max(0, lumetri.temperature) * 0.4;
    parts.push(`contrast(${contrastPct}%)`, `brightness(${brightnessPct}%)`, `saturate(${saturationPct}%)`, `hue-rotate(${hueRotateDeg}deg)`, `sepia(${tempSepia}%)`);
  }

  for (const f of filters || []) {
    if (!f.enabled) continue;
    switch (f.type) {
      case 'blur':
        parts.push(`blur(${(f.value / 100) * 20}px)`);
        break;
      case 'brightness':
        parts.push(`brightness(${f.value}%)`);
        break;
      case 'contrast':
        parts.push(`contrast(${f.value}%)`);
        break;
      case 'hue-rotate':
        parts.push(`hue-rotate(${f.value}deg)`);
        break;
      case 'invert':
        parts.push(`invert(${f.value}%)`);
        break;
      case 'sepia':
        parts.push(`sepia(${f.value}%)`);
        break;
      case 'grayscale':
        parts.push(`grayscale(${f.value}%)`);
        break;
      // chromatic / glitch / scanlines / sharpen require pixel access —
      // handled separately in applyPostPixelEffects().
      default:
        break;
    }
  }

  if (extraBlurPx > 0.1) {
    parts.push(`blur(${extraBlurPx}px)`);
  }

  return parts.length ? parts.join(' ') : 'none';
}

/**
 * Applies a shape mask to the already-rendered layer canvas contents.
 * mode 'crop': only pixels inside the shape remain (rest becomes transparent).
 * mode 'blur': pixels inside the shape are blurred; everything else stays sharp.
 * `invert` flips "inside the shape" to mean "outside the shape" for both modes.
 */
function applyClipMask(ctx: CanvasRenderingContext2D, w: number, h: number, mask: ClipMask | undefined) {
  if (!mask || mask.shape === undefined) return;

  const cx = (mask.xPercent / 100) * w;
  const cy = (mask.yPercent / 100) * h;
  const shapeW = Math.max(1, (mask.widthPercent / 100) * w);
  const shapeH = Math.max(1, (mask.heightPercent / 100) * h);
  const feather = Math.max(0, mask.feather || 0);

  const maskCanvas = document.createElement('canvas');
  maskCanvas.width = w;
  maskCanvas.height = h;
  const maskCtx = maskCanvas.getContext('2d');
  if (!maskCtx) return;

  const drawShapePath = () => {
    maskCtx.beginPath();
    if (mask.shape === 'ellipse') {
      maskCtx.ellipse(cx, cy, shapeW / 2, shapeH / 2, 0, 0, Math.PI * 2);
    } else {
      maskCtx.rect(cx - shapeW / 2, cy - shapeH / 2, shapeW, shapeH);
    }
    maskCtx.closePath();
  };

  maskCtx.fillStyle = '#fff';
  if (mask.invert) {
    // Solid everywhere, then punch a (feathered) hole where the shape is —
    // leaves the mask affecting everything OUTSIDE the shape.
    maskCtx.filter = 'none';
    maskCtx.fillRect(0, 0, w, h);
    maskCtx.filter = feather > 0 ? `blur(${feather}px)` : 'none';
    maskCtx.globalCompositeOperation = 'destination-out';
    drawShapePath();
    maskCtx.fill();
    maskCtx.globalCompositeOperation = 'source-over';
  } else {
    maskCtx.filter = feather > 0 ? `blur(${feather}px)` : 'none';
    drawShapePath();
    maskCtx.fill();
  }

  if (mask.mode === 'crop') {
    ctx.globalCompositeOperation = 'destination-in';
    ctx.drawImage(maskCanvas, 0, 0);
    ctx.globalCompositeOperation = 'source-over';
    return;
  }

  // mode === 'blur': render a fully-blurred copy of the current layer, mask
  // it down to just the shape region, then composite that on top of the
  // still-sharp original — so only the masked area ends up blurred.
  const blurAmount = Math.max(0, mask.blurAmount || 0);
  if (blurAmount <= 0) return;

  const blurCanvas = document.createElement('canvas');
  blurCanvas.width = w;
  blurCanvas.height = h;
  const blurCtx = blurCanvas.getContext('2d');
  if (!blurCtx) return;

  blurCtx.filter = `blur(${blurAmount}px)`;
  blurCtx.drawImage(ctx.canvas, 0, 0);
  blurCtx.filter = 'none';
  blurCtx.globalCompositeOperation = 'destination-in';
  blurCtx.drawImage(maskCanvas, 0, 0);
  blurCtx.globalCompositeOperation = 'source-over';

  ctx.drawImage(blurCanvas, 0, 0);
}

function applyPostPixelEffects(ctx: CanvasRenderingContext2D, w: number, h: number, filters: VideoFilter[] | undefined, timeSec: number) {
  if (!filters || filters.length === 0) return;
  for (const f of filters) {
    if (!f.enabled) continue;
    switch (f.type) {
      case 'chromatic':
        applyChromaticAberration(ctx, w, h, f.value);
        break;
      case 'scanlines':
        applyScanlines(ctx, w, h, f.value);
        break;
      case 'sharpen':
        applySharpen(ctx, w, h, f.value);
        break;
      case 'glitch':
        applyGlitchSlices(ctx, w, h, f.value);
        break;
      default:
        break;
    }
  }
}

/** RGB channel split — samples R/B from horizontally offset positions of the same frame. */
function applyChromaticAberration(ctx: CanvasRenderingContext2D, w: number, h: number, value: number) {
  const shift = Math.round((Math.max(0, Math.min(100, value)) / 100) * 12);
  if (shift <= 0) return;
  const imgData = ctx.getImageData(0, 0, w, h);
  const src = imgData.data;
  const out = new Uint8ClampedArray(src.length);
  for (let y = 0; y < h; y++) {
    const rowStart = y * w;
    for (let x = 0; x < w; x++) {
      const idx = (rowStart + x) * 4;
      const rx = Math.min(w - 1, x + shift);
      const bx = Math.max(0, x - shift);
      const rIdx = (rowStart + rx) * 4;
      const bIdx = (rowStart + bx) * 4;
      out[idx] = src[rIdx];
      out[idx + 1] = src[idx + 1];
      out[idx + 2] = src[bIdx + 2];
      out[idx + 3] = src[idx + 3];
    }
  }
  ctx.putImageData(new ImageData(out, w, h), 0, 0);
}

/** Cheap CRT-style scanlines — no pixel loop, just thin translucent rects. */
function applyScanlines(ctx: CanvasRenderingContext2D, w: number, h: number, value: number) {
  const alpha = (Math.max(0, Math.min(100, value)) / 100) * 0.5;
  if (alpha <= 0) return;
  ctx.save();
  ctx.fillStyle = `rgba(0,0,0,${alpha})`;
  for (let y = 0; y < h; y += 3) {
    ctx.fillRect(0, y, w, 1);
  }
  ctx.restore();
}

/** 3x3 unsharp-style convolution kernel, blended in by `value` (0-100). */
function applySharpen(ctx: CanvasRenderingContext2D, w: number, h: number, value: number) {
  const amount = Math.max(0, Math.min(100, value)) / 100;
  if (amount <= 0) return;
  const src = ctx.getImageData(0, 0, w, h);
  const s = src.data;
  const out = new Uint8ClampedArray(s.length);
  const center = 1 + 4 * amount;
  const edge = -amount;
  const stride = w * 4;

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const idx = (y * w + x) * 4;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1) {
        out[idx] = s[idx]; out[idx + 1] = s[idx + 1]; out[idx + 2] = s[idx + 2]; out[idx + 3] = s[idx + 3];
        continue;
      }
      for (let c = 0; c < 3; c++) {
        const cIdx = idx + c;
        const v = s[cIdx] * center + edge * (s[cIdx - stride] + s[cIdx + stride] + s[cIdx - 4] + s[cIdx + 4]);
        out[cIdx] = v;
      }
      out[idx + 3] = s[idx + 3];
    }
  }
  ctx.putImageData(new ImageData(out, w, h), 0, 0);
}

/** Randomized horizontal-band displacement for a digital-glitch look. */
function applyGlitchSlices(ctx: CanvasRenderingContext2D, w: number, h: number, value: number) {
  const intensity = Math.max(0, Math.min(100, value)) / 100;
  if (intensity <= 0) return;
  const snapshot = document.createElement('canvas');
  snapshot.width = w;
  snapshot.height = h;
  const snapCtx = snapshot.getContext('2d');
  if (!snapCtx) return;
  snapCtx.drawImage(ctx.canvas, 0, 0);

  const bands = 14;
  const bandH = h / bands;
  for (let i = 0; i < bands; i++) {
    if (Math.random() < intensity * 0.5) {
      const dx = (Math.random() - 0.5) * 50 * intensity;
      ctx.drawImage(snapshot, 0, i * bandH, w, bandH, dx, i * bandH, w, bandH);
    }
  }
}

function maskForType(type: TransitionType, r: number, w: number, h: number): Path2D | null {
  const p = new Path2D();
  switch (type) {
    case 'wipe-left':
      p.rect(w / 2 - w * r, -h / 2, w * r, h);
      return p;
    case 'wipe-right':
      p.rect(-w / 2, -h / 2, w * r, h);
      return p;
    case 'wipe-up':
      p.rect(-w / 2, h / 2 - h * r, w, h * r);
      return p;
    case 'wipe-down':
      p.rect(-w / 2, -h / 2, w, h * r);
      return p;
    case 'iris': {
      const maxRadius = Math.sqrt((w / 2) ** 2 + (h / 2) ** 2);
      p.arc(0, 0, maxRadius * r, 0, Math.PI * 2);
      return p;
    }
    default:
      return null;
  }
}

function computeTransitionEffect(type: TransitionType, r: number, w: number, h: number): TransitionEffect {
  switch (type) {
    case 'cross-dissolve':
      return { ...IDENTITY_EFFECT, opacity: r };
    case 'dip-to-black':
      return { ...IDENTITY_EFFECT, opacity: r, flashColor: '#000000' };
    case 'dip-to-white':
      return { ...IDENTITY_EFFECT, opacity: r, flashColor: '#ffffff' };
    case 'blur-dissolve':
      return { ...IDENTITY_EFFECT, opacity: r, extraBlurPx: Math.sin(r * Math.PI) * 18 };
    case 'zoom-in':
      return { ...IDENTITY_EFFECT, opacity: r, scaleMod: 0.5 + r * 0.5 };
    case 'wipe-left':
    case 'wipe-right':
    case 'wipe-up':
    case 'wipe-down':
    case 'iris':
      return { ...IDENTITY_EFFECT, maskPath: maskForType(type, r, w, h) };
    case 'slide-left':
      return { ...IDENTITY_EFFECT, offsetX: (1 - r) * w };
    case 'slide-right':
      return { ...IDENTITY_EFFECT, offsetX: -(1 - r) * w };
    case 'slide-up':
      return { ...IDENTITY_EFFECT, offsetY: (1 - r) * h };
    case 'slide-down':
      return { ...IDENTITY_EFFECT, offsetY: -(1 - r) * h };
    case 'glitch':
      return { ...IDENTITY_EFFECT, opacity: r };
    default:
      return { ...IDENTITY_EFFECT };
  }
}

function combineTransitionEffects(a: TransitionEffect, b: TransitionEffect): TransitionEffect {
  return {
    opacity: Math.min(a.opacity, b.opacity),
    scaleMod: a.scaleMod * b.scaleMod,
    offsetX: a.offsetX + b.offsetX,
    offsetY: a.offsetY + b.offsetY,
    extraBlurPx: Math.max(a.extraBlurPx, b.extraBlurPx),
    flashColor: a.flashColor || b.flashColor,
    maskPath: a.maskPath || b.maskPath, // rare overlap case: last-writer wins rather than trying to intersect two Path2Ds
  };
}

export const videoCompositor = new VideoCompositor();
