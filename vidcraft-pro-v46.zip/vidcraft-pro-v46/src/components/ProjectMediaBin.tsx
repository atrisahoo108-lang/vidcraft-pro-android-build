import React, { useState, useRef } from 'react';
import { 
  FolderPlus, Upload, Search, Film, Music, Image as ImageIcon, 
  Trash2, Plus, Grid, List, Sparkles, FileText, CheckCircle2, AlertTriangle, Link2
} from 'lucide-react';
import { MediaAsset } from '../types';
import { formatDuration } from '../utils/timecode';

interface ProjectMediaBinProps {
  assets: MediaAsset[];
  // `file` is passed alongside the asset (for local imports only) so the
  // caller can cache the actual bytes in IndexedDB — without this, the
  // asset's blob: URL would stop working the moment the page reloads.
  onAddAsset: (asset: MediaAsset, file?: File) => void;
  onSelectSourceAsset: (asset: MediaAsset) => void;
  onAddAssetToTimeline: (asset: MediaAsset) => void;
  // Called when the user picks a replacement file for an asset flagged
  // isOfflineMissing (its cached bytes weren't found — e.g. project opened
  // on a different device/browser than it was imported on).
  onRelinkAsset?: (assetId: string, file: File) => void;
  activeSourceAssetId?: string;
  // v43: bigger touch targets, no-hover-required quick actions, and a
  // reflowing grid instead of a fixed 2-column one. Defaults to false —
  // desktop/web rendering is unchanged unless a caller passes true.
  isMobile?: boolean;
}

export const ProjectMediaBin: React.FC<ProjectMediaBinProps> = ({
  assets,
  onAddAsset,
  onSelectSourceAsset,
  onAddAssetToTimeline,
  onRelinkAsset,
  activeSourceAssetId,
  isMobile = false
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const relinkInputRef = useRef<HTMLInputElement | null>(null);
  const [relinkTargetId, setRelinkTargetId] = useState<string | null>(null);

  // Reads the real length of a video/audio file from its own metadata,
  // instead of a guessed/placeholder number, before the asset is ever
  // created — so the very first clip made from it already has the right
  // duration (see handleFileUpload below).
  //
  // Resolves `undefined` (never rejects) if the duration genuinely can't be
  // determined, so a bad/corrupt file falls back gracefully instead of
  // breaking the import.
  const probeMediaDuration = (url: string, kind: 'video' | 'audio'): Promise<number | undefined> => {
    return new Promise(resolve => {
      const el = kind === 'video' ? document.createElement('video') : document.createElement('audio');
      let settled = false;
      const finish = (value: number | undefined) => {
        if (settled) return;
        settled = true;
        el.removeAttribute('src');
        resolve(value);
      };

      el.preload = 'metadata';
      el.onloadedmetadata = () => {
        const d = el.duration;
        if (Number.isFinite(d) && d > 0) {
          finish(d);
          return;
        }
        if (d === Infinity) {
          // Some encoders (including this app's own WebM export) omit the
          // duration from the file header — the standard browser
          // workaround is to seek past the end, which forces it to compute
          // the real length and fire 'durationchange'.
          el.currentTime = 1e10;
          el.ondurationchange = () => {
            if (Number.isFinite(el.duration) && el.duration > 0) {
              finish(el.duration);
            }
          };
          return;
        }
        finish(undefined);
      };
      el.onerror = () => finish(undefined);
      // Belt-and-suspenders: don't leave the import hanging forever if a
      // malformed file never fires loadedmetadata or error.
      setTimeout(() => finish(undefined), 8000);
      el.src = url;
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const fileList = Array.from(files);
    if (fileInputRef.current) fileInputRef.current.value = '';

    fileList.forEach(async (file: File) => {
      const url = URL.createObjectURL(file);
      const isVideo = file.type.startsWith('video');
      const isAudio = file.type.startsWith('audio');
      const isImage = file.type.startsWith('image');
      const assetType = isVideo ? 'video' : isAudio ? 'audio' : 'image';

      // Video/audio: read the real duration from the file's own metadata
      // before creating the asset. Images have no intrinsic duration, so
      // they keep the existing fixed default untouched.
      let duration = 5;
      if (isVideo || isAudio) {
        const probed = await probeMediaDuration(url, isVideo ? 'video' : 'audio');
        // 12s fallback only if the real duration truly couldn't be read
        // (corrupt file, unsupported codec, etc.) — matches the previous
        // hard-coded value, now used only as a last resort instead of always.
        duration = probed ?? 12;
      }

      const newAsset: MediaAsset = {
        id: `asset-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        name: file.name,
        type: assetType,
        src: url,
        duration,
        fileSize: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        category: 'User Imports',
        thumbnailUrl: isImage ? url : undefined,
        isLocalFile: true
      };

      onAddAsset(newAsset, file);
    });
  };

  const startRelink = (assetId: string) => {
    setRelinkTargetId(assetId);
    relinkInputRef.current?.click();
  };

  const handleRelinkFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && relinkTargetId && onRelinkAsset) {
      onRelinkAsset(relinkTargetId, file);
    }
    setRelinkTargetId(null);
    if (relinkInputRef.current) relinkInputRef.current.value = '';
  };

  const filteredAssets = assets.filter(a => {
    const matchesSearch = a.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (a.category && a.category.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesType = filterType === 'all' || a.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="h-full flex flex-col bg-[#16161b] text-zinc-200 text-xs select-none">
      {/* Header Bar with Search & Actions */}
      <div className={`bg-[#1e1e26] border-b border-[#282834] px-2 flex items-center justify-between ${isMobile ? 'h-11' : 'h-8'}`}>
        <div className="flex items-center space-x-1">
          <span className="font-semibold text-zinc-100 text-[11px]">Project Bin</span>
          <span className="text-[10px] text-zinc-500 font-mono-code">({assets.length})</span>
        </div>

        <div className="flex items-center space-x-1">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            multiple
            accept="video/*,audio/*,image/*"
            className="hidden"
          />
          <input
            type="file"
            ref={relinkInputRef}
            onChange={handleRelinkFile}
            accept="video/*,audio/*,image/*"
            className="hidden"
          />
          <button
            id="btn-import-media"
            onClick={() => fileInputRef.current?.click()}
            title="Import Media Files (MP4, MP3, PNG, JPG, WebM)"
            className={`rounded bg-[#2b2b36] hover:bg-[#383848] text-sky-400 hover:text-white flex items-center space-x-1 font-medium ${
              isMobile ? 'px-3 py-2 text-[11px]' : 'px-2 py-1 text-[10px]'
            }`}
          >
            <Upload className="w-3 h-3" />
            <span>Import</span>
          </button>

          <div className="h-3 w-px bg-[#2d2d38] mx-0.5" />

          <button
            onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
            title="Toggle Grid / List View"
            className={`rounded text-zinc-400 hover:text-zinc-200 hover:bg-[#282834] ${isMobile ? 'p-2' : 'p-1'}`}
          >
            {viewMode === 'grid' ? <List className="w-3.5 h-3.5" /> : <Grid className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Filter & Search Toolbar */}
      <div className="px-2 py-1.5 bg-[#181820] border-b border-[#242430] flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="w-3 h-3 text-zinc-500 absolute left-2 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search footage, audio, SFX..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full bg-[#111116] border border-[#2b2b38] rounded pl-6 pr-2 text-[10px] text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-sky-500 ${
              isMobile ? 'py-2' : 'py-0.5'
            }`}
          />
        </div>

        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className={`bg-[#111116] border border-[#2b2b38] rounded px-1.5 text-[10px] text-zinc-300 focus:outline-none ${
            isMobile ? 'py-2' : 'py-0.5'
          }`}
        >
          <option value="all">All Types</option>
          <option value="video">Videos</option>
          <option value="audio">Audio / SFX</option>
          <option value="image">Images</option>
        </select>
      </div>

      {/* Assets Grid / List */}
      <div className="flex-1 p-2 overflow-y-auto">
        {filteredAssets.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-zinc-500 text-center p-4">
            <Film className="w-6 h-6 mb-1 opacity-50" />
            <span className="text-[11px]">No matching assets found</span>
          </div>
        ) : viewMode === 'grid' ? (
          <div
            className={isMobile ? 'grid gap-2' : 'grid grid-cols-2 gap-2'}
            style={isMobile ? { gridTemplateColumns: 'repeat(auto-fill, minmax(128px, 1fr))' } : undefined}
          >
            {filteredAssets.map(asset => {
              const isSelected = activeSourceAssetId === asset.id;
              return (
                <div
                  key={asset.id}
                  onDoubleClick={() => onSelectSourceAsset(asset)}
                  className={`group relative bg-[#1c1c24] border rounded overflow-hidden transition-all ${isMobile ? '' : 'cursor-pointer hover:scale-[1.02]'} ${
                    isSelected ? 'border-sky-400 shadow-md ring-1 ring-sky-400/40' : 'border-[#282834] hover:border-[#3d3d4e]'
                  }`}
                >
                  {/* Thumbnail */}
                  <div className="aspect-video bg-[#111116] relative flex items-center justify-center overflow-hidden">
                    {asset.isOfflineMissing ? (
                      <div className="flex flex-col items-center justify-center text-amber-400 px-1 text-center">
                        <AlertTriangle className="w-5 h-5 opacity-80" />
                        <span className="text-[8px] mt-1 text-zinc-400">Media offline</span>
                      </div>
                    ) : asset.thumbnailUrl ? (
                      <img src={asset.thumbnailUrl} alt={asset.name} className="w-full h-full object-cover" />
                    ) : asset.type === 'video' ? (
                      <video src={asset.src} className="w-full h-full object-cover opacity-60" preload="metadata" />
                    ) : asset.type === 'audio' ? (
                      <div className="flex flex-col items-center justify-center text-emerald-400">
                        <Music className="w-5 h-5 opacity-75" />
                        <span className="text-[8px] mt-1 font-mono-code text-zinc-500">Audio Track</span>
                      </div>
                    ) : (
                      <ImageIcon className="w-5 h-5 text-amber-400 opacity-75" />
                    )}

                    {/* Media Type Badge */}
                    <div className="absolute top-1 left-1 px-1 py-0.5 rounded bg-black/70 text-[8px] font-mono-code text-zinc-300 flex items-center space-x-0.5">
                      {asset.type === 'video' && <Film className="w-2.5 h-2.5 text-sky-400" />}
                      {asset.type === 'audio' && <Music className="w-2.5 h-2.5 text-emerald-400" />}
                      {asset.type === 'image' && <ImageIcon className="w-2.5 h-2.5 text-amber-400" />}
                      <span className="uppercase">{asset.type}</span>
                    </div>

                    {/* Duration Badge */}
                    {asset.duration > 0 && (
                      <div className="absolute bottom-1 right-1 px-1 py-0.5 rounded bg-black/70 text-[8px] font-mono-code text-zinc-300">
                        {formatDuration(asset.duration)}
                      </div>
                    )}

                    {/* Quick Add Overlay — on desktop this only appears on
                        hover; touch has no hover state, so on mobile it's
                        always shown (at slightly lower opacity so the
                        thumbnail underneath stays visible) with bigger
                        buttons instead of depending on group-hover. */}
                    <div
                      className={`absolute inset-0 flex items-center justify-center space-x-2 transition-opacity ${
                        isMobile
                          ? 'bg-black/50 opacity-100'
                          : 'bg-black/60 opacity-0 group-hover:opacity-100'
                      }`}
                    >
                      {asset.isOfflineMissing ? (
                        <button
                          onClick={(e) => { e.stopPropagation(); startRelink(asset.id); }}
                          className={`rounded-full bg-amber-600 hover:bg-amber-500 text-white flex items-center space-x-1 ${
                            isMobile ? 'px-3 py-2 text-[10px]' : 'px-2 py-1 text-[9px]'
                          }`}
                          title="Locate the original file on this device"
                        >
                          <Link2 className="w-3 h-3" />
                          <span>Relink</span>
                        </button>
                      ) : (
                        <>
                          <button
                            onClick={(e) => { e.stopPropagation(); onSelectSourceAsset(asset); }}
                            className={`rounded-full bg-sky-600 hover:bg-sky-500 text-white ${
                              isMobile ? 'px-3 py-2 text-[10px]' : 'p-1 text-[9px]'
                            }`}
                            title="Open in Source Monitor"
                          >
                            Preview
                          </button>
                          <button
                            onClick={(e) => { e.stopPropagation(); onAddAssetToTimeline(asset); }}
                            className={`rounded-full bg-[#323242] hover:bg-[#444458] text-white ${
                              isMobile ? 'p-2.5' : 'p-1 text-[9px]'
                            }`}
                            title="Add to Timeline"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Asset Title Bar */}
                  <div className="p-1.5 bg-[#181820]">
                    <div className="font-medium text-[10px] text-zinc-200 truncate flex items-center gap-1" title={asset.name}>
                      {asset.isOfflineMissing && <AlertTriangle className="w-2.5 h-2.5 text-amber-400 shrink-0" />}
                      <span className="truncate">{asset.name}</span>
                    </div>
                    <div className="text-[8px] text-zinc-500 truncate mt-0.5">
                      {asset.isOfflineMissing ? 'Needs relinking' : (asset.category || 'Asset')} • {asset.fileSize || 'Standard'}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="space-y-1">
            {filteredAssets.map(asset => {
              const isSelected = activeSourceAssetId === asset.id;
              return (
                <div
                  key={asset.id}
                  onDoubleClick={() => onSelectSourceAsset(asset)}
                  className={`rounded flex items-center justify-between transition-colors ${isMobile ? 'p-2.5' : 'p-1.5 cursor-pointer'} ${
                    isSelected ? 'bg-sky-950/40 border border-sky-500/40 text-sky-200' : 'bg-[#1a1a22] hover:bg-[#242430] text-zinc-300'
                  }`}
                >
                  <div className="flex items-center space-x-2 truncate">
                    {asset.isOfflineMissing ? (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    ) : (
                      <>
                        {asset.type === 'video' && <Film className="w-3.5 h-3.5 text-sky-400 shrink-0" />}
                        {asset.type === 'audio' && <Music className="w-3.5 h-3.5 text-emerald-400 shrink-0" />}
                        {asset.type === 'image' && <ImageIcon className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                      </>
                    )}
                    <span className="text-[11px] font-medium truncate">{asset.name}</span>
                  </div>

                  <div className="flex items-center space-x-2 shrink-0">
                    {asset.isOfflineMissing ? (
                      <button
                        onClick={() => startRelink(asset.id)}
                        className={`rounded bg-amber-600/80 hover:bg-amber-500 text-white text-[9px] flex items-center space-x-1 ${
                          isMobile ? 'px-2.5 py-1.5' : 'px-1.5 py-0.5'
                        }`}
                        title="Locate the original file on this device"
                      >
                        <Link2 className="w-3 h-3" />
                        <span>Relink</span>
                      </button>
                    ) : (
                      <>
                        <span className="font-mono-code text-[10px] text-zinc-500">{formatDuration(asset.duration)}</span>
                        <button
                          onClick={() => onAddAssetToTimeline(asset)}
                          className={`rounded bg-[#2a2a38] hover:bg-sky-600 text-zinc-300 hover:text-white ${isMobile ? 'p-2' : 'p-1'}`}
                          title="Add to Timeline"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
