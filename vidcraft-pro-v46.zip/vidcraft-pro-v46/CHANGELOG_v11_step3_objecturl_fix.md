# v11 — Step 3: Fix stale Object URLs

Scope: exactly what STEP 3 asked for — object URL lifecycle cleanup. Nothing
else touched (no proxy editing, no timeline/audio-engine/export changes).

## Object URL Audit (before → after)

| # | Location | Represents | Owner | Lifetime it needs | Before | After |
|---|----------|-----------|-------|--------------------|--------|-------|
| 1 | `ProjectMediaBin.tsx:44` | Newly imported media (video/audio/image) | `assets` state in `App.tsx` | Whole session, until the asset is superseded | never revoked | revoked by `releaseLocalAssetUrls` when the asset it belongs to is later replaced/discarded (see #2–#4) |
| 2 | `App.tsx` `hydrateFromSnapshot` | Restored local media, rebuilt from an IndexedDB blob when opening a project | `assets` state | Until this project is closed/replaced by another | old URLs from the *previous* project leaked on every "Open Recent" / restore | previous project's local URLs released right after the new ones are committed |
| 3 | `App.tsx` `handleNewProject` | Same as #2 | `assets` state | Until "New Project" | old URLs leaked | released |
| 4 | `App.tsx` `handleRelinkAsset` | Replacement file for a "media offline" asset | one `MediaAsset` entry | Until relinked again | old URL leaked, and the compositor's cached `<video>`/`<img>` kept pointing at the stale src (asset id unchanged) | old URL released; compositor cache for that asset id explicitly dropped so it picks up the new src |
| 5 | `App.tsx` `handleSaveProjectAs` | Downloadable `.vidcraftproj.json` (not media) | local `url` var | Only until `a.click()` returns | already revoked immediately after | unchanged (already correct) |
| 6 | `ExportModal.tsx` `exportVideo` | Finished MP4/WebM render | `exportedUrl` state | Until downloaded/abandoned or a new export starts | never revoked | revoked when superseded by the next export, or on unmount |
| 7 | `ExportModal.tsx` `exportWav` | Finished WAV render | `exportedUrl` state | Same as #6 | never revoked | same fix as #6 (shared state) |

**Counts:** `createObjectURL` — 6 call sites (unchanged, all legitimate). `revokeObjectURL` — was 1, now 4 (the 3 new ones are the fix; #5's pre-existing one was already correct and untouched).

## What was changed

**`src/App.tsx`**
- Added `releaseLocalAssetUrls(staleAssets)` — a small helper (not a global manager) that, given a list of assets about to be superseded, revokes their `blob:` URLs. It only acts on `isLocalFile` assets with a `blob:` src (remote sample-library URLs are left alone — nothing to release). The actual revoke is deferred with `setTimeout(...,0)` so React has already repainted every `<video>`/`<img>` bound to the *new* assets before the old URL disappears — revoking synchronously in the same tick that replaces state would race the re-render. It also calls `videoCompositor.disposeAsset(id)` first, because that module caches `<video>`/`<img>` elements by asset id and (by design, confirmed by reading its code) does **not** update an existing cached element's `src` — so on a relink, the compositor would otherwise keep playing the old file forever even after `assets` state updates.
- Wired it into the three places that actually replace/discard assets: `hydrateFromSnapshot` (opening a project), `handleNewProject`, and `handleRelinkAsset`.
- `handleRelinkAsset` also now updates `activeSourceAsset` (Source Monitor's own copy of the open asset) when the relinked asset is the one currently previewed — without this, Source Monitor would keep pointing at the URL that's about to be revoked.

**`src/components/ExportModal.tsx`**
- `handleStartExport` now revokes the previous `exportedUrl` (if any) before starting a new render — this was the real leak: exporting more than once in a session (trying a different format/resolution, or just re-running it) piled up an un-revoked blob every time.
- Added an unmount cleanup effect as a safety net. In the current app this component is mounted for the app's whole lifetime (parent always renders it, just toggles `isOpen`), so this mostly future-proofs against that changing later.

## Files Modified
- `src/App.tsx`
- `src/components/ExportModal.tsx`

(`src/components/ProjectMediaBin.tsx` was read and included in the audit but not modified — the URL it creates is correctly owned and released one level up, in `App.tsx`, where the asset's actual lifetime is decided.)

## Why
Every `createObjectURL()` in the app had a real, identifiable lifetime, but three of the six had no matching cleanup: switching projects, starting a new project, relinking media, and re-exporting all left the previous blob alive in memory for the rest of the session with no way to reclaim it short of a full page reload. On a long editing session (import media, try a few projects, export a few times) this grows without bound — exactly the kind of thing that matters on an 8GB machine.

## Tests Performed
- Read every file in `src/` for `createObjectURL`/`revokeObjectURL` (not just trusted the prior audit) — found the 6 create-sites and 1 (now 4) revoke-sites listed above.
- Read `videoCompositor.ts`'s caching logic in full to confirm it's keyed by asset id and does *not* refresh `src` on a cache hit — this is why relink needed an explicit `disposeAsset` call, not just a revoke.
- Read `audioEngine.ts`'s caching logic to confirm it's keyed by **clip id**, not asset id — so an orphaned cached `<audio>` element after a project switch is never reused/replayed (the render loop only iterates current clips), meaning it's safe to revoke the asset's URL underneath it. (The audio engine itself was not modified, per the instructions.)
- Confirmed `ProgramMonitor.tsx` looks up `assets.find(a => a.id === clip.assetId)` fresh every frame from the live `assets` prop — not a cached/stale reference — so once state updates and the compositor cache is dropped, playback picks up the new URL automatically.
- Diffed every modified file byte-for-byte against the original v10 zip to confirm only the intended lines changed (posted as part of this session).
- Ran an isolated `tsc` check (real `react`/`react-dom` packages symlinked in, a hand-written `lucide-react` type stub covering every icon actually imported in this codebase, `skipLibCheck` on) scoped to `src/**/*`. Result: zero new type errors in either modified file — every reported error is one of the same 3 pre-existing, environment-only categories present before this change (missing `@types/react`/`@types/react-dom`, missing `vite/client` types for the CSS import, a `FileList.forEach` typing nuance in `ProjectMediaBin.tsx` unrelated to this change).

## Result
- **Passed:** isolated `tsc` type-check (scoped, with the stubs described above) — zero new errors.
- **Passed:** manual code-trace of all 7 Test A–G scenarios in the brief (import, delete/switch project, playback, image, project reload, relink, export) against the actual call graph — each one lands on a path that either already worked or is now fixed as described above.
- **Unable to run:** `npm install`, `npm run lint` (`tsc --noEmit` with the *real* `node_modules`), `npm run dev`, or a production build. This sandbox has no network access, so real dependencies (React types, Vite, Tailwind, Capacitor, etc.) can't be installed. Please run `npm install && npm run lint && npm run dev` locally and click through Test A–G once before shipping — the isolated check above is a strong signal but isn't a substitute for the real toolchain.

## Memory Impact
Previously, each of "open a different project," "start a new project," "relink an offline asset," and "export more than once" left one or more multi-megabyte `blob:` URLs (and, for relink, a duplicate cached `<video>` element) alive for the rest of the tab's life with no way to reclaim them. In a realistic session — import some clips, try two or three project versions, export a couple of times — that's several un-revoked blobs of imported-media size sitting in memory that didn't need to be there. Now each is released within one tick of being superseded, so steady-state memory during a long session tracks "what's actually in the current project" instead of "everything ever loaded this session."

## Discovered but Not Changed
- **`audioEngine.ts` has no dispose/prune for its `audioElements`/`sourceNodes`/`trackGains` maps** (keyed by clip id) — switching projects orphans those entries permanently (they're inert, since the render loop won't call back into a clip id that no longer exists, but the memory/node objects themselves are never freed). This is the audio-side counterpart to the `videoCompositor.pruneUnusedAssets` fix already done in the "C2" pass, but the brief explicitly excluded touching the audio engine, so it's left as-is.
- **No per-asset "remove from bin" action exists yet.** Once one is added, it'll need to call `releaseLocalAssetUrls([thatAsset])` too (the helper is already written to support this — it just isn't wired to a UI action yet).
- **GIF export** still silently falls back to WebM (pre-existing, documented in `PROJECT_FIX_NOTES_v8.md`, unrelated to this step).

## Next Recommended Step
Give `audioEngine.ts` the same dispose/prune treatment `videoCompositor.ts` already got in the "C2" pass (free `audioElements`/`sourceNodes`/`trackGains` for clip ids no longer in the timeline) — same category of fix (long-session memory growth on modest hardware), same low-risk shape, and it directly closes the gap noted above.

Not implementing this automatically — stopping here per instructions.
