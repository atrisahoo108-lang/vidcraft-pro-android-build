// -----------------------------------------------------------------------
// VidCraft Pro — License verification boundary (foundation only)
// -----------------------------------------------------------------------
// THIS FILE DOES NOT VERIFY ANYTHING CRYPTOGRAPHICALLY YET.
//
// There is currently no real signing key, payment provider, activation
// server, or licensing server anywhere in this project. This file exists
// so that when one exists, there is ONE clearly-named boundary function
// for the rest of the app to call — `verifyProductionLicense()` — instead
// of a real verifier being bolted on ad hoc later.
//
// Until a real verifier is wired in here, this module is intentionally
// conservative:
//   - A signature field being *present* on a license is NOT treated as
//     proof of anything. We do not check it against any key, because no
//     key exists — there is nothing to check it against.
//   - No secret/private key is embedded, generated, or hard-coded here.
//   - Nothing is ever reported as `verified: true`.
//
// A real implementation (e.g. using Web Crypto's `crypto.subtle.verify`
// with a public key baked into a future build, checked against a
// signature produced by a private key that never ships in this app) can
// replace the body of `runVerifier()` below without any caller needing to
// change, because the shape of `LicenseVerificationResult` already
// distinguishes "not configured" from "verified" from "invalid".

import type { ProductionLicense } from './license';

export type LicenseVerificationStatus =
  | 'invalid'        // license data itself is malformed/unusable
  | 'unverified'      // structurally fine, but carries no signature to check
  | 'not-configured'  // carries a signature, but no verifier/key exists yet
  | 'verified';        // signature was actually checked and passed (unused today)

export interface LicenseVerificationResult {
  status: LicenseVerificationStatus;
  verified: boolean;
  reason: string;
}

/**
 * A verifier is just "given a license, decide if its signature checks
 * out" — kept as its own function type so a real cryptographic
 * implementation can be swapped in later (e.g. loaded from a config
 * module holding a public key) without changing `verifyProductionLicense`'s
 * signature or any of its callers.
 */
export type LicenseVerifier = (license: ProductionLicense) => LicenseVerificationResult;

function isParseableDate(value: string): boolean {
  return !Number.isNaN(new Date(value).getTime());
}

/** Type/shape checks only — no cryptography. Mirrors license.ts's own structural check plus a date-sanity check, so verification never has to trust unparsed data. */
function hasValidStructure(license: ProductionLicense): boolean {
  if (!license.licenseId || typeof license.licenseId !== 'string') return false;
  if (license.tier !== 'FREE' && license.tier !== 'PRO') return false;
  if (license.expiryDate !== null) {
    if (typeof license.expiryDate !== 'string' || !isParseableDate(license.expiryDate)) {
      // A malformed expiry date must never be treated as "no expiry" —
      // it makes the whole license structurally unusable instead.
      return false;
    }
  }
  return true;
}

/**
 * No real signing key exists in this codebase (see file header). This is
 * the single, obvious place a future implementation replaces — everything
 * above it (structural checks) and below it (the exported function) stays
 * the same.
 */
function runVerifier(license: ProductionLicense): LicenseVerificationResult {
  if (!license.signature || !license.keyId || !license.algorithm) {
    return {
      status: 'unverified',
      verified: false,
      reason: 'License has no signature metadata to verify.'
    };
  }

  // Signature metadata is present, but there is no configured public key
  // or verifier implementation anywhere in this project yet. Presence of
  // a signature string is not evidence of anything on its own — do not
  // fabricate a pass here.
  return {
    status: 'not-configured',
    verified: false,
    reason: 'License carries signature metadata, but no verifier/key is configured yet — treating as unverified.'
  };
}

/**
 * The verification boundary. Distinguishes:
 *  - `invalid`        — license is missing/malformed, nothing to verify
 *  - `unverified`      — well-formed, but has no signature to check
 *  - `not-configured`  — well-formed and signed, but no real key exists yet
 *  - `verified`        — signature actually checked out (not reachable today)
 *
 * Never throws on malformed input, and never returns `verified: true`
 * without a real cryptographic check having happened.
 */
export function verifyProductionLicense(license: ProductionLicense | null): LicenseVerificationResult {
  if (!license) {
    return { status: 'invalid', verified: false, reason: 'No production license is present.' };
  }

  try {
    if (!hasValidStructure(license)) {
      return { status: 'invalid', verified: false, reason: 'License data is structurally invalid.' };
    }
    return runVerifier(license);
  } catch {
    // Defensive: any unexpected error while inspecting license data is a
    // reason to distrust it, never to crash the caller.
    return { status: 'invalid', verified: false, reason: 'License data could not be evaluated.' };
  }
}
