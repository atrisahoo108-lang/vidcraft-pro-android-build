/**
 * Foundation for decoupling live-preview render resolution from the
 * project's actual resolution (audit item C1).
 *
 * This module is intentionally just pure math with no side effects and no
 * wiring to any UI/state yet — that's a deliberate, separate future step.
 * Today, every caller passes `maxDimension: null`, which makes
 * `computePreviewDimensions` return the project's resolution completely
 * unchanged — so introducing this doesn't alter current behavior at all.
 */

export interface PreviewDimensions {
  width: number;
  height: number;
}

/**
 * Given a project's real resolution and an optional cap on the longer edge,
 * returns the resolution the live preview canvas should actually render at.
 *
 * - `maxDimension: null` (the current default everywhere it's used) → returns
 *   `{ width: projectWidth, height: projectHeight }` unchanged. This is what
 *   keeps today's behavior identical until a future step actually sets a cap.
 * - A numeric `maxDimension` scales the longer edge down to that many pixels
 *   and derives the other edge from the project's aspect ratio, so the
 *   preview never distorts — it just renders smaller.
 * - Never upscales: if the project is already smaller than the cap on both
 *   edges, the project's own resolution is returned as-is.
 * - Always returns integers (canvas dimensions must be whole pixels).
 */
export function computePreviewDimensions(
  projectWidth: number,
  projectHeight: number,
  maxDimension: number | null
): PreviewDimensions {
  if (!maxDimension || maxDimension <= 0) {
    return { width: projectWidth, height: projectHeight };
  }

  const longerEdge = Math.max(projectWidth, projectHeight);
  if (longerEdge <= maxDimension) {
    // Already at or below the cap — never upscale.
    return { width: projectWidth, height: projectHeight };
  }

  const scale = maxDimension / longerEdge;
  return {
    width: Math.max(1, Math.round(projectWidth * scale)),
    height: Math.max(1, Math.round(projectHeight * scale))
  };
}
