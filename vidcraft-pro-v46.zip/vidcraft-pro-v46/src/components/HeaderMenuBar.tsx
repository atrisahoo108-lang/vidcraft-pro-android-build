import React, { useRef, useState } from 'react';
import { 
  Play, Pause, Undo2, Redo2, Magnet, Download, 
  HelpCircle, Monitor, Layers, Palette, Volume2, Type, 
  Settings, Film, Scissors, Plus, Check, Clock, FilePlus2,
  Save, FolderOpen, FolderDown, Loader2, CloudOff, KeyRound
} from 'lucide-react';
import { WorkspaceMode, ProjectSettings } from '../types';
import { formatTimecode } from '../utils/timecode';

export type SaveStatus = 'idle' | 'saving' | 'saved' | 'dirty' | 'unavailable';

interface HeaderMenuBarProps {
  workspace: WorkspaceMode;
  setWorkspace: (ws: WorkspaceMode) => void;
  project: ProjectSettings;
  setProject: React.Dispatch<React.SetStateAction<ProjectSettings>>;
  currentTime: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onUndo: () => void;
  onRedo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  undoLabel?: string;
  redoLabel?: string;
  snapping: boolean;
  setSnapping: (val: boolean | ((prev: boolean) => boolean)) => void;
  onOpenExport: () => void;
  onOpenLicensePanel: () => void;
  onOpenShortcuts: () => void;
  onNewTextClip: () => void;
  onSplitAtPlayhead: () => void;
  onNewProject: () => void;
  onSaveProject: () => void;
  onSaveProjectAs: () => void;
  onOpenProjectFile: (file: File) => void;
  onOpenProjectManager: () => void;
  saveStatus: SaveStatus;
  // v43: taller touch targets + safe-area-aware top padding on phones.
  // Defaults to false, so desktop/web rendering is byte-for-byte the same
  // as v42 unless a caller explicitly passes true.
  isMobile?: boolean;
}

export const HeaderMenuBar: React.FC<HeaderMenuBarProps> = ({
  workspace,
  setWorkspace,
  project,
  currentTime,
  isPlaying,
  onTogglePlay,
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  undoLabel,
  redoLabel,
  snapping,
  setSnapping,
  onOpenExport,
  onOpenLicensePanel,
  onOpenShortcuts,
  onNewTextClip,
  onSplitAtPlayhead,
  onNewProject,
  onSaveProject,
  onSaveProjectAs,
  onOpenProjectFile,
  onOpenProjectManager,
  saveStatus,
  isMobile = false
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const openFileInputRef = useRef<HTMLInputElement | null>(null);

  const workspaces: { id: WorkspaceMode; label: string; icon: any }[] = [
    { id: 'editing', label: 'Editing', icon: Film },
    { id: 'color', label: 'Color', icon: Palette },
    { id: 'effects', label: 'Effects', icon: Layers },
    { id: 'audio', label: 'Audio', icon: Volume2 },
    { id: 'graphics', label: 'Graphics', icon: Type },
    { id: 'export', label: 'Export', icon: Download },
  ];

  return (
    <header
      className={`safe-top bg-[#141416] border-b border-[#27272e] flex items-center justify-between px-2 text-xs select-none z-30 shrink-0 overflow-x-auto flex-nowrap ${
        isMobile ? 'h-12' : 'h-10'
      }`}
    >
      {/* Tap-anywhere-outside-to-close backdrop for open dropdown menus.
          onMouseLeave (below, unchanged) already handles this with a
          mouse; touch has no hover/leave event, so without this an open
          File/Edit menu had no way to be dismissed except toggling the
          same button again — this fixes that for both input types. */}
      {activeMenu && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setActiveMenu(null)}
          onPointerDown={() => setActiveMenu(null)}
        />
      )}

      {/* Left: App Branding & Menus */}
      <div className="flex items-center space-x-2">
        <div className="flex items-center space-x-1.5 px-2 py-0.5 bg-[#003c5c] rounded text-[#99ddff] font-bold tracking-wider text-[11px] border border-[#336699]/40 shadow-sm">
          <span className="text-[#e0f4ff]">VC</span>
          <span className="text-[9px] text-zinc-300 font-medium ml-0.5">PRO</span>
        </div>

        <div className="flex items-center space-x-1 text-zinc-400">
          <div className="relative">
            <button 
              id="menu-file-btn"
              onClick={() => setActiveMenu(activeMenu === 'file' ? null : 'file')}
              className={`rounded hover:bg-[#27272e] hover:text-zinc-100 transition-colors ${isMobile ? 'px-2.5 py-2' : 'px-2 py-1'} ${activeMenu === 'file' ? 'bg-[#27272e] text-white' : ''}`}
            >
              File
            </button>
            {activeMenu === 'file' && (
              <div 
                className="absolute left-0 top-full mt-1 w-52 bg-[#1e1e24] border border-[#32323e] rounded shadow-2xl py-1 z-50 text-zinc-200"
                onMouseLeave={() => setActiveMenu(null)}
              >
                <button 
                  onClick={() => { onNewProject(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center space-x-2"
                >
                  <FilePlus2 className="w-3.5 h-3.5" />
                  <span>New Project</span>
                </button>
                <button 
                  onClick={() => { onOpenProjectManager(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center space-x-2"
                >
                  <FolderOpen className="w-3.5 h-3.5" />
                  <span>Open Recent Project...</span>
                </button>
                <button 
                  onClick={() => { openFileInputRef.current?.click(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center space-x-2"
                >
                  <FolderOpen className="w-3.5 h-3.5" />
                  <span>Open Project File...</span>
                </button>
                <input
                  type="file"
                  ref={openFileInputRef}
                  accept="application/json,.json,.vidcraftproj"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) onOpenProjectFile(file);
                    if (openFileInputRef.current) openFileInputRef.current.value = '';
                  }}
                />
                <div className="my-1 border-t border-[#2d2d38]"></div>
                <button 
                  onClick={() => { onSaveProject(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center justify-between"
                >
                  <span className="flex items-center space-x-2">
                    <Save className="w-3.5 h-3.5" />
                    <span>Save Project</span>
                  </span>
                  <span className="text-[10px] text-zinc-400">Ctrl+S</span>
                </button>
                <button 
                  onClick={() => { onSaveProjectAs(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center space-x-2"
                >
                  <FolderDown className="w-3.5 h-3.5" />
                  <span>Save Project As... (Download)</span>
                </button>
                <div className="my-1 border-t border-[#2d2d38]"></div>
                <button 
                  onClick={() => { onNewTextClip(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center justify-between"
                >
                  <span>New Title / Graphic</span>
                  <span className="text-[10px] text-zinc-400">Ctrl+T</span>
                </button>
                <div className="my-1 border-t border-[#2d2d38]"></div>
                <button 
                  onClick={() => { onOpenExport(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center justify-between"
                >
                  <span>Export Media...</span>
                  <span className="text-[10px] text-zinc-400">Ctrl+M</span>
                </button>
                <div className="my-1 border-t border-[#2d2d38]"></div>
                <button 
                  onClick={() => { onOpenLicensePanel(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center space-x-2"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>License...</span>
                </button>
              </div>
            )}
          </div>

          <div className="relative">
            <button 
              id="menu-edit-btn"
              onClick={() => setActiveMenu(activeMenu === 'edit' ? null : 'edit')}
              className={`rounded hover:bg-[#27272e] hover:text-zinc-100 transition-colors ${isMobile ? 'px-2.5 py-2' : 'px-2 py-1'} ${activeMenu === 'edit' ? 'bg-[#27272e] text-white' : ''}`}
            >
              Edit
            </button>
            {activeMenu === 'edit' && (
              <div 
                className="absolute left-0 top-full mt-1 w-48 bg-[#1e1e24] border border-[#32323e] rounded shadow-2xl py-1 z-50 text-zinc-200"
                onMouseLeave={() => setActiveMenu(null)}
              >
                <button 
                  onClick={() => { onUndo(); setActiveMenu(null); }}
                  disabled={!canUndo}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white disabled:opacity-40 flex items-center justify-between"
                >
                  <span>Undo</span>
                  <span className="text-[10px] text-zinc-400">Ctrl+Z</span>
                </button>
                <button 
                  onClick={() => { onRedo(); setActiveMenu(null); }}
                  disabled={!canRedo}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white disabled:opacity-40 flex items-center justify-between"
                >
                  <span>Redo</span>
                  <span className="text-[10px] text-zinc-400">Ctrl+Y</span>
                </button>
                <div className="my-1 border-t border-[#2d2d38]"></div>
                <button 
                  onClick={() => { onSplitAtPlayhead(); setActiveMenu(null); }}
                  className="w-full text-left px-3 py-1.5 hover:bg-[#3b82f6] hover:text-white flex items-center justify-between"
                >
                  <span>Razor Split at Playhead</span>
                  <span className="text-[10px] text-zinc-400">Ctrl+K</span>
                </button>
              </div>
            )}
          </div>

          <button 
            id="menu-shortcuts-btn"
            onClick={onOpenShortcuts}
            className={`rounded hover:bg-[#27272e] hover:text-zinc-100 transition-colors flex items-center space-x-1 ${isMobile ? 'px-2.5 py-2' : 'px-2 py-1'}`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            {!isMobile && <span>Shortcuts</span>}
          </button>
        </div>

        <div className="h-4 w-px bg-[#2d2d38] mx-1"></div>

        {/* Undo / Redo / Snapping quick icons */}
        <div className="flex items-center space-x-0.5">
          <button 
            id="hdr-undo-btn"
            onClick={onUndo}
            disabled={!canUndo}
            title={canUndo ? `Undo ${undoLabel} (Ctrl+Z)` : 'Undo (Ctrl+Z)'}
            className={`rounded hover:bg-[#27272e] text-zinc-400 hover:text-zinc-100 disabled:opacity-30 disabled:hover:bg-transparent ${isMobile ? 'p-2' : 'p-1'}`}
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button 
            id="hdr-redo-btn"
            onClick={onRedo}
            disabled={!canRedo}
            title={canRedo ? `Redo ${redoLabel} (Ctrl+Y)` : 'Redo (Ctrl+Y)'}
            className={`rounded hover:bg-[#27272e] text-zinc-400 hover:text-zinc-100 disabled:opacity-30 disabled:hover:bg-transparent ${isMobile ? 'p-2' : 'p-1'}`}
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
          <button 
            id="hdr-snap-btn"
            onClick={() => setSnapping(s => !s)}
            title={`Snapping: ${snapping ? 'ON (S)' : 'OFF (S)'}`}
            className={`rounded transition-colors ${isMobile ? 'p-2' : 'p-1'} ${snapping ? 'bg-sky-500/20 text-sky-400' : 'text-zinc-400 hover:bg-[#27272e] hover:text-zinc-200'}`}
          >
            <Magnet className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Center: Workspaces Selector */}
      <div className="flex items-center bg-[#1c1c22] p-0.5 rounded-md border border-[#2a2a34]">
        {workspaces.map(ws => {
          const Icon = ws.icon;
          const isActive = workspace === ws.id;
          return (
            <button
              key={ws.id}
              id={`ws-tab-${ws.id.toLowerCase()}`}
              onClick={() => {
                if (ws.id === 'export') {
                  onOpenExport();
                } else {
                  setWorkspace(ws.id);
                }
              }}
              className={`flex items-center space-x-1.5 rounded text-[11px] font-medium transition-all ${
                isMobile ? 'px-2.5 py-2' : 'px-2.5 py-1'
              } ${
                isActive 
                  ? 'bg-[#2b2b36] text-sky-400 shadow-sm' 
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#24242e]'
              }`}
            >
              <Icon className={`w-3 h-3 ${isActive ? 'text-sky-400' : 'text-zinc-400'}`} />
              {!isMobile && <span>{ws.label}</span>}
            </button>
          );
        })}
      </div>

      {/* Right: Timecode Display & Primary Export Action */}
      <div className="flex items-center space-x-3">
        <div
          title={
            saveStatus === 'unavailable'
              ? 'Offline auto-save is not available in this browser'
              : 'Project auto-saves to this device — works fully offline'
          }
          className="hidden sm:flex items-center space-x-1 text-[10px]"
        >
          {saveStatus === 'saving' && (
            <>
              <Loader2 className="w-3 h-3 text-zinc-400 animate-spin" />
              <span className="text-zinc-400">Saving…</span>
            </>
          )}
          {saveStatus === 'saved' && (
            <>
              <Check className="w-3 h-3 text-emerald-400" />
              <span className="text-zinc-500">Saved</span>
            </>
          )}
          {saveStatus === 'dirty' && (
            <>
              <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              <span className="text-zinc-500">Unsaved changes</span>
            </>
          )}
          {saveStatus === 'unavailable' && (
            <>
              <CloudOff className="w-3 h-3 text-zinc-500" />
              <span className="text-zinc-500">Auto-save off</span>
            </>
          )}
        </div>

        <div className="flex items-center space-x-1.5 bg-[#181820] px-2.5 py-1 rounded border border-[#2c2c38]">
          <Clock className="w-3 h-3 text-sky-400" />
          <span className="font-mono-code text-[11px] text-sky-300 font-semibold tracking-wider">
            {formatTimecode(currentTime, project.fps)}
          </span>
          <span className="text-[10px] text-zinc-500">/ {formatTimecode(project.duration, project.fps, false)}</span>
        </div>

        <button
          id="btn-export-media"
          onClick={onOpenExport}
          className={`flex items-center space-x-1.5 rounded bg-sky-600 hover:bg-sky-500 text-white font-semibold text-[11px] transition-colors shadow-sm cursor-pointer ${
            isMobile ? 'px-3 py-2' : 'px-3 py-1'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
};
