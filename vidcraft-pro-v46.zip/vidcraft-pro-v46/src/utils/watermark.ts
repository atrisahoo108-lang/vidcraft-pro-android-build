// -----------------------------------------------------------------------
// Free-tier export watermark
// -----------------------------------------------------------------------
// Deliberately isolated in its own file/function so there's one obvious
// place to change, restyle, or remove entirely once a real Pro upgrade
// flow exists — nothing else needs to know how the watermark is drawn,
// only whether to call this.
//
// Called explicitly by the export pipeline (ExportModal.exportVideo)
// AFTER the normal frame render. It never touches videoCompositor.ts or
// ProgramMonitor's live preview loop, so Free-mode editing looks exactly
// like Pro-mode editing — only the exported file differs.

export function drawExportWatermark(
  ctx: CanvasRenderingContext2D,
  canvasWidth: number,
  canvasHeight: number
): void {
  const fontSize = Math.max(14, Math.round(canvasHeight * 0.028));
  const paddingX = Math.round(fontSize * 0.9);
  const paddingY = Math.round(fontSize * 0.55);
  const margin = Math.round(canvasHeight * 0.03);
  const text = 'VidCraft Pro';

  ctx.save();
  // Same UI font family used elsewhere (e.g. text-clip titles) — if it
  // isn't available it falls back to sans-serif like everywhere else in
  // the app; nothing watermark-specific to worry about there.
  ctx.font = `700 ${fontSize}px "Plus Jakarta Sans", sans-serif`;
  ctx.textBaseline = 'middle';
  ctx.textAlign = 'right';

  const metrics = ctx.measureText(text);
  const boxW = metrics.width + paddingX * 2;
  const boxH = fontSize + paddingY * 2;
  const boxX = canvasWidth - margin - boxW;
  const boxY = canvasHeight - margin - boxH;

  // Soft dark pill behind the text so it stays legible over bright footage
  // — "visible but reasonable", not a full-frame stamp.
  ctx.fillStyle = 'rgba(0, 0, 0, 0.38)';
  ctx.beginPath();
  ctx.roundRect(boxX, boxY, boxW, boxH, boxH / 2);
  ctx.fill();

  ctx.fillStyle = 'rgba(255, 255, 255, 0.88)';
  ctx.fillText(text, boxX + boxW - paddingX, boxY + boxH / 2);
  ctx.restore();
}
