import React, { useState } from 'react';
import { 
  Layers, Sparkles, Wand2, SplitSquareVertical, Eye, 
  Plus, Check, Sliders, Zap 
} from 'lucide-react';
import { Clip, TransitionType, VideoFilter } from '../types';

interface EffectsLibraryProps {
  selectedClip: Clip | null;
  onUpdateClip: (clipId: string, updates: Partial<Clip>) => void;
  // v44: taller tabs/buttons on mobile. Defaults to false (unchanged
  // desktop/web behavior).
  isMobile?: boolean;
}

export const EffectsLibrary: React.FC<EffectsLibraryProps> = ({
  selectedClip,
  onUpdateClip,
  isMobile = false
}) => {
  const [activeCategory, setActiveCategory] = useState<'transitions' | 'filters'>('transitions');

  const transitionList: { id: TransitionType; name: string; desc: string; icon: string }[] = [
    { id: 'cross-dissolve', name: 'Cross Dissolve', desc: 'Smooth alpha blend between cuts', icon: '✨' },
    { id: 'dip-to-black', name: 'Dip to Black', desc: 'Fade out to black and fade in', icon: '🌑' },
    { id: 'dip-to-white', name: 'Dip to White', desc: 'Flash transition to white', icon: '☀️' },
    { id: 'blur-dissolve', name: 'Blur Dissolve', desc: 'Cross dissolve that blurs through the midpoint', icon: '🌫️' },
    { id: 'wipe-left', name: 'Wipe Left', desc: 'Hard-edge wipe revealing from the right', icon: '◀️' },
    { id: 'wipe-right', name: 'Wipe Right', desc: 'Hard-edge wipe revealing from the left', icon: '▶️' },
    { id: 'wipe-up', name: 'Wipe Up', desc: 'Hard-edge wipe revealing from the bottom', icon: '🔼' },
    { id: 'wipe-down', name: 'Wipe Down', desc: 'Hard-edge wipe revealing from the top', icon: '🔽' },
    { id: 'iris', name: 'Iris Reveal', desc: 'Classic circular iris open/close', icon: '⭕' },
    { id: 'slide-left', name: 'Slide Left', desc: 'Clip pushes in from the right edge', icon: '⬅️' },
    { id: 'slide-right', name: 'Slide Right', desc: 'Clip pushes in from the left edge', icon: '➡️' },
    { id: 'slide-up', name: 'Slide Up', desc: 'Clip pushes in from the bottom edge', icon: '⬆️' },
    { id: 'slide-down', name: 'Slide Down', desc: 'Clip pushes in from the top edge', icon: '⬇️' },
    { id: 'zoom-in', name: 'Zoom In Punch', desc: 'Kinetic crash zoom in transition', icon: '🔍' },
  ];

  const filterList: { type: VideoFilter['type']; name: string; defaultVal: number; desc: string }[] = [
    { type: 'blur', name: 'Gaussian Blur', defaultVal: 8, desc: 'Soft cinematic depth blur' },
    { type: 'brightness', name: 'Brightness Boost', defaultVal: 130, desc: 'Boost scene luminous energy' },
    { type: 'contrast', name: 'High Contrast Punch', defaultVal: 140, desc: 'Crushed blacks and punchy whites' },
    { type: 'hue-rotate', name: 'Hue Spectrum Shift', defaultVal: 90, desc: 'Creative color spectrum rotation' },
    { type: 'chromatic', name: 'Chromatic Aberration', defaultVal: 50, desc: 'RGB lens prism dispersion' },
    { type: 'glitch', name: 'Digital Glitch', defaultVal: 40, desc: 'Randomized band-displacement glitch' },
    { type: 'scanlines', name: 'Retro CRT Scanlines', defaultVal: 60, desc: '90s monitor retro scanlines' },
    { type: 'sharpen', name: 'Unsharp Mask Sharpen', defaultVal: 40, desc: 'Crisp high-frequency detail (heavier to render)' },
    { type: 'sepia', name: 'Vintage Sepia Wash', defaultVal: 75, desc: 'Historical warm photo wash' },
    { type: 'grayscale', name: 'Grayscale', defaultVal: 100, desc: 'Full desaturation, black & white' },
    { type: 'invert', name: 'Invert', defaultVal: 100, desc: 'Negative-film color inversion' },
  ];

  const applyTransition = (tType: TransitionType) => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, {
      transitionIn: { type: tType, duration: 0.8 },
      transitionOut: { type: tType, duration: 0.8 }
    });
  };

  const applyFilter = (filterItem: typeof filterList[0]) => {
    if (!selectedClip) return;
    const existing = selectedClip.filters || [];
    const newFilter: VideoFilter = {
      id: `filter-${Date.now()}`,
      type: filterItem.type,
      name: filterItem.name,
      enabled: true,
      value: filterItem.defaultVal
    };
    onUpdateClip(selectedClip.id, {
      filters: [...existing, newFilter]
    });
  };

  const toggleAppliedFilter = (filterId: string) => {
    if (!selectedClip) return;
    const updated = (selectedClip.filters || []).map(f =>
      f.id === filterId ? { ...f, enabled: !f.enabled } : f
    );
    onUpdateClip(selectedClip.id, { filters: updated });
  };

  const setAppliedFilterValue = (filterId: string, value: number) => {
    if (!selectedClip) return;
    const updated = (selectedClip.filters || []).map(f =>
      f.id === filterId ? { ...f, value } : f
    );
    onUpdateClip(selectedClip.id, { filters: updated });
  };

  const removeAppliedFilter = (filterId: string) => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, {
      filters: (selectedClip.filters || []).filter(f => f.id !== filterId)
    });
  };

  return (
    <div className="h-full flex flex-col bg-[#16161b] text-zinc-200 text-xs select-none">
      {/* Top Header */}
      <div className="h-8 bg-[#1e1e26] border-b border-[#282834] px-3 flex items-center justify-between">
        <div className="flex items-center space-x-1.5">
          <Layers className="w-3.5 h-3.5 text-purple-400" />
          <span className="font-semibold text-zinc-100 text-[11px]">Effects & Transitions</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-[#141418] border-b border-[#242430] p-1 text-[11px]">
        <button
          onClick={() => setActiveCategory('transitions')}
          className={`flex-1 text-center rounded transition-colors ${isMobile ? 'py-2.5' : 'py-1'} ${
            activeCategory === 'transitions' ? 'bg-[#282834] text-purple-400 font-medium' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Video Transitions
        </button>
        <button
          onClick={() => setActiveCategory('filters')}
          className={`flex-1 text-center rounded transition-colors ${isMobile ? 'py-2.5' : 'py-1'} ${
            activeCategory === 'filters' ? 'bg-[#282834] text-purple-400 font-medium' : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          Video Filters & FX
        </button>
      </div>

      <div className="flex-1 p-3 overflow-y-auto space-y-3">
        {activeCategory === 'transitions' ? (
          <div className="space-y-2">
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
              VidCraft Pro Transitions
            </span>
            <div className="grid grid-cols-1 gap-2">
              {transitionList.map(t => {
                const isActive = selectedClip?.transitionIn?.type === t.id;
                return (
                  <div
                    key={t.id}
                    className={`p-2.5 rounded-md border transition-all flex ${isMobile ? 'flex-col space-y-2' : 'items-center justify-between'} ${
                      isActive 
                        ? 'bg-purple-950/30 border-purple-500/60 text-purple-200' 
                        : 'bg-[#1b1b22] border-[#272732] hover:border-[#383848] text-zinc-300'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <span className="text-base">{t.icon}</span>
                      <div>
                        <div className="font-semibold text-xs text-zinc-100">{t.name}</div>
                        <div className="text-[10px] text-zinc-400">{t.desc}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => applyTransition(t.id)}
                      disabled={!selectedClip}
                      className={`bg-purple-600 hover:bg-purple-500 disabled:opacity-30 text-white rounded font-medium flex items-center justify-center space-x-1 ${
                        isMobile ? 'w-full px-3 py-2 text-[11px]' : 'px-2.5 py-1 text-[10px]'
                      }`}
                    >
                      <Plus className="w-3 h-3" />
                      <span>Apply</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {selectedClip && (selectedClip.filters?.length ?? 0) > 0 && (
              <div className="space-y-2">
                <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
                  Applied on "{selectedClip.name}"
                </span>
                <div className="grid grid-cols-1 gap-2">
                  {selectedClip.filters!.map(f => (
                    <div
                      key={f.id}
                      className={`p-2.5 rounded-md border transition-all ${
                        f.enabled ? 'bg-purple-950/20 border-purple-500/40' : 'bg-[#1b1b22] border-[#272732] opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <button
                          onClick={() => toggleAppliedFilter(f.id)}
                          className={`flex items-center space-x-1.5 text-xs font-semibold text-zinc-100 ${isMobile ? 'py-1' : ''}`}
                        >
                          <span className={`rounded-sm border flex items-center justify-center ${isMobile ? 'w-[18px] h-[18px]' : 'w-3.5 h-3.5'} ${f.enabled ? 'bg-purple-500 border-purple-500' : 'border-zinc-500'}`}>
                            {f.enabled && <Check className="w-2.5 h-2.5 text-white" />}
                          </span>
                          <span>{f.name}</span>
                        </button>
                        <button
                          onClick={() => removeAppliedFilter(f.id)}
                          className={`text-red-400 hover:text-red-300 font-medium ${isMobile ? 'text-[11px] p-1' : 'text-[10px]'}`}
                        >
                          Remove
                        </button>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={f.type === 'brightness' || f.type === 'contrast' ? 200 : 100}
                        value={f.value}
                        onChange={(e) => setAppliedFilterValue(f.id, parseFloat(e.target.value))}
                        disabled={!f.enabled}
                        className={`w-full bg-[#2b2b36] rounded appearance-none cursor-pointer accent-purple-500 ${isMobile ? 'h-2 py-2' : 'h-1'}`}
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
              Stylistic Video Filters
            </span>
            <div className="grid grid-cols-1 gap-2">
              {filterList.map(f => (
                <div
                  key={f.type}
                  className={`p-2.5 rounded-md bg-[#1b1b22] border border-[#272732] hover:border-[#383848] transition-all flex ${
                    isMobile ? 'flex-col space-y-2' : 'items-center justify-between'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-xs text-zinc-100">{f.name}</div>
                    <div className="text-[10px] text-zinc-400">{f.desc}</div>
                  </div>

                  <button
                    onClick={() => applyFilter(f)}
                    disabled={!selectedClip}
                    className={`bg-purple-600 hover:bg-purple-500 disabled:opacity-30 text-white rounded font-medium flex items-center justify-center space-x-1 ${
                      isMobile ? 'w-full px-3 py-2 text-[11px]' : 'px-2.5 py-1 text-[10px]'
                    }`}
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Filter</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
