import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { 
  Keyboard, X, Monitor, Folder, Sliders, GalleryHorizontal, 
  History, FolderOpen, Trash2, FileClock 
} from 'lucide-react';
import { 
  HeaderMenuBar 
} from './components/HeaderMenuBar';
import { ProjectMediaBin } from './components/ProjectMediaBin';
import { SourceMonitor } from './components/SourceMonitor';
import { ProgramMonitor } from './components/ProgramMonitor';
import { Timeline } from './components/Timeline';
import { EffectControls } from './components/EffectControls';
import { LumetriColorPanel } from './components/LumetriColorPanel';
import { EssentialGraphicsPanel } from './components/EssentialGraphicsPanel';
import { EffectsLibrary } from './components/EffectsLibrary';
import { AudioMixerPanel } from './components/AudioMixerPanel';
import { ExportModal } from './components/ExportModal';
import { LicensePanel } from './components/LicensePanel';

import { 
  ProjectSettings, WorkspaceType, ActiveTool, Clip, Track, 
  MediaAsset, Marker, TextConfig, LumetriGrade, Keyframe 
} from './types';
import { 
  INITIAL_PROJECT, INITIAL_TRACKS, INITIAL_CLIPS, 
  SAMPLE_ASSETS 
} from './data/sampleMedia';
import { audioEngine } from './utils/audioEngine';
import { videoCompositor } from './utils/videoCompositor';
import { useEditorHistory, describeClipEdit, describeTrackEdit } from './utils/history';
import { getSpeedAdjustedSourceOffset } from './utils/keyframes';
import {
  saveProjectSnapshot, loadProjectSnapshot, listProjectSnapshots, deleteProjectSnapshot,
  getLastOpenedProjectId, saveMediaBlob, loadMediaBlob, isProjectStorageAvailable,
  ProjectSnapshot, ProjectSnapshotMeta
} from './utils/projectStorage';
import type { SaveStatus } from './components/HeaderMenuBar';

// Below this width the desktop 4-column editor layout doesn't fit — switch to
// a single-panel-at-a-time mobile layout with a bottom tab bar instead.
//
// v44 fix: this now checks the *shorter* viewport edge instead of raw
// width. A typical Android phone in landscape is ~800-915px wide — wider
// than the old 768px cutoff — which meant rotating a phone to landscape
// previously fell back to the cramped desktop 4-column layout instead of
// staying in the touch-first single-panel view. Checking the shorter edge
// (height in landscape, width in portrait) classifies a phone as "mobile"
// in both orientations, while a genuinely large screen (tablet/desktop)
// stays on the desktop layout regardless of rotation, since its shorter
// edge is still comfortably above the breakpoint.
function useIsMobile(breakpointPx: number = 768): boolean {
  const getIsMobile = () =>
    typeof window !== 'undefined'
      ? Math.min(window.innerWidth, window.innerHeight) < breakpointPx
      : false;

  const [isMobile, setIsMobile] = useState<boolean>(getIsMobile);

  useEffect(() => {
    // A single query combining width OR height (comma = logical OR in CSS
    // media queries) fires on any resize/rotation that could change which
    // side is shorter — matches the min()-based check above.
    const mq = window.matchMedia(
      `(max-width: ${breakpointPx - 1}px), (max-height: ${breakpointPx - 1}px)`
    );
    const handler = () => setIsMobile(getIsMobile());
    handler();
    mq.addEventListener('change', handler);
    window.addEventListener('orientationchange', handler);
    return () => {
      mq.removeEventListener('change', handler);
      window.removeEventListener('orientationchange', handler);
    };
  }, [breakpointPx]);

  return isMobile;
}

export default function App() {
  // 1. Core Project & Workspace State
  const [project, setProject] = useState<ProjectSettings>(INITIAL_PROJECT);
  const [workspace, setWorkspace] = useState<WorkspaceType>('editing');
  const [activeTool, setActiveTool] = useState<ActiveTool>('select');
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // 2. Timeline & Media State
  const [tracks, setTracks] = useState<Track[]>(INITIAL_TRACKS);
  const [clips, setClips] = useState<Clip[]>(INITIAL_CLIPS);
  const [assets, setAssets] = useState<MediaAsset[]>(SAMPLE_ASSETS);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(INITIAL_CLIPS[0]?.id || null);
  const [activeSourceAsset, setActiveSourceAsset] = useState<MediaAsset | null>(SAMPLE_ASSETS[0] || null);

  // 3. Editor View Controls
  const [zoomLevel, setZoomLevel] = useState<number>(30); // px per second
  const [snapping, setSnapping] = useState<boolean>(true);
  const [masterVolume, setMasterVolume] = useState<number>(1);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);
  const [isLicensePanelOpen, setIsLicensePanelOpen] = useState<boolean>(false);
  const [isShortcutsModalOpen, setIsShortcutsModalOpen] = useState<boolean>(false);
  const isMobile = useIsMobile();
  const [mobilePanel, setMobilePanel] = useState<'preview' | 'media' | 'timeline' | 'tools'>('preview');

  // 4. Undo / Redo History — covers project settings + tracks + clips, not
  // just clips, and coalesces continuous drags/slider input into one step
  // per gesture (see src/utils/history.ts).
  const { recordSnapshot, undo, redo, clearHistory, canUndo, canRedo, undoLabel, redoLabel } = useEditorHistory({
    project, tracks, clips, setProject, setTracks, setClips
  });

  // 5. Offline Project Persistence (IndexedDB — no server, no internet)
  // A stable id for whichever project is currently open. "New Project" and
  // opening/importing a different project reassign this; autosave always
  // writes under whichever id is current.
  const currentProjectIdRef = useRef<string>(`project-${Date.now()}`);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>(isProjectStorageAvailable() ? 'idle' : 'unavailable');
  const [hasHydrated, setHasHydrated] = useState(false);
  const [restorePrompt, setRestorePrompt] = useState<{ id: string; name: string; updatedAt: number } | null>(null);
  const [isProjectManagerOpen, setIsProjectManagerOpen] = useState(false);
  const [savedProjects, setSavedProjects] = useState<ProjectSnapshotMeta[]>([]);
  const saveTimerRef = useRef<number | null>(null);

  // Object URL lifecycle (Step 3 fix): call with the asset(s) that are about
  // to be replaced/discarded — after they've been superseded in state — so
  // any blob: URLs this app created for local imports (ProjectMediaBin's
  // file picker, project-restore, relink) don't outlive the asset they
  // belonged to. The revoke is deferred one tick so React has already
  // committed the *new* assets to every <video>/<img> bound to them before
  // anything old is torn down — revoking synchronously here would race the
  // re-render and could blank a still-visible thumbnail/preview. Remote
  // sample-library URLs (http/https) are untouched — nothing to release.
  const releaseLocalAssetUrls = useCallback((staleAssets: MediaAsset[]) => {
    const stale = staleAssets.filter(a => a.isLocalFile && a.src?.startsWith('blob:'));
    if (stale.length === 0) return;
    setTimeout(() => {
      stale.forEach(a => {
        // Drop the compositor's cached <video>/<img> for this asset first —
        // it holds its own reference to the old src and won't pick up a
        // replacement asset with the same id otherwise (see videoCompositor.ts).
        videoCompositor.disposeAsset(a.id);
        try { URL.revokeObjectURL(a.src); } catch { /* already invalid — safe to ignore */ }
      });
    }, 0);
  }, []);

  // Loads a full project document (from IndexedDB or an imported file) into
  // the editor. Local media is re-linked from its cached bytes where
  // possible; anything missing is flagged so ProjectMediaBin can offer a
  // "Relink" action instead of silently showing a broken video.
  //
  // Step 8: this is the single shared entry point for every restore path
  // (auto-restore prompt, "Open Recent Project", and the imported-file
  // path below), so a minimal validity check lives here once instead of
  // being duplicated per call site — mirrors the existing guard in
  // handleOpenProjectFile. Returns false (and touches no state at all) for
  // a malformed snapshot instead of crashing on `undefined` project/tracks/
  // clips; callers are responsible for telling the user and not getting
  // stuck (see the two call sites below).
  const hydrateFromSnapshot = useCallback(async (snap: ProjectSnapshot): Promise<boolean> => {
    if (!snap || !snap.project || !Array.isArray(snap.tracks) || !Array.isArray(snap.clips)) {
      console.error('Refusing to restore a malformed project snapshot:', snap);
      return false;
    }

    const resolvedAssets = await Promise.all((snap.assets || []).map(async (asset) => {
      if (!asset.isLocalFile) return asset;
      try {
        const stored = await loadMediaBlob(asset.id);
        if (stored) {
          const url = URL.createObjectURL(stored.blob);
          return { ...asset, src: url, thumbnailUrl: asset.type === 'image' ? url : asset.thumbnailUrl, isOfflineMissing: false };
        }
      } catch (err) {
        console.warn('Could not load cached media for asset', asset.id, err);
      }
      return { ...asset, isOfflineMissing: true };
    }));

    const previousAssets = assets; // about to be superseded by the snapshot's own asset list
    currentProjectIdRef.current = snap.id;
    setProject(snap.project);
    setTracks(snap.tracks);
    setClips(snap.clips);
    setAssets(resolvedAssets.length > 0 ? resolvedAssets : SAMPLE_ASSETS);
    setSelectedClipId(snap.clips[0]?.id || null);
    setActiveSourceAsset(resolvedAssets[0] || null);
    clearHistory();
    setHasHydrated(true);
    releaseLocalAssetUrls(previousAssets);
    return true;
  }, [clearHistory, assets, releaseLocalAssetUrls]);

  // On first mount: if a previous session was auto-saved, offer to restore
  // it instead of silently discarding it (or silently overwriting it).
  useEffect(() => {
    if (!isProjectStorageAvailable()) {
      setHasHydrated(true);
      return;
    }
    (async () => {
      try {
        const lastId = await getLastOpenedProjectId();
        if (lastId) {
          const snap = await loadProjectSnapshot(lastId);
          if (snap) {
            setRestorePrompt({ id: snap.id, name: snap.name, updatedAt: snap.updatedAt });
            return;
          }
        }
      } catch (err) {
        console.warn('Offline project storage unavailable:', err);
      }
      setHasHydrated(true);
    })();
  }, []);

  const persistCurrentProject = useCallback(async () => {
    if (!isProjectStorageAvailable()) return;
    try {
      setSaveStatus('saving');
      await saveProjectSnapshot({
        id: currentProjectIdRef.current,
        name: project.name,
        updatedAt: Date.now(),
        project, tracks, clips, assets
      });
      setSaveStatus('saved');
    } catch (err) {
      console.error('Auto-save failed:', err);
      setSaveStatus('dirty');
    }
  }, [project, tracks, clips, assets]);

  // Debounced autosave — waits for a short pause after the last change
  // instead of writing to IndexedDB on every keystroke/slider tick.
  useEffect(() => {
    if (!hasHydrated || !isProjectStorageAvailable()) return;
    setSaveStatus('dirty');
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
    saveTimerRef.current = window.setTimeout(() => { persistCurrentProject(); }, 1500);
    return () => { if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [project, tracks, clips, assets, hasHydrated]);

  // Step 7 — flush a pending autosave before the tab goes away, instead of
  // leaving up to 1.5s of edits sitting in the debounce timer.
  //
  // This is deliberately a ref, updated every render, rather than deps on
  // the two DOM listeners below: it lets the listeners stay registered
  // exactly once (added on mount, removed on unmount — see the next
  // effect) while still always flushing whatever the *latest*
  // project/tracks/clips/assets are, without re-attaching window/document
  // listeners on every keystroke.
  const flushPendingSaveRef = useRef<() => void>(() => {});
  useEffect(() => {
    flushPendingSaveRef.current = () => {
      if (!hasHydrated || !isProjectStorageAvailable()) return;
      // Nothing changed since the last successful write — skip, so this
      // can't produce a duplicate save on top of one that already ran (or
      // is already in flight from the debounce timer itself firing).
      if (saveStatus !== 'dirty') return;
      if (saveTimerRef.current) {
        window.clearTimeout(saveTimerRef.current);
        saveTimerRef.current = null;
      }
      persistCurrentProject();
    };
  }, [hasHydrated, saveStatus, persistCurrentProject]);

  useEffect(() => {
    const flush = () => flushPendingSaveRef.current();
    // 'visibilitychange' → 'hidden' is the most reliable of the lifecycle
    // signals (fires on tab switch, minimize, mobile app-switch, and
    // before most close/refresh/navigate actions) and — unlike
    // 'beforeunload' — doesn't block the back/forward cache. 'pagehide'
    // is kept as a second, final-moment attempt for the actual
    // unload/navigation case. Neither can *guarantee* the asynchronous
    // IndexedDB write below finishes before the page is actually torn
    // down or the process is killed — no browser API promises that for
    // IndexedDB — this only gives it the best available head start
    // instead of waiting out the rest of the debounce window.
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') flush();
    };
    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('pagehide', flush);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pagehide', flush);
    };
  }, []);

  // v43: auto-pause playback when the app is backgrounded (Android home/
  // recent-apps button, app switch, or a browser tab switch). Without this,
  // the playback clock and Program Monitor's render loop (ProgramMonitor.tsx)
  // keep decoding/compositing frames — and audioEngine keeps playing audio —
  // while nothing is visible, which is wasted CPU/GPU/battery on a phone in
  // particular. Purely a lifecycle/performance change: it doesn't touch
  // editing state, and resuming is a normal tap on Play, same as pausing by
  // hand ever did.
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') {
        setIsPlaying(prev => (prev ? false : prev));
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, []);

  // v45: Android hardware back-button handling for full-screen modals.
  //
  // Capacitor's Android bridge has a built-in default for the hardware
  // back button even without any plugin installed: if the WebView's
  // in-page history has a state to go back to, it calls history.back();
  // only if there is none does it fall through to closing the app. Today,
  // this app never pushes any history state, so pressing back — even just
  // to dismiss the Export dialog — closes the whole app immediately. That
  // is almost certainly not what someone meant by a single back-press.
  //
  // Fix: while any full-screen modal is open, push one history entry.
  // A `popstate` (which fires for both the hardware back button and a
  // swipe-back gesture) then closes the modal instead of exiting. If the
  // modal is instead closed normally (its own × / Cancel button), the
  // cleanup below consumes that pushed entry itself via history.back(),
  // so a *later* back press doesn't need to be pressed twice for
  // something already closed. This is plain Web History API — no native
  // plugin, no new dependency — and behaves identically in a desktop
  // browser (closes the modal on Alt+Left / the mouse back button too).
  //
  // NOTE: I do not have Android hardware, an emulator, or network access
  // in this sandbox to actually press a physical back button and confirm
  // this — the above is the documented, standard behavior of Capacitor's
  // bridge and of the History API, but treat it as needing a real-device
  // check before you rely on it, same as everything else in this v45
  // pass that touches native/WebView behavior. See CHANGELOG_v45.md.
  const isAnyModalOpen = isExportModalOpen || isLicensePanelOpen || isShortcutsModalOpen || isProjectManagerOpen;
  useEffect(() => {
    if (!isAnyModalOpen) return;

    window.history.pushState({ vidcraftModalGuard: true }, '');
    let closedViaPopState = false;

    const handlePopState = () => {
      closedViaPopState = true;
      setIsExportModalOpen(false);
      setIsLicensePanelOpen(false);
      setIsShortcutsModalOpen(false);
      setIsProjectManagerOpen(false);
    };
    window.addEventListener('popstate', handlePopState);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      if (!closedViaPopState) {
        window.history.back();
      }
    };
  }, [isAnyModalOpen]);

  // C2 fix: release cached <video>/<img> elements for assets that are no
  // longer part of the current asset collection (new project, switching to
  // a different opened project, etc.). `assets` only ever grows or is
  // wholesale-replaced together with `clips` in the same handler (there is
  // no per-asset "remove from bin" action today), so "still present in
  // `assets`" is always a safe superset of what any clip could reference —
  // this can't dispose something the current project still needs.
  // Deliberately NOT run inside the render loop/rAF — this only needs to
  // react to the asset collection itself changing.
  useEffect(() => {
    videoCompositor.pruneUnusedAssets(new Set(assets.map(a => a.id)));
  }, [assets]);

  // Step 4 Part 2: same idea as the C2 fix above, but for cached audio
  // resources (audioEngine.ts pools <audio> elements per clip id). Keyed off
  // a stable "which clip ids currently exist" signature rather than `clips`
  // itself — dragging/resizing/trimming a clip updates `clips` on every
  // pointermove but never changes which ids exist, so this avoids re-running
  // the prune check on every drag-frame tick and only fires when a clip is
  // actually added/removed or the whole project is switched.
  const clipIdsSignature = useMemo(() => clips.map(c => c.id).sort().join(','), [clips]);
  useEffect(() => {
    audioEngine.pruneUnusedClips(new Set(clips.map(c => c.id)));
    // clipIdsSignature is the intentional dependency (see comment above);
    // `clips` itself is read fresh inside the effect each time it does run.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clipIdsSignature]);

  const handleNewProject = () => {
    if (clips.length > 0 && !window.confirm('একটি নতুন প্রজেক্ট শুরু করবেন? বর্তমান প্রজেক্ট ইতিমধ্যে এই ডিভাইসে সেভ করা আছে, পরে "Open Recent Project" থেকে ফিরে আসতে পারবেন।')) {
      return;
    }
    const previousAssets = assets; // about to be replaced by the fresh sample library
    currentProjectIdRef.current = `project-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setProject({ ...INITIAL_PROJECT, name: 'Untitled Project', duration: 10, markers: [] });
    setTracks(INITIAL_TRACKS.map(t => ({ ...t })));
    setClips([]);
    setAssets(SAMPLE_ASSETS);
    setSelectedClipId(null);
    setActiveSourceAsset(SAMPLE_ASSETS[0] || null);
    clearHistory();
    releaseLocalAssetUrls(previousAssets);
  };

  const handleSaveProject = () => { persistCurrentProject(); };

  const handleSaveProjectAs = () => {
    const data: ProjectSnapshot = {
      id: currentProjectIdRef.current,
      name: project.name,
      updatedAt: Date.now(),
      project, tracks, clips, assets
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(project.name || 'vidcraft-project').replace(/[^a-z0-9\-_]+/gi, '_')}.vidcraftproj.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleOpenProjectFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result as string) as ProjectSnapshot;
        if (!data.project || !data.tracks || !data.clips) throw new Error('Invalid project file');
        hydrateFromSnapshot(data);
      } catch (err) {
        window.alert('এই ফাইলটি একটি বৈধ VidCraft Pro প্রজেক্ট ফাইল বলে মনে হচ্ছে না।');
      }
    };
    reader.readAsText(file);
  };

  const handleOpenProjectManager = async () => {
    try {
      setSavedProjects(await listProjectSnapshots());
    } catch (err) {
      setSavedProjects([]);
    }
    setIsProjectManagerOpen(true);
  };

  const handleOpenSavedProject = async (id: string) => {
    const snap = await loadProjectSnapshot(id);
    const ok = snap ? await hydrateFromSnapshot(snap) : false;
    if (!ok) {
      window.alert('এই সংরক্ষিত প্রজেক্টটি খোলা যায়নি — ফাইলটি করাপ্টেড বা অসম্পূর্ণ বলে মনে হচ্ছে।');
    }
    setIsProjectManagerOpen(false);
  };

  const handleDeleteSavedProject = async (id: string) => {
    await deleteProjectSnapshot(id);
    setSavedProjects(prev => prev.filter(p => p.id !== id));
  };

  const handleAddAsset = (newAsset: MediaAsset, file?: File) => {
    setAssets(a => [newAsset, ...a]);
    if (file && newAsset.isLocalFile) {
      saveMediaBlob(newAsset.id, file, newAsset.name, file.type)
        .catch(err => console.warn('Could not cache media for offline use:', err));
    }
  };

  const handleRelinkAsset = (assetId: string, file: File) => {
    const url = URL.createObjectURL(file);
    const previousAsset = assets.find(a => a.id === assetId);
    setAssets(prev => prev.map(a => a.id === assetId
      ? { ...a, src: url, isLocalFile: true, isOfflineMissing: false, thumbnailUrl: a.type === 'image' ? url : a.thumbnailUrl }
      : a
    ));
    // Source Monitor holds its own copy of the active asset (not a live
    // lookup into `assets`), so if the relinked asset is the one currently
    // previewed, it needs the same update or it'd keep showing/pointing at
    // the old (about-to-be-revoked) URL.
    setActiveSourceAsset(prev => (prev && prev.id === assetId)
      ? { ...prev, src: url, isLocalFile: true, isOfflineMissing: false, thumbnailUrl: prev.type === 'image' ? url : prev.thumbnailUrl }
      : prev
    );
    saveMediaBlob(assetId, file, file.name, file.type)
      .catch(err => console.warn('Could not cache relinked media:', err));
    if (previousAsset) releaseLocalAssetUrls([previousAsset]);
  };

  // Playback Toggle
  const togglePlay = useCallback(() => {
    setIsPlaying(prev => {
      const next = !prev;
      if (next && currentTime >= project.duration) {
        setCurrentTime(0);
      }
      return next;
    });
  }, [currentTime, project.duration]);

  // Global Time Increment during Playback Loop
  useEffect(() => {
    let animFrame: number;
    let lastTime = performance.now();

    const loop = (now: number) => {
      if (isPlaying) {
        const delta = (now - lastTime) / 1000;
        setCurrentTime(t => {
          const next = t + delta;
          if (next >= project.duration) {
            setIsPlaying(false);
            return project.duration;
          }
          return next;
        });
      }
      lastTime = now;
      animFrame = requestAnimationFrame(loop);
    };

    animFrame = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrame);
  }, [isPlaying, project.duration]);

  // Clip Modification Helpers
  const handleUpdateClip = (clipId: string, updates: Partial<Clip>) => {
    recordSnapshot(describeClipEdit(updates));
    setClips(prevClips => {
      const updated = prevClips.map(c => c.id === clipId ? { ...c, ...updates } : c);
      return updated;
    });
  };

  // Adds/overwrites a keyframe for an animatable property at the current playhead
  // position (converted to clip-relative time), using the property's live value.
  const handleAddKeyframe = (clipId: string, property: Keyframe['property']) => {
    const clip = clips.find(c => c.id === clipId);
    if (!clip) return;

    const timeFromStart = Math.max(0, Math.min(clip.duration, currentTime - clip.startTime));
    const currentValue = property === 'volume'
      ? (clip.audioConfig?.volume ?? 1)
      : property === 'speed'
      ? (clip.speed ?? 1)
      : (clip[property] as number);

    const existing = clip.keyframes || [];
    // Overwrite any keyframe already sitting at ~this instant for this property
    // instead of stacking duplicates every time the button is clicked.
    const filtered = existing.filter(k => !(k.property === property && Math.abs(k.time - timeFromStart) < 0.05));
    const newKeyframe: Keyframe = {
      id: `kf-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      time: timeFromStart,
      property,
      value: currentValue
    };

    handleUpdateClip(clipId, { keyframes: [...filtered, newKeyframe] });
  };

  const handleDeleteClip = (clipId: string) => {
    recordSnapshot('Delete Clip');
    setClips(prev => {
      const deletedClip = prev.find(c => c.id === clipId);
      const remaining = prev.filter(c => c.id !== clipId);
      if (!deletedClip || activeTool !== 'ripple-edit') return remaining;

      // Ripple Delete: close the gap by shifting every later clip on the
      // same track left by the deleted clip's duration. Same track-scoped,
      // startTime-based boundary check (with the same float epsilon) as
      // the existing Ripple Trim follower lookup in Timeline.tsx.
      const shiftAmount = deletedClip.duration;
      return remaining.map(c =>
        c.trackId === deletedClip.trackId && c.startTime > deletedClip.startTime + 0.01
          ? { ...c, startTime: Math.max(0, c.startTime - shiftAmount) }
          : c
      );
    });
    if (selectedClipId === clipId) {
      setSelectedClipId(null);
    }
  };

  const handleUpdateTrack = (trackId: string, updates: Partial<Track>) => {
    recordSnapshot(describeTrackEdit(updates));
    setTracks(prev => prev.map(t => t.id === trackId ? { ...t, ...updates } : t));
  };

  const handleAddTrack = (type: 'video' | 'audio') => {
    recordSnapshot('Add Track');
    const trackNum = tracks.filter(t => t.type === type).length + 1;
    const newTrack: Track = {
      id: `track-${type[0]}${trackNum}-${Date.now().toString(36)}`,
      name: `${type.toUpperCase()} ${trackNum}`,
      type: type,
      index: tracks.length,
      isLocked: false,
      isMuted: false,
      isSolo: false,
      isVisible: true,
      volume: 1,
      pan: 0,
      height: 48
    };
    setTracks(t => [...t, newTrack]);
  };

  // Add Asset to Timeline
  const handleAddAssetToTimeline = (asset: MediaAsset, startTime?: number) => {
    const isAudio = asset.type === 'audio';
    const targetTrack = tracks.find(t => isAudio ? t.type === 'audio' : t.type === 'video');
    if (!targetTrack) return;

    const start = startTime !== undefined ? startTime : currentTime;
    const duration = asset.duration || 5;

    const newClip: Clip = {
      id: `clip-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      assetId: asset.id,
      trackId: targetTrack.id,
      type: asset.type,
      name: asset.name,
      startTime: start,
      duration: duration,
      inPoint: 0,
      outPoint: duration,
      sourceDuration: duration,
      positionX: 0,
      positionY: 0,
      scale: 100,
      rotation: 0,
      opacity: 100,
      blendMode: 'normal',
      color: isAudio ? '#059669' : '#0284c7',
      lumetri: {
        temperature: 0,
        tint: 0,
        exposure: 0,
        contrast: 0,
        highlights: 0,
        shadows: 0,
        whites: 0,
        blacks: 0,
        saturation: 100,
        vibrance: 0,
        vignette: 0,
        liftColor: '#000000',
        gammaColor: '#808080',
        gainColor: '#ffffff',
      },
      filters: [],
      transitionIn: { type: 'cross-dissolve', duration: 0.6 },
      transitionOut: { type: 'cross-dissolve', duration: 0.6 },
      audioConfig: { volume: 1, pan: 0, mute: false }
    };

    recordSnapshot('Add Clip');
    setClips(prev => [...prev, newClip]);
    setSelectedClipId(newClip.id);
  };

  // Add Text Title Clip to Timeline
  const handleAddTextClipToTimeline = (textConfig: TextConfig, startTime?: number, customDuration?: number) => {
    const titleTrack = tracks.find(t => t.id === 'track-v3') || tracks.find(t => t.type === 'video');
    if (!titleTrack) return;

    const start = startTime !== undefined ? startTime : currentTime;
    const dur = customDuration || 4;

    const newClip: Clip = {
      id: `title-clip-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      assetId: 'asset-text',
      trackId: titleTrack.id,
      type: 'text',
      name: `Title: ${textConfig.text.substring(0, 16)}`,
      startTime: start,
      duration: dur,
      inPoint: 0,
      outPoint: dur,
      sourceDuration: 10,
      positionX: 0,
      positionY: 120,
      scale: 100,
      rotation: 0,
      opacity: 100,
      blendMode: 'normal',
      color: '#d97706',
      lumetri: {
        temperature: 0,
        tint: 0,
        exposure: 0,
        contrast: 0,
        highlights: 0,
        shadows: 0,
        whites: 0,
        blacks: 0,
        saturation: 100,
        vibrance: 0,
        vignette: 0,
        liftColor: '#000000',
        gammaColor: '#808080',
        gainColor: '#ffffff',
      },
      filters: [],
      textConfig: textConfig,
      transitionIn: { type: 'cross-dissolve', duration: 0.5 },
      transitionOut: { type: 'cross-dissolve', duration: 0.5 }
    };

    recordSnapshot('Add Title');
    setClips(prev => [...prev, newClip]);
    setSelectedClipId(newClip.id);
  };

  // Source Monitor Insert & Overwrite
  const handleSourceInsert = (asset: MediaAsset, inP: number, outP: number) => {
    const isAudio = asset.type === 'audio';
    const targetTrack = tracks.find(t => isAudio ? t.type === 'audio' : t.type === 'video');
    if (!targetTrack) return;

    const clipDur = Math.max(0.5, outP - inP);
    const newClip: Clip = {
      id: `clip-src-${Date.now()}`,
      assetId: asset.id,
      trackId: targetTrack.id,
      type: asset.type,
      name: `${asset.name} (Subclip)`,
      startTime: currentTime,
      duration: clipDur,
      inPoint: inP,
      outPoint: outP,
      sourceDuration: asset.duration || 10,
      positionX: 0,
      positionY: 0,
      scale: 100,
      rotation: 0,
      opacity: 100,
      blendMode: 'normal',
      color: isAudio ? '#059669' : '#0284c7',
      lumetri: {
        temperature: 0,
        tint: 0,
        exposure: 0,
        contrast: 0,
        highlights: 0,
        shadows: 0,
        whites: 0,
        blacks: 0,
        saturation: 100,
        vibrance: 0,
        vignette: 0,
        liftColor: '#000000',
        gammaColor: '#808080',
        gainColor: '#ffffff',
      },
      filters: [],
      transitionIn: { type: 'cross-dissolve', duration: 0.6 },
      transitionOut: { type: 'cross-dissolve', duration: 0.6 }
    };

    recordSnapshot('Insert Clip');
    setClips(prev => [...prev, newClip]);
    setSelectedClipId(newClip.id);
    setCurrentTime(c => c + clipDur);
  };

  // Markers
  const handleAddMarker = (time: number) => {
    const newMarker: Marker = {
      id: `marker-${Date.now()}`,
      time: time,
      color: '#f59e0b',
      label: `Marker at ${time.toFixed(1)}s`
    };
    recordSnapshot('Add Marker');
    setProject(p => ({
      ...p,
      markers: [...(p.markers || []), newMarker]
    }));
  };

  // Take Snapshot Frame
  const handleTakeSnapshot = () => {
    const canvas = document.querySelector('canvas');
    if (canvas) {
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `snapshot_${project.name}_${currentTime.toFixed(2)}s.png`;
      a.click();
    }
  };

  // Split Clip at Current Playhead (Razor split / Ctrl+K)
  //
  // The actual split math lives in splitClipAtTime() below so the Razor
  // tool's click-to-split (Timeline.tsx → onSplitClipAtTime) can reuse the
  // exact same speed-aware source offset + keyframe re-basing instead of a
  // second, drifting copy of this logic.
  const splitClipAtTime = (targetClip: Clip, splitTimelineTime: number) => {
    const splitOffset = splitTimelineTime - targetClip.startTime;
    if (splitOffset <= 0.1 || splitOffset >= targetClip.duration - 0.1) return;

    // splitOffset is a TIMELINE-time delta. inPoint/outPoint are SOURCE-time,
    // so for a clip with speed != 1 (or a keyframed speed ramp) they don't
    // move 1:1 with splitOffset — reuse the same speed-integration helper
    // the audio/video playback path already uses, instead of assuming 1x.
    const sourceOffsetAtSplit = getSpeedAdjustedSourceOffset(targetClip, splitOffset);

    // Keyframe `time` is seconds relative to the clip's own start (see
    // types.ts). Split it the same way: a keyframe before the split point
    // stays with the left half untouched; one at/after it moves to the
    // right half with the split offset subtracted, so the right clip's
    // own frame 0 lines up with the playhead, matching its new startTime.
    const sourceKeyframes = targetClip.keyframes ?? [];
    const leftKeyframes = sourceKeyframes.filter(k => k.time < splitOffset);
    const rightKeyframes = sourceKeyframes
      .filter(k => k.time >= splitOffset)
      .map(k => ({ ...k, time: k.time - splitOffset }));

    const firstHalf: Clip = {
      ...targetClip,
      id: `clip-split-${Date.now()}-1`,
      duration: splitOffset,
      outPoint: targetClip.inPoint + sourceOffsetAtSplit,
      keyframes: leftKeyframes
    };

    const secondHalf: Clip = {
      ...targetClip,
      id: `clip-split-${Date.now()}-2`,
      startTime: splitTimelineTime,
      duration: targetClip.duration - splitOffset,
      inPoint: targetClip.inPoint + sourceOffsetAtSplit,
      keyframes: rightKeyframes
    };

    const updatedClips = clips.filter(c => c.id !== targetClip.id).concat([firstHalf, secondHalf]);
    recordSnapshot('Split Clip');
    setClips(updatedClips);
    setSelectedClipId(secondHalf.id);
  };

  const handleSplitAtPlayhead = () => {
    const targetClip = clips.find(c => c.id === selectedClipId && currentTime > c.startTime && currentTime < c.startTime + c.duration)
      || clips.find(c => currentTime > c.startTime && currentTime < c.startTime + c.duration);
    
    if (!targetClip) return;
    splitClipAtTime(targetClip, currentTime);
  };

  // Razor Tool (C): click-to-split at an arbitrary timeline position. The
  // click can land on any clip regardless of selection/playhead, so this
  // takes the clip id + clicked time explicitly rather than reading
  // `currentTime` like the shortcut above does.
  const handleSplitClipAtTime = (clipId: string, splitTimelineTime: number) => {
    const targetClip = clips.find(c => c.id === clipId);
    if (!targetClip) return;
    splitClipAtTime(targetClip, splitTimelineTime);
  };

  // Add Default Cinematic Title Clip
  const handleNewTextClip = () => {
    handleAddTextClipToTimeline({
      text: 'CINEMATIC TITLE',
      fontSize: 44,
      fontFamily: 'Plus Jakarta Sans',
      color: '#ffffff',
      backgroundColor: 'rgba(0,0,0,0.6)',
      align: 'center',
      animation: 'slide-up'
    });
  };

  // Keyboard Shortcuts (NLE Industry Standard)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if typing inside input, textarea, or select
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if ((e.metaKey || e.ctrlKey) && (e.key === 's' || e.key === 'S')) {
        e.preventDefault();
        handleSaveProject();
      } else if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        handleSplitAtPlayhead();
      } else if (e.key === 'v' || e.key === 'V') {
        setActiveTool('select');
      } else if (e.key === 'c' || e.key === 'C') {
        setActiveTool('razor');
      } else if (e.key === 'a' || e.key === 'A') {
        setActiveTool('track-select');
      } else if (e.key === 'b' || e.key === 'B') {
        setActiveTool('ripple-edit');
      } else if (e.key === 'h' || e.key === 'H') {
        setActiveTool('hand');
      } else if (e.key === 'z' || e.key === 'Z') {
        if (e.metaKey || e.ctrlKey) {
          if (e.shiftKey) {
            redo();
          } else {
            undo();
          }
        } else {
          setActiveTool('zoom');
        }
      } else if (e.key === 'y' && (e.metaKey || e.ctrlKey)) {
        redo();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        if (selectedClipId) {
          handleDeleteClip(selectedClipId);
        }
      } else if (e.key === 'm' || e.key === 'M') {
        handleAddMarker(currentTime);
      } else if (e.key === 'ArrowLeft' || e.key === 'j' || e.key === 'J') {
        setCurrentTime(t => Math.max(0, t - 1 / project.fps));
      } else if (e.key === 'ArrowRight' || e.key === 'l' || e.key === 'L') {
        setCurrentTime(t => Math.min(project.duration, t + 1 / project.fps));
      } else if (e.key === 'k' || e.key === 'K') {
        setIsPlaying(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [togglePlay, selectedClipId, clips, currentTime, project.fps, project.duration]);

  const selectedClip = clips.find(c => c.id === selectedClipId) || null;

  // Shared panel content — reused by both the desktop column layout and the
  // mobile single-panel view, so the two stay in sync automatically.
  const leftPanelContent = (
    <>
      {workspace === 'editing' && (
        <ProjectMediaBin
          assets={assets}
          onAddAsset={handleAddAsset}
          onSelectSourceAsset={(asset) => setActiveSourceAsset(asset)}
          onAddAssetToTimeline={(asset) => handleAddAssetToTimeline(asset)}
          onRelinkAsset={handleRelinkAsset}
          activeSourceAssetId={activeSourceAsset?.id}
          isMobile={isMobile}
        />
      )}

      {workspace === 'color' && (
        <LumetriColorPanel
          selectedClip={selectedClip}
          onUpdateClip={handleUpdateClip}
          isMobile={isMobile}
        />
      )}

      {workspace === 'effects' && (
        <EffectsLibrary
          selectedClip={selectedClip}
          onUpdateClip={handleUpdateClip}
          isMobile={isMobile}
        />
      )}

      {workspace === 'graphics' && (
        <EssentialGraphicsPanel
          selectedClip={selectedClip}
          onUpdateClip={handleUpdateClip}
          onAddTextClipToTimeline={handleAddTextClipToTimeline}
          isMobile={isMobile}
        />
      )}

      {workspace === 'audio' && (
        <AudioMixerPanel
          tracks={tracks}
          onUpdateTrack={handleUpdateTrack}
          masterVolume={masterVolume}
          setMasterVolume={setMasterVolume}
          isPlaying={isPlaying}
          isMobile={isMobile}
        />
      )}
    </>
  );

  const programMonitorElement = (
    <ProgramMonitor
      project={project}
      setProject={setProject}
      currentTime={currentTime}
      setCurrentTime={setCurrentTime}
      isPlaying={isPlaying}
      onTogglePlay={togglePlay}
      clips={clips}
      tracks={tracks}
      assets={assets}
      selectedClipId={selectedClipId}
      onAddMarker={handleAddMarker}
      onTakeSnapshot={handleTakeSnapshot}
    />
  );

  const sourceMonitorElement = (
    <SourceMonitor
      asset={activeSourceAsset}
      fps={project.fps}
      onInsertToTimeline={handleSourceInsert}
      onOverwriteToTimeline={handleSourceInsert}
    />
  );

  const effectControlsElement = (
    <EffectControls
      selectedClip={selectedClip}
      onUpdateClip={handleUpdateClip}
      onAddKeyframe={handleAddKeyframe}
      isMobile={isMobile}
    />
  );

  const timelineElement = (
    <Timeline
      project={project}
      currentTime={currentTime}
      setCurrentTime={setCurrentTime}
      isPlaying={isPlaying}
      onTogglePlay={togglePlay}
      tracks={tracks}
      clips={clips}
      onUpdateClips={setClips}
      onBeginClipEdit={recordSnapshot}
      selectedClipId={selectedClipId}
      onSelectClip={(id) => setSelectedClipId(id)}
      activeTool={activeTool}
      setActiveTool={setActiveTool}
      zoomLevel={zoomLevel}
      setZoomLevel={setZoomLevel}
      snapping={snapping}
      setSnapping={setSnapping}
      onDeleteClip={handleDeleteClip}
      onUpdateTrack={handleUpdateTrack}
      onAddTrack={handleAddTrack}
      onSplitClipAtTime={handleSplitClipAtTime}
      isMobile={isMobile}
    />
  );

  const mobileTabs: { id: 'preview' | 'media' | 'timeline' | 'tools'; label: string; icon: typeof Monitor }[] = [
    { id: 'preview', label: 'Preview', icon: Monitor },
    { id: 'media', label: 'Media', icon: Folder },
    { id: 'timeline', label: 'Timeline', icon: GalleryHorizontal },
    { id: 'tools', label: 'Tools', icon: Sliders },
  ];

  return (
    <div className="safe-x flex flex-col h-screen w-screen bg-[#121216] text-zinc-100 overflow-hidden font-sans select-none">
      {/* 1. VidCraft Pro Top Application Bar */}
      <HeaderMenuBar
        project={project}
        setProject={setProject}
        workspace={workspace}
        setWorkspace={setWorkspace}
        currentTime={currentTime}
        isPlaying={isPlaying}
        onTogglePlay={togglePlay}
        onUndo={undo}
        onRedo={redo}
        canUndo={canUndo}
        canRedo={canRedo}
        undoLabel={undoLabel}
        redoLabel={redoLabel}
        snapping={snapping}
        setSnapping={setSnapping}
        onOpenExport={() => setIsExportModalOpen(true)}
        onOpenLicensePanel={() => setIsLicensePanelOpen(true)}
        onOpenShortcuts={() => setIsShortcutsModalOpen(true)}
        onNewTextClip={handleNewTextClip}
        onSplitAtPlayhead={handleSplitAtPlayhead}
        onNewProject={handleNewProject}
        onSaveProject={handleSaveProject}
        onSaveProjectAs={handleSaveProjectAs}
        onOpenProjectFile={handleOpenProjectFile}
        onOpenProjectManager={handleOpenProjectManager}
        saveStatus={saveStatus}
        isMobile={isMobile}
      />

      {/* 2 & 3. Editor Workspace — desktop keeps the classic 4-column layout;
           mobile switches to one full-screen panel at a time via the tab bar
           below, since fixed-width columns don't fit on a phone screen. */}
      {!isMobile && (
        <>
          {/* 2. Main Middle Workspace Area (Adaptive by Workspace) */}
          <div className="flex-1 flex overflow-hidden border-b border-[#282834]">
            {/* Left-Hand Column: Media Bin / Effects / Effect Controls */}
            <div className="w-[340px] lg:w-[380px] h-full flex flex-col border-r border-[#262632] bg-[#16161b] shrink-0">
              {leftPanelContent}
            </div>

            {/* Center-Left: Source Monitor (In/Out Trims & Raw Preview) */}
            <div className="w-[360px] lg:w-[420px] h-full hidden md:flex flex-col border-r border-[#262632] shrink-0">
              {sourceMonitorElement}
            </div>

            {/* Center-Right: Program Monitor (Main Live Output Compositor) */}
            <div className="flex-1 h-full flex flex-col min-w-0 bg-[#09090c]">
              {programMonitorElement}
            </div>

            {/* Far-Right Column: Contextual Inspector / Effect Controls */}
            <div className="w-[300px] lg:w-[340px] h-full hidden xl:flex flex-col border-l border-[#262632] bg-[#16161b] shrink-0">
              {effectControlsElement}
            </div>
          </div>

          {/* 3. Bottom Non-Linear Multi-Track Timeline & Tool Palette */}
          <div className="h-[280px] lg:h-[320px] w-full shrink-0">
            {timelineElement}
          </div>
        </>
      )}

      {isMobile && (
        <>
          {/* Mobile: exactly one panel fills the space, switched via the
              bottom tab bar so nothing is ever hidden or unreachable. */}
          <div className="flex-1 flex flex-col overflow-hidden min-h-0 bg-[#09090c]">
            {mobilePanel === 'preview' && (
              <div className="flex-1 flex flex-col min-h-0">{programMonitorElement}</div>
            )}
            {mobilePanel === 'media' && (
              <div className="flex-1 flex flex-col min-h-0 bg-[#16161b] overflow-y-auto">{leftPanelContent}</div>
            )}
            {mobilePanel === 'timeline' && (
              <div className="flex-1 flex flex-col min-h-0">{timelineElement}</div>
            )}
            {mobilePanel === 'tools' && (
              <div className="flex-1 flex flex-col min-h-0 overflow-y-auto divide-y divide-[#262632]">
                <div className="min-h-[45%] flex flex-col">{sourceMonitorElement}</div>
                <div className="min-h-[45%] flex flex-col">{effectControlsElement}</div>
              </div>
            )}
          </div>

          {/* Bottom Tab Bar — extra bottom padding respects the gesture bar /
              home indicator safe area on real phones (Capacitor build). */}
          <div
            className="min-h-14 w-full shrink-0 bg-[#141416] border-t border-[#27272e] flex items-stretch"
            style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
          >
            {mobileTabs.map(tab => {
              const Icon = tab.icon;
              const isActive = mobilePanel === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setMobilePanel(tab.id)}
                  className={`flex-1 flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium ${
                    isActive ? 'text-sky-400' : 'text-zinc-500'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </>
      )}

      {/* 4. Export & Render Modal */}
      <ExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
        project={project}
        clips={clips}
        tracks={tracks}
        assets={assets}
        isMobile={isMobile}
      />

      <LicensePanel
        isOpen={isLicensePanelOpen}
        onClose={() => setIsLicensePanelOpen(false)}
      />

      {/* 5. Keyboard Shortcuts Quick Reference Modal */}
      {isShortcutsModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1e1e24] border border-[#383848] rounded-xl shadow-2xl max-w-lg w-full p-6 text-zinc-200">
            <div className="flex items-center justify-between pb-4 border-b border-[#2c2c38]">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-sky-500/20 text-sky-400 rounded-lg">
                  <Keyboard className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-base">VidCraft Pro Shortcuts</h3>
                  <p className="text-xs text-zinc-400">Industry-standard non-linear editing hotkeys</p>
                </div>
              </div>
              <button 
                onClick={() => setIsShortcutsModalOpen(false)}
                className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-4 text-xs">
              <div className="p-2.5 bg-[#141418] rounded-lg border border-[#272733] space-y-1.5">
                <div className="text-[10px] font-bold tracking-wider text-sky-400 uppercase">Transport & Edit</div>
                <div className="flex justify-between"><span>Play / Pause</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">Space</kbd></div>
                <div className="flex justify-between"><span>Split at Playhead</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">Ctrl/⌘+K</kbd></div>
                <div className="flex justify-between"><span>Prev Frame / J</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">← or J</kbd></div>
                <div className="flex justify-between"><span>Next Frame / L</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">→ or L</kbd></div>
                <div className="flex justify-between"><span>Stop</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">K</kbd></div>
                <div className="flex justify-between"><span>Add Marker</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">M</kbd></div>
                <div className="flex justify-between"><span>Save Project</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">Ctrl/⌘+S</kbd></div>
              </div>

              <div className="p-2.5 bg-[#141418] rounded-lg border border-[#272733] space-y-1.5">
                <div className="text-[10px] font-bold tracking-wider text-amber-400 uppercase">Tools & Edit</div>
                <div className="flex justify-between"><span>Selection Tool</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">V</kbd></div>
                <div className="flex justify-between"><span>Razor Tool</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">C</kbd></div>
                <div className="flex justify-between"><span>Track Select</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">A</kbd></div>
                <div className="flex justify-between"><span>Ripple Edit</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">B</kbd></div>
                <div className="flex justify-between"><span>Hand Tool</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">H</kbd></div>
                <div className="flex justify-between"><span>Undo / Redo</span><kbd className="px-1.5 py-0.5 bg-[#252530] rounded text-zinc-300 font-mono">⌘Z / ⌘Y</kbd></div>
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setIsShortcutsModalOpen(false)}
                className="px-4 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-medium transition-colors shadow-md"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. Restore Last Session Prompt — shown once on load when this
          device has an auto-saved project from a previous visit. */}
      {restorePrompt && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1e1e24] border border-[#383848] rounded-xl shadow-2xl max-w-sm w-full p-5 text-zinc-200">
            <div className="flex items-center space-x-2 pb-3 border-b border-[#2c2c38]">
              <div className="p-2 bg-sky-500/20 text-sky-400 rounded-lg">
                <FileClock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-white text-sm">আগের কাজ ফিরিয়ে আনবেন?</h3>
                <p className="text-[11px] text-zinc-400">এই ডিভাইসে একটি সংরক্ষিত প্রজেক্ট পাওয়া গেছে</p>
              </div>
            </div>
            <div className="mt-3 p-2.5 bg-[#141418] rounded-lg border border-[#272733]">
              <div className="text-xs font-medium text-zinc-100 truncate">{restorePrompt.name}</div>
              <div className="text-[10px] text-zinc-500 mt-0.5">
                সর্বশেষ সেভ: {new Date(restorePrompt.updatedAt).toLocaleString('bn-BD')}
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <button
                onClick={() => { setRestorePrompt(null); setHasHydrated(true); }}
                className="flex-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#27272e] hover:bg-[#32323c] text-zinc-300 transition-colors"
              >
                নতুন শুরু করুন
              </button>
              <button
                onClick={async () => {
                  const snap = await loadProjectSnapshot(restorePrompt.id);
                  const ok = snap ? await hydrateFromSnapshot(snap) : false;
                  if (!ok) {
                    // Don't leave the app stuck on the restore prompt forever —
                    // fall back to whatever's already loaded (the fresh/default
                    // project) and let the person know why.
                    setHasHydrated(true);
                    window.alert('আগের প্রজেক্টটি রিস্টোর করা যায়নি — এটি করাপ্টেড বলে মনে হচ্ছে। নতুন প্রজেক্ট দিয়ে শুরু হচ্ছে।');
                  }
                  setRestorePrompt(null);
                }}
                className="flex-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white shadow-md transition-colors"
              >
                ফিরিয়ে আনুন
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. Open Recent Project Modal — lists every project auto-saved on
          this device (one per "New Project" session started here). */}
      {isProjectManagerOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1e1e24] border border-[#383848] rounded-xl shadow-2xl max-w-md w-full p-5 text-zinc-200 max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-[#2c2c38] shrink-0">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-sky-500/20 text-sky-400 rounded-lg">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-sm">Open Recent Project</h3>
                  <p className="text-[11px] text-zinc-400">এই ডিভাইসে সংরক্ষিত প্রজেক্টসমূহ</p>
                </div>
              </div>
              <button
                onClick={() => setIsProjectManagerOpen(false)}
                className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-3 overflow-y-auto space-y-1.5">
              {savedProjects.length === 0 ? (
                <div className="py-8 flex flex-col items-center text-zinc-500 text-center">
                  <FolderOpen className="w-6 h-6 mb-1 opacity-50" />
                  <span className="text-[11px]">এখনো কোনো প্রজেক্ট সংরক্ষিত হয়নি</span>
                </div>
              ) : (
                savedProjects.map(p => (
                  <div
                    key={p.id}
                    className={`p-2.5 rounded-lg border flex items-center justify-between gap-2 ${
                      p.id === currentProjectIdRef.current
                        ? 'border-sky-500/50 bg-sky-950/30'
                        : 'border-[#272733] bg-[#141418] hover:border-[#3d3d4e]'
                    }`}
                  >
                    <button
                      onClick={() => handleOpenSavedProject(p.id)}
                      className="flex-1 text-left min-w-0"
                    >
                      <div className="text-xs font-medium text-zinc-100 truncate">{p.name}</div>
                      <div className="text-[10px] text-zinc-500 mt-0.5">
                        {p.clipCount} clips • {p.trackCount} tracks • {new Date(p.updatedAt).toLocaleString('bn-BD')}
                      </div>
                    </button>
                    <button
                      onClick={() => handleDeleteSavedProject(p.id)}
                      title="Delete this saved project"
                      className="p-1.5 rounded text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="mt-4 flex justify-end shrink-0">
              <button
                onClick={() => setIsProjectManagerOpen(false)}
                className="px-4 py-1.5 bg-[#27272e] hover:bg-[#32323c] text-zinc-300 rounded-lg text-xs font-medium transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
