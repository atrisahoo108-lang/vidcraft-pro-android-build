# VidCraft Pro — v7 Update: Undo/Redo + Offline Project Save/Load

Focus of this pass (as requested): make Undo/Redo cover the whole editor
(not just clips), and add real project save/load that works fully offline —
no server, no internet required, no account.

## Fixed (real bugs, not just new features)
- **Dragging a clip flooded the undo stack.** `Timeline.tsx` called its
  "update clips" callback on every `pointermove` while dragging or trimming
  a clip — with the old 25-entry cap, a single drag across the timeline
  could consume the *entire* undo history, and pressing Undo once would
  only step back one pixel. Now a drag/trim/split is captured as a single
  undo step, however far the gesture travels.
- **Track changes (mute, lock, hide, volume, pan) weren't undoable at all.**
  `Timeline`'s track buttons and `AudioMixerPanel`'s sliders wrote straight
  to state, bypassing history entirely. Both now go through the same
  history-aware `handleUpdateTrack`.
- **`AI Co-Pilot` button in the header sent an invalid workspace value**
  (`'AI Magic'` instead of `'ai-tools'`) — clicking it did nothing.
- **`npm run lint` (`tsc --noEmit`) couldn't actually run** — `@types/react`
  and `@types/react-dom` were missing from `devDependencies` even though
  the project is React 19. Added both.

## New — Undo/Redo
- Undo/Redo now covers **project settings + tracks + clips**, not just
  clips — renaming the project, adding a marker, adding/removing a track,
  and mute/lock/volume changes are all undoable now.
- Continuous input (dragging a clip, trimming, dragging a color/volume
  slider) is coalesced into **one undo step per gesture** instead of one
  step per pixel/tick (`src/utils/history.ts`).
- Undo/Redo buttons and the Edit menu now show *what* they'll undo/redo
  (e.g. "Undo Adjust Color") as a tooltip.

## New — Project Save/Load (offline, via IndexedDB)
- **Auto-save**: the project quietly saves to this device ~1.5s after you
  stop editing. A status pill in the header shows Saving… / Saved /
  Unsaved changes. No internet, no account, no server — it's all local
  browser storage (IndexedDB).
- **Imported media survives a reload.** Previously, files added via
  "Import" only lived as a `blob:` URL that died the moment the page
  refreshed. Uploaded files are now cached in IndexedDB alongside the
  project, so closing and reopening the app brings back real, playable
  media — not just an empty timeline.
- **Restore-last-session prompt** on load, if this device has an
  auto-saved project from a previous visit.
- **File ▸ New Project / Save Project (Ctrl/⌘+S) / Save Project As…
  (downloads a `.vidcraftproj.json` file) / Open Project File… / Open
  Recent Project…** — the last one lists every project auto-saved on this
  device, with a delete option.
- **Relink missing media**: if you open a project file on a different
  device/browser than it was imported on, the referenced local files won't
  be found — instead of a silently broken video, the asset is flagged
  "Media offline" with a **Relink** button to point it at the file again.

## Known trade-offs / follow-ups for a future pass
- AI Magic Lab edits (`AIToolsPanel`) and Program Monitor project-setting
  changes (resolution/fps/aspect ratio) still write directly to state and
  aren't individually undoable yet — they become part of the new "current"
  baseline instead of a revertible step. Rewiring those two through history
  is straightforward but was out of scope for this pass.
- `Save Project As...` (the downloadable `.vidcraftproj.json`) stores
  project structure + asset metadata, not the media bytes themselves (that
  would make the file enormous). Opening it on the *same* device it was
  saved on restores media automatically from IndexedDB; on a *different*
  device you'll be asked to relink each file once.
- The auto-save slot is per-browser (IndexedDB doesn't sync across
  devices/browsers). Multi-track timeline management (drag tracks to
  reorder, resizable track headers, etc.) is next on the list.
