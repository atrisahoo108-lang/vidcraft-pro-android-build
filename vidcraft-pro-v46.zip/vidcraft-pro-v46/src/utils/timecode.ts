/**
 * Formats a time in seconds into SMPTE timecode (HH:MM:SS:FF or MM:SS:FF)
 */
export function formatTimecode(seconds: number, fps: number = 30, showHours: boolean = true): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  
  const totalFrames = Math.floor(seconds * fps);
  const frames = totalFrames % fps;
  const totalSeconds = Math.floor(seconds);
  const secs = totalSeconds % 60;
  const totalMinutes = Math.floor(totalSeconds / 60);
  const mins = totalMinutes % 60;
  const hours = Math.floor(totalMinutes / 60);

  const pad = (num: number, size: number = 2) => String(num).padStart(size, '0');

  if (showHours) {
    return `${pad(hours)}:${pad(mins)}:${pad(secs)}:${pad(frames)}`;
  }
  return `${pad(mins)}:${pad(secs)}:${pad(frames)}`;
}

/**
 * Formats seconds into human-readable duration (e.g. 01:24s or 14.5s)
 */
export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  const mins = Math.floor(seconds / 60);
  const secs = (seconds % 60).toFixed(1);
  if (mins > 0) {
    return `${mins}m ${secs}s`;
  }
  return `${secs}s`;
}

/**
 * Parses timecode string back to seconds
 */
export function parseTimecode(timecodeStr: string, fps: number = 30): number {
  const parts = timecodeStr.split(':').map(Number);
  if (parts.some(isNaN)) return 0;

  if (parts.length === 4) {
    const [h, m, s, f] = parts;
    return h * 3600 + m * 60 + s + f / fps;
  } else if (parts.length === 3) {
    const [m, s, f] = parts;
    return m * 60 + s + f / fps;
  } else if (parts.length === 2) {
    const [m, s] = parts;
    return m * 60 + s;
  }
  return Number(timecodeStr) || 0;
}

/**
 * Snapping helper for timeline clips & playhead
 */
export function findSnapPoint(
  targetTime: number,
  snapPoints: number[],
  thresholdSeconds: number = 0.2
): { snappedTime: number; isSnapped: boolean } {
  let closestDist = Infinity;
  let snappedTime = targetTime;

  for (const point of snapPoints) {
    const dist = Math.abs(targetTime - point);
    if (dist < thresholdSeconds && dist < closestDist) {
      closestDist = dist;
      snappedTime = point;
    }
  }

  return {
    snappedTime,
    isSnapped: closestDist !== Infinity
  };
}
