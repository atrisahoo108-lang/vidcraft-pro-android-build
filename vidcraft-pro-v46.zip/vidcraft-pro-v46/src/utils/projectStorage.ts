// Offline project persistence.
//
// Everything here talks to the browser's IndexedDB, which works fully
// offline (no server, no internet) and survives closing the tab/app —
// unlike blob: URLs from URL.createObjectURL(), which die as soon as the
// page reloads. Two things are stored:
//
//   1. "projects"  — the editable document (project settings, tracks,
//      clips, asset metadata) as one JSON-able record per project.
//   2. "media"     — the actual bytes (Blob) of every file the user
//      imported via the file picker, keyed by asset id, so re-opening a
//      project restores real playable media, not just an empty timeline.
//
// Sample/stock assets that point at remote URLs are never stored here —
// there is nothing to cache locally, and they already work the same way
// they did before (only requiring internet if the person actually plays
// one, same as clicking any other link).

import { Clip, MediaAsset, ProjectSettings, Track } from '../types';

const DB_NAME = 'vidcraft-pro';
const DB_VERSION = 1;
const STORE_PROJECTS = 'projects';
const STORE_MEDIA = 'media';
const STORE_META = 'meta';

export interface ProjectSnapshot {
  id: string;
  name: string;
  updatedAt: number;
  project: ProjectSettings;
  tracks: Track[];
  clips: Clip[];
  assets: MediaAsset[];
}

export interface ProjectSnapshotMeta {
  id: string;
  name: string;
  updatedAt: number;
  clipCount: number;
  trackCount: number;
}

interface StoredMediaBlob {
  assetId: string;
  blob: Blob;
  fileName: string;
  mimeType: string;
}

let dbPromise: Promise<IDBDatabase> | null = null;

function openDatabase(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not available in this environment.'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_MEDIA)) {
        db.createObjectStore(STORE_MEDIA, { keyPath: 'assetId' });
      }
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  return dbPromise;
}

function runTx<T>(
  storeName: string,
  mode: IDBTransactionMode,
  work: (store: IDBObjectStore) => IDBRequest<T>
): Promise<T> {
  return openDatabase().then(
    db =>
      new Promise<T>((resolve, reject) => {
        const tx = db.transaction(storeName, mode);
        const store = tx.objectStore(storeName);
        const req = work(store);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
        tx.onerror = () => reject(tx.error);
      })
  );
}

// Whether IndexedDB persistence can be used at all in this environment
// (it's absent in some locked-down webviews / private-browsing modes).
export function isProjectStorageAvailable(): boolean {
  return typeof indexedDB !== 'undefined';
}

// --- Project documents ---------------------------------------------------

export async function saveProjectSnapshot(snapshot: ProjectSnapshot): Promise<void> {
  await runTx(STORE_PROJECTS, 'readwrite', store => store.put(snapshot));
  await runTx(STORE_META, 'readwrite', store => store.put({ key: 'lastOpenedId', value: snapshot.id }));
}

export async function loadProjectSnapshot(id: string): Promise<ProjectSnapshot | null> {
  const result = await runTx<ProjectSnapshot | undefined>(STORE_PROJECTS, 'readonly', store => store.get(id));
  return result || null;
}

export async function listProjectSnapshots(): Promise<ProjectSnapshotMeta[]> {
  const all = await runTx<ProjectSnapshot[]>(STORE_PROJECTS, 'readonly', store => store.getAll());
  return (all || [])
    .map(p => ({
      id: p.id,
      name: p.name,
      updatedAt: p.updatedAt,
      clipCount: p.clips?.length || 0,
      trackCount: p.tracks?.length || 0,
    }))
    .sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function deleteProjectSnapshot(id: string): Promise<void> {
  await runTx(STORE_PROJECTS, 'readwrite', store => store.delete(id));
}

export async function getLastOpenedProjectId(): Promise<string | null> {
  const rec = await runTx<{ key: string; value: string } | undefined>(STORE_META, 'readonly', store =>
    store.get('lastOpenedId')
  );
  return rec?.value || null;
}

// --- Media blobs -----------------------------------------------------------

export async function saveMediaBlob(assetId: string, file: Blob, fileName: string, mimeType: string): Promise<void> {
  const record: StoredMediaBlob = { assetId, blob: file, fileName, mimeType };
  await runTx(STORE_MEDIA, 'readwrite', store => store.put(record));
}

export async function loadMediaBlob(assetId: string): Promise<StoredMediaBlob | null> {
  const rec = await runTx<StoredMediaBlob | undefined>(STORE_MEDIA, 'readonly', store => store.get(assetId));
  return rec || null;
}

export async function deleteMediaBlob(assetId: string): Promise<void> {
  await runTx(STORE_MEDIA, 'readwrite', store => store.delete(assetId));
}
