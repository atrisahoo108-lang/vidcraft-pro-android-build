# VidCraft Pro — v45 Update: Android Native Foundation & Build-Readiness

Base: v44 (`vidcraft-pro-v44.zip`) — every file not listed below is
byte-for-byte unchanged from v44.

## Important — what this sandbox cannot verify

This environment has **no network access and no Android SDK/emulator**.
That was true for v43/v44 too, but this update's scope (native foundation,
build-readiness, on-device behavior) makes the limitation matter more, so
it's stated plainly here rather than only in a footnote:

- I could not run `cap add android`, so the `android/` native project
  still does not exist in this zip.
- I could not run a Gradle build, install an APK, or press a physical/
  emulated back button, rotate a real device, or open the soft keyboard.
- Nothing in this changelog that mentions Android runtime behavior
  (back button, orientation, edge-to-edge, keyboard resize) has been
  observed working — it's implemented against Capacitor's documented
  default behavior and standard Web APIs, and needs a real-device check
  on your machine before you rely on it. Where relevant, this is called
  out again per-item below.

Only 4 files changed from v44: `capacitor.config.ts`, `vite.config.ts`,
`src/App.tsx`, `MOBILE_BUILD.md`. No `android/` folder, no new runtime
dependency, no license/payment/auth file touched (verified by diff).

## Changed — `src/App.tsx`: hardware/gesture back-button handling

**Not verified on a real device — see note above.**

Previously nothing in the app ever pushed browser history, so Capacitor's
documented default behavior for the Android back button (call
`history.back()` if there's an entry to go back to, else close the app)
meant pressing back while, say, the Export dialog was open would exit the
whole app instantly.

Fixed with plain Web History API, no new native plugin:
- While `ExportModal`, `LicensePanel`, the Shortcuts modal, or the Project
  Manager is open, one history entry is pushed.
- A `popstate` event (fires for the hardware back button, an edge-swipe
  back gesture, and a desktop browser's Back) closes whichever of those
  is open instead of exiting/navigating.
- If the modal is instead closed normally (its own × / Cancel button),
  cleanup consumes that same pushed entry via `history.back()`, so a
  later real back press isn't "spent" on a modal that's already closed.
- Works identically on desktop/web (Alt+Left or a mouse back button will
  now close an open modal there too) — this was intentionally not gated
  to mobile-only, since the behavior is reasonable on any platform and
  needed no `isMobile` branching.
- This only touches `App.tsx`'s modal-open state — `LicensePanel.tsx`
  itself was not opened or edited.

## Changed — `vite.config.ts`: explicit WebView-safe build target

Added `build.target: 'es2020'`. Vite's implicit default already excludes
the newest syntax, but this makes the floor intentional: ES2020 covers
Chrome 80+ / Android System WebView from roughly Android 8+, which is the
range a low-end device with an outdated WebView is most likely to still
be on. Checked the codebase for anything that would need a newer target —
no top-level `await`, no `structuredClone`, no `OffscreenCanvas`, no class
private fields — so this is a safety floor being made explicit, not a
functional change. Desktop/web output is unaffected (every desktop
browser in real use supports ES2020).

## Changed — `capacitor.config.ts`: native-side checklist for after `cap add android`

No config values were changed (appId `com.vidcraft.pro`, appName
`VidCraft Pro`, `webDir: 'dist'`, the v43 `backgroundColor`/
`allowMixedContent` settings are all exactly as in v44). Added a comment
block documenting four things to check/apply once the `android/` project
exists (which it doesn't yet in this zip — see below):

1. **Orientation** — confirmed the request for portrait *and* landscape
   support needs no config change: Capacitor's default template doesn't
   set `android:screenOrientation` on the activity, which is what allows
   both. Documented as a "don't add this line" warning, since
   `android:screenOrientation="portrait"` is a common copy-paste default
   in Android tutorials that would silently break the landscape editing
   layout v43/v44 already built.
2. **`android:largeHeap="true"`** — a one-line `AndroidManifest.xml`
   addition to raise the process's heap ceiling for video compositing/
   export on low/mid-end devices. Documented, not applied (no manifest
   file exists yet to edit).
3. **Permissions audit** — confirmed nothing in the current dependency
   list (`@capacitor/core`, `@capacitor/android` only, no camera/mic/
   storage/ads/billing plugin) requests any dangerous permission beyond
   the default INTERNET the WebView needs. No permission was added.
4. **`minSdkVersion`** — left at Capacitor 7's template default (23 /
   Android 6.0) rather than raised or lowered; changing it either way
   needs a real low-end device or emulator to validate against, which
   isn't available here.

## Changed — `MOBILE_BUILD.md`

Added a "v45" section (Bengali, matching the rest of the doc) covering:
app icon/splash generation (still not done — `assets/` is empty; needs
`@capacitor/assets`, which needs network you'll have locally but this
sandbox doesn't), a plain-language explanation of the back-button fix
and that it's unverified here, a pointer to the `capacitor.config.ts`
checklist, and an explicit list of what this sandbox could not verify.

## Verified unchanged (regression check against v43/v44)

Diffed identical to v44: device-tier preview cap (`ProgramMonitor.tsx`,
`deviceTier.ts`), `Timeline.tsx`/`HeaderMenuBar.tsx` touch sizing, the
`.safe-top`/`.safe-bottom`/`.safe-x` CSS utilities and global scroll-
behavior rules in `index.css`, the `(pointer: coarse)` slider-thumb rule,
`AudioMixerPanel`'s meter throttling, `ExportModal`'s v44 layout changes,
the v44 landscape-detection fix in `useIsMobile` (checks the shorter
viewport edge, not raw width), and the background auto-pause effect. None
regressed. `license.ts`, `licenseVerification.ts`, `payment.ts`,
`paymentBackendContract.ts`, `premiumFeatures.ts`, `razorpayConfig.ts`,
`watermark.ts`, `auth.ts`, `googleAuthAdapter.ts`, `firebaseConfig.ts`,
`LicensePanel.tsx`, `PremiumBadge.tsx` — untouched.

## Known follow-ups (not done in this pass)

- The `android/` native project itself still needs to be generated on
  your own machine (`npm run cap:add:android`) — nothing about that step
  changed.
- App icon and splash image generation (`@capacitor/assets`) — needs a
  source icon you provide plus network access, both unavailable here.
- `android:largeHeap="true"` and the edge-to-edge `MainActivity.java`
  line (from v43) both still need to be added by hand to files that don't
  exist in this sandbox — they're documented, not applied.
- The back-button fix, keyboard-resize behavior (Capacitor's default
  `adjustResize` was relied on as-is; no `@capacitor/keyboard` plugin was
  added), and orientation switching all need a real-device pass before
  the next update builds further on top of them.
