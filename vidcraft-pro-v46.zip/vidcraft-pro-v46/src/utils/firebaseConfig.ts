// -----------------------------------------------------------------------
// VidCraft Pro — Firebase configuration (env-var only, never hard-coded)
// -----------------------------------------------------------------------
// Reads the Firebase Web config from Vite env vars (VITE_FIREBASE_*).
// These are PUBLIC client identifiers (not secrets — Firebase's own docs
// note the Web API key is safe to expose; access is controlled by
// Firebase Auth/Security Rules, not by hiding this config), but they are
// still never hard-coded here so each deployment/environment can use its
// own Firebase project without touching source.
//
// If any required value is missing, getFirebaseConfig() returns null and
// isFirebaseConfigured() returns false — nothing that imports this file
// should ever throw or attempt a network call when that happens.

export interface FirebaseConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  appId: string;
}

function readEnvVar(key: string): string | undefined {
  const value = (import.meta.env as Record<string, string | undefined>)[key];
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined;
}

/** Returns the config if every required field is present, otherwise null — never throws. */
export function getFirebaseConfig(): FirebaseConfig | null {
  const apiKey = readEnvVar('VITE_FIREBASE_API_KEY');
  const authDomain = readEnvVar('VITE_FIREBASE_AUTH_DOMAIN');
  const projectId = readEnvVar('VITE_FIREBASE_PROJECT_ID');
  const appId = readEnvVar('VITE_FIREBASE_APP_ID');

  if (!apiKey || !authDomain || !projectId || !appId) {
    return null;
  }
  return { apiKey, authDomain, projectId, appId };
}

export function isFirebaseConfigured(): boolean {
  return getFirebaseConfig() !== null;
}
