# VidCraft Pro — v6 Update: Editing Features & Rendering Fixes

Focus of this pass (as requested): editing features (new effects/transitions/tools)
and performance/export quality. No UI redesign or mobile-build changes in this pass.

## Fixed (real bugs, not just new features)
- **Filters were never rendered.** `EffectsLibrary` let you add filters (blur,
  chromatic aberration, glitch, scanlines, sharpen, sepia, etc.) to a clip, but
  `videoCompositor.ts` never read `clip.filters` at all — they had zero visual
  effect. Now fully wired into the render pipeline (see below).
- **Wipe transitions computed but unused.** The old compositor calculated a
  `wipeFactor` for wipe-left/right but never applied it — wipes always looked
  identical to a plain cut. Now implemented via canvas clipping paths.
- **Video/image stretched instead of cropped.** Clips were drawn at full
  canvas size regardless of source aspect ratio, distorting anything that
  didn't exactly match the project's aspect ratio. Now uses "cover fit"
  (crop-to-fill, like CSS `object-fit: cover`).
- **Keyframes were dead code.** `Clip.keyframes` and the `onAddKeyframe`
  callback existed in the types/props but nothing ever added a keyframe or
  interpolated one during playback. Now fully functional.
- **Vignette was warped by the clip's own transform** (rotation/scale bent the
  vignette gradient with it). Now applied in the clip's own frame space, so it
  reads correctly regardless of transform.

## New
- **8 new transitions**: Wipe Up/Down, Iris Reveal, Slide Left/Right/Up/Down,
  Blur Dissolve — alongside the fixed Cross Dissolve / Dip to Black / Dip to
  White / Wipe Left/Right / Zoom In.
- **Keyframe animation**: "Add Keyframe" buttons next to Position X/Y, Scale,
  Rotation, Opacity (video) and Volume (audio) in Effect Controls. Keyframes
  interpolate linearly and hold at the ends. Volume keyframes now also drive
  the audio engine (real fades, not just a static level).
- **Applied Filters panel**: previously-added filters can now be toggled,
  adjusted, and removed from the Effects & Transitions panel (there was no way
  to manage them before — only add).
- **Additional filter types exposed in the UI**: Glitch, Grayscale, Invert
  (types already existed but weren't selectable).
- New shared utility `src/utils/keyframes.ts` for keyframe interpolation,
  reused by both the video compositor and the audio engine.

## Performance / quality
- Filters that need pixel access (chromatic aberration, glitch, sharpen) are
  isolated to a reusable off-screen "layer" canvas instead of allocating a new
  canvas per clip per frame.
- `imageSmoothingQuality = 'high'` set on both the layer and main canvas for
  better upscale/downscale quality (was left at default).
- Added `VideoCompositor.disposeAsset()` / `pruneUnusedAssets()` to release
  cached `<video>`/`<img>` elements — call this when an asset is removed from
  the project, especially important on mobile where memory is tighter.

## Known trade-offs / follow-ups for a future pass
- Sharpen and chromatic aberration use per-pixel `ImageData` processing, which
  costs more per frame than the CSS-filter-only effects. Fine for occasional
  use; a project leaning on these heavily across many simultaneous clips may
  see reduced scrub/preview frame rate. A GPU (WebGL) filter path would be the
  next step if that becomes a bottleneck.
- Export (`ExportModal.tsx`) still records in real time via
  `canvas.captureStream()` + `MediaRecorder` — a 3-minute timeline still takes
  ~3 minutes to export. True frame-accurate/faster-than-real-time export would
  require a WebCodecs (`VideoEncoder`) rewrite of the export path — a larger,
  separate piece of work, not included in this pass since it wasn't the
  priority you picked.
- True GIF encoding is still a stub (falls back to WebM), unchanged this pass.
