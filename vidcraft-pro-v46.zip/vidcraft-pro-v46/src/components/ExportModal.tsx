import React, { useState, useRef, useEffect } from 'react';
import { 
  X, Download, Film, HardDrive, CheckCircle2, 
  Loader2, Sparkles, Layers, Sliders, Play, AlertTriangle
} from 'lucide-react';
import { ProjectSettings, Clip, Track, MediaAsset } from '../types';
import { videoCompositor } from '../utils/videoCompositor';
import { audioEngine } from '../utils/audioEngine';
import { audioBufferToWav } from '../utils/wavEncoder';
import { getEffectiveClipFadeSeconds } from '../utils/keyframes';
import { isProUser, getLicenseTier, setDevLicenseOverride, type LicenseTier } from '../utils/license';
import { canUseFeature } from '../utils/premiumFeatures';
import { PremiumBadge } from './PremiumBadge';
import { drawExportWatermark } from '../utils/watermark';
import { getDeviceTier, isTouchPrimaryDevice } from '../utils/deviceTier';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: ProjectSettings;
  clips: Clip[];
  tracks: Track[];
  assets: MediaAsset[];
  // v44: taller controls, single-column option grid, and a viewport-height
  // clamp with internal scrolling so the modal fits on short/landscape
  // phone screens. Layout-only — none of the export/encoding logic below,
  // or the dev license-tier switch, is touched by this flag. Defaults to
  // false, so desktop/web is pixel-identical to v43.
  isMobile?: boolean;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  project,
  clips,
  tracks,
  assets,
  isMobile = false
}) => {
  const [format, setFormat] = useState<'mp4' | 'webm' | 'gif' | 'wav'>('mp4');
  const [resolution, setResolution] = useState<'1080p' | '4k' | '720p' | 'shorts'>('1080p');
  const [quality, setQuality] = useState<'high' | 'medium' | 'cinematic'>('high');
  const [fps, setFps] = useState<number>(project.fps || 30);
  const [isExporting, setIsExporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [exportedUrl, setExportedUrl] = useState<string | null>(null);
  const [exportedExt, setExportedExt] = useState<string>('webm');
  const [fellBackToWebm, setFellBackToWebm] = useState(false);

  // TEMPORARY DEV/TEST STATE — mirrors utils/license.ts's localStorage
  // override purely so this component re-renders when it's toggled. See
  // license.ts for why this is not a real licensing system.
  const [licenseTier, setLicenseTierState] = useState<LicenseTier>(getLicenseTier());
  const setDevTier = (tier: LicenseTier) => {
    setDevLicenseOverride(tier);
    setLicenseTierState(tier);
  };

  // 4K Export Premium Gate (v32): same small self-clearing local notice
  // pattern already used in LumetriColorPanel.tsx for the cinematic-LUT
  // gate — reused here rather than building a new notification system.
  const FOUR_K_LOCK_MESSAGE = '4K export is available in VidCraft Pro.';
  const [lockNotice, setLockNotice] = useState<string | null>(null);
  // v46: visible failure message (previously a failed/short encode was silent).
  const [exportError, setExportError] = useState<string | null>(null);
  useEffect(() => {
    if (!lockNotice) return;
    const timer = setTimeout(() => setLockNotice(null), 3500);
    return () => clearTimeout(timer);
  }, [lockNotice]);

  // Object URL lifecycle (Step 3 fix): `exportedUrl` is a blob: URL for the
  // finished render — it's the download link's href AND what the "Render
  // Complete" state points at, so it must stay alive as long as either of
  // those might still be used. It's tracked in a ref (mirrored from state)
  // purely so the unmount cleanup below can always reach the *latest* value
  // without re-subscribing every time a new export finishes.
  const exportedUrlRef = useRef<string | null>(null);
  useEffect(() => { exportedUrlRef.current = exportedUrl; }, [exportedUrl]);

  // This component is normally kept mounted for the app's lifetime (its
  // parent renders it unconditionally and just toggles `isOpen`), so this
  // mainly guards against a future change to that mounting strategy — if it
  // does ever unmount, don't leave the last export's blob alive.
  useEffect(() => {
    return () => {
      if (exportedUrlRef.current) URL.revokeObjectURL(exportedUrlRef.current);
    };
  }, []);

  if (!isOpen) return null;

  const getTargetDimensions = () => {
    let targetW = 1920;
    let targetH = 1080;
    if (resolution === '4k') {
      targetW = 3840; targetH = 2160;
    } else if (resolution === '720p') {
      targetW = 1280; targetH = 720;
    } else if (resolution === 'shorts' || project.aspectRatio === '9:16') {
      targetW = 1080; targetH = 1920;
    }
    return { targetW, targetH };
  };

  // 4K Export Premium Gate (v32): "genuinely 4K" means the resolved export
  // dimensions are at least 3840x2160 — reusing whatever getTargetDimensions()
  // already resolves to, rather than a second resolution concept. 720p,
  // 1080p, and the 9:16 shorts preset (1080x1920) are all well under this
  // and are never affected.
  const isFourKExport = (): boolean => {
    const { targetW, targetH } = getTargetDimensions();
    return targetW >= 3840 && targetH >= 2160;
  };

  const pickVideoMimeType = (preferMp4: boolean): string => {
    if (typeof MediaRecorder === 'undefined') return '';
    const candidates = preferMp4
      ? ['video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm']
      : ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
    for (const type of candidates) {
      if (MediaRecorder.isTypeSupported(type)) return type;
    }
    return '';
  };

  // Drives the real video elements / audio graph forward to `t` seconds so the
  // canvas + captured audio stream actually contain that instant of the timeline.
  const driveTimelineTo = (t: number, playing: boolean) => {
    clips.forEach(clip => {
      const asset = assets.find(a => a.id === clip.assetId);
      if (!asset) return;
      if (clip.type === 'video') {
        videoCompositor.syncVideoPlayback(clip, asset, t, playing);
      }
      if (clip.type === 'audio' || clip.type === 'video') {
        audioEngine.playClipAudio(clip, asset, t, playing, tracks, clips);
      }
    });
  };

  // Real export: plays the sequence in real time, captures the canvas as a
  // video stream, mixes in the live audio graph, and records both together
  // with MediaRecorder. This produces an actual playable video file instead
  // of a single still frame.
  const exportVideo = async () => {
    const { targetW, targetH } = getTargetDimensions();
    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const mimeType = pickVideoMimeType(format === 'mp4');
    if (!mimeType) {
      console.error('This browser does not support MediaRecorder video encoding.');
      return;
    }
    const actualExt = mimeType.startsWith('video/mp4') ? 'mp4' : 'webm';
    setFellBackToWebm(format === 'mp4' && actualExt === 'webm');

    const canvasStream = (canvas as HTMLCanvasElement & {
      captureStream: (fps?: number) => MediaStream;
    }).captureStream(fps);

    // Tap the live audio mixer into a MediaStream so real mixed audio (all
    // tracks, volumes, mutes) is captured alongside the video, not silence.
    const audioCtx = audioEngine.getContext();
    let destNode: MediaStreamAudioDestinationNode | null = null;
    let combinedStream: MediaStream = canvasStream;
    if (audioCtx) {
      destNode = audioCtx.createMediaStreamDestination();
      const master = audioEngine.getMasterDestination();
      if (master) master.connect(destNode);
      combinedStream = new MediaStream([
        ...canvasStream.getVideoTracks(),
        ...destNode.stream.getAudioTracks()
      ]);
    }

    let bitrate = quality === 'cinematic' ? 12_000_000 : quality === 'high' ? 8_000_000 : 4_000_000;
    // v46: phones encode in real time on a small encoder + 4GB-class RAM;
    // very high bitrates can make MediaRecorder stall or stop early.
    // Desktop is unchanged.
    if (isTouchPrimaryDevice()) {
      const tier = getDeviceTier();
      bitrate = Math.min(bitrate, tier === 'low' ? 3_000_000 : tier === 'mid' ? 6_000_000 : 12_000_000);
    }
    const chunks: Blob[] = [];
    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(combinedStream, { mimeType, videoBitsPerSecond: bitrate });
    } catch {
      recorder = new MediaRecorder(combinedStream, { mimeType });
    }
    let recorderError: string | null = null;
    recorder.onerror = (e: Event) => {
      const err = (e as unknown as { error?: { message?: string } }).error;
      recorderError = err?.message || 'The encoder stopped unexpectedly.';
    };
    recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
    const stopped = new Promise<void>((resolve) => { recorder.onstop = () => resolve(); });

    // v46: preflight so the recording doesn't start on black/unloaded
    // video. Resume audio (a suspended context yields no audio samples,
    // which can stall the muxer), wait for each used video to have a
    // decodable frame, park everything at t=0, and paint one frame.
    if (audioCtx && audioCtx.state === 'suspended') {
      try { await audioCtx.resume(); } catch { /* ignore */ }
    }
    const usedVideoAssets = new Set(clips.filter(c => c.type === 'video').map(c => c.assetId));
    for (const assetId of usedVideoAssets) {
      const a = assets.find(x => x.id === assetId);
      if (a && a.src) await videoCompositor.ensureVideoReady(a.id, a.src);
    }
    driveTimelineTo(0, false);
    await videoCompositor.waitForVideosIdle();
    videoCompositor.renderFrame(ctx, targetW, targetH, 0, clips, tracks, assets, project, null, false);

    recorder.start(250);

    const duration = Math.max(project.duration, 0.1);
    const startWall = performance.now();
    const videoTrack = canvasStream.getVideoTracks()[0] as (MediaStreamTrack & { requestFrame?: () => void }) | undefined;

    await new Promise<void>((resolve) => {
      const frame = () => {
        const t = Math.min((performance.now() - startWall) / 1000, duration);
        driveTimelineTo(t, true);
        videoCompositor.renderFrame(ctx, targetW, targetH, t, clips, tracks, assets, project, null, false);
        // Free-tier export watermark — Pro users get a clean export. Only
        // applied here, to the export canvas, never to the live editing
        // preview (ProgramMonitor never calls this).
        if (!isProUser()) {
          drawExportWatermark(ctx, targetW, targetH);
        }
        videoTrack?.requestFrame?.();
        setProgress(Math.min(100, Math.round((t / duration) * 100)));

        if (recorder.state === 'inactive') {
          // Encoder died mid-run — stop driving the timeline.
          resolve();
        } else if (t < duration) {
          requestAnimationFrame(frame);
        } else {
          resolve();
        }
      };
      requestAnimationFrame(frame);
    });

    driveTimelineTo(duration, false);
    audioEngine.stopAll();
    if (recorder.state !== 'inactive') recorder.stop();
    await stopped;

    if (destNode) {
      try { audioEngine.getMasterDestination()?.disconnect(destNode); } catch { /* already disconnected */ }
    }

    const blob = new Blob(chunks, { type: mimeType });
    if (recorderError || blob.size < 2048) {
      setExportError(
        'Export failed on this device' + (recorderError ? ` (${recorderError})` : '') +
        '. Try 720p, Web Compressed quality, or a shorter sequence.'
      );
      setProgress(0);
      return;
    }
    setExportedExt(actualExt);
    setExportedUrl(URL.createObjectURL(blob));
    setProgress(100);
  };

  // Real audio-only export: decodes every clip's source audio and mixes it
  // offline (fast, not real-time) into a single buffer, then writes a
  // genuine PCM WAV file.
  const exportWav = async () => {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    const duration = Math.max(project.duration, 0.1);
    const offlineCtx = new OfflineAudioContext(2, Math.ceil(duration * 48000), 48000);
    const tempCtx = new AudioCtx();

    const audioClips = clips.filter(c => c.type === 'video' || c.type === 'audio');
    let done = 0;

    for (const clip of audioClips) {
      const asset = assets.find(a => a.id === clip.assetId);
      if (!asset || !asset.src) { done++; continue; }
      const track = tracks.find(t => t.id === clip.trackId);
      const isTrackMuted = track ? track.isMuted : false;
      const trackVolume = track ? track.volume : 1;
      const effectiveVol = (clip.audioConfig?.mute || isTrackMuted) ? 0 : (clip.audioConfig?.volume ?? 1) * trackVolume;

      try {
        const res = await fetch(asset.src);
        const arrayBuffer = await res.arrayBuffer();
        const decoded = await tempCtx.decodeAudioData(arrayBuffer.slice(0));

        const source = offlineCtx.createBufferSource();
        source.buffer = decoded;
        const gain = offlineCtx.createGain();

        // Fade in/out + same-track auto-crossfade (Step 7): schedule the
        // same fade window the real-time preview uses, as an actual Web
        // Audio gain ramp — a constant gain here would silently drop fades
        // from this export path even though the preview honors them.
        const sameTrackClips = audioClips.filter(c => c.trackId === clip.trackId);
        const { fadeIn, fadeOut } = getEffectiveClipFadeSeconds(clip, sameTrackClips);
        if (fadeIn <= 0 && fadeOut <= 0) {
          gain.gain.value = effectiveVol;
        } else {
          const rampStart = clip.startTime;
          const rampEnd = clip.startTime + clip.duration;
          gain.gain.setValueAtTime(fadeIn > 0 ? 0 : effectiveVol, Math.max(0, rampStart));
          if (fadeIn > 0) {
            gain.gain.linearRampToValueAtTime(effectiveVol, rampStart + fadeIn);
          }
          if (fadeOut > 0) {
            gain.gain.setValueAtTime(effectiveVol, Math.max(0, rampEnd - fadeOut));
            gain.gain.linearRampToValueAtTime(0, rampEnd);
          }
        }

        source.connect(gain);
        gain.connect(offlineCtx.destination);

        const offset = Math.max(0, clip.inPoint);
        const playDuration = Math.min(clip.duration, decoded.duration - offset);
        if (playDuration > 0) {
          source.start(clip.startTime, offset, playDuration);
        }
      } catch (err) {
        console.error(`Could not decode audio for clip ${clip.id}`, err);
      }
      done++;
      setProgress(Math.round((done / Math.max(audioClips.length, 1)) * 90));
    }

    tempCtx.close().catch(() => {});
    const rendered = await offlineCtx.startRendering();
    setProgress(95);

    const wavBlob = audioBufferToWav(rendered);
    setExportedExt('wav');
    setExportedUrl(URL.createObjectURL(wavBlob));
    setProgress(100);
  };

  const handleStartExport = async () => {
    // 4K Export Premium Gate (v32): checked first, before touching any
    // export state (no revoked blob, no isExporting, no progress reset) —
    // WAV export has no video resolution at all, so it's never affected.
    if (format !== 'wav' && isFourKExport() && !canUseFeature('4k-export')) {
      setLockNotice(FOUR_K_LOCK_MESSAGE);
      return;
    }

    // A previous render's blob (if any) is being superseded — its download
    // link is about to disappear from the UI too, so its useful life is
    // over. Revoke it before dropping the reference, otherwise every
    // re-export (different format/resolution, or just trying again) leaks
    // the prior attempt's blob for the rest of the session.
    if (exportedUrl) {
      URL.revokeObjectURL(exportedUrl);
    }
    setIsExporting(true);
    setExportError(null);
    setProgress(0);
    setExportedUrl(null);
    setFellBackToWebm(false);

    try {
      if (format === 'wav') {
        await exportWav();
      } else {
        // GIF isn't backed by a bundled encoder yet — export a real WebM
        // instead of silently faking a static image, and say so in the UI.
        await exportVideo();
      }
    } catch (err) {
      console.error('Export failed', err);
      setExportError('Export failed: ' + (err instanceof Error ? err.message : 'unknown error'));
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownload = () => {
    if (!exportedUrl) return;
    const a = document.createElement('a');
    a.href = exportedUrl;
    a.download = `${project.name.toLowerCase().replace(/\s+/g, '_')}_master.${exportedExt}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const estimatedSize = ((project.duration * (quality === 'cinematic' ? 35 : quality === 'high' ? 20 : 10)) / 8).toFixed(1);

  return (
    <div className={`fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center select-none ${isMobile ? 'p-2' : 'p-4'}`}>
      <div className={`w-full max-w-xl bg-[#181820] border border-[#2b2b38] rounded-xl shadow-2xl overflow-hidden flex flex-col ${isMobile ? 'max-h-[92vh]' : ''}`}>
        {/* Modal Header */}
        <div className={`safe-top bg-[#1e1e28] border-b border-[#282836] px-4 flex items-center justify-between shrink-0 ${isMobile ? 'h-14' : 'h-10'}`}>
          <div className="flex items-center space-x-2">
            <Film className="w-4 h-4 text-sky-400" />
            <span className="font-semibold text-zinc-100 text-xs">Export Media & Sequence</span>
          </div>
          <button
            onClick={onClose}
            className={`rounded text-zinc-400 hover:text-white hover:bg-[#2b2b3a] ${isMobile ? 'p-2' : 'p-1'}`}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body — scrolls internally on mobile so the modal never
            exceeds the screen on a short/landscape phone; on desktop this
            is unchanged (whole modal simply sizes to its content). */}
        <div className={`space-y-4 text-xs text-zinc-300 ${isMobile ? 'p-3 overflow-y-auto' : 'p-4'}`}>
          {/* TEMPORARY DEV/TEST SWITCH — lets Free/Pro export behavior (the
              watermark below) be verified locally before any real payment
              or licensing system exists. Not secure, not for production —
              see utils/license.ts. */}
          <div className="flex items-center justify-between px-2.5 py-1.5 rounded border border-dashed border-amber-500/40 bg-amber-500/5">
            <span className="text-[10px] text-amber-400/90">
              <span className="font-semibold">DEV TEST ONLY</span> — license tier (not real, local testing)
            </span>
            <div className="flex gap-1">
              <button
                onClick={() => setDevTier('FREE')}
                className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                  licenseTier === 'FREE' ? 'bg-zinc-200 text-zinc-900' : 'bg-[#2b2b36] text-zinc-400 hover:text-zinc-200'
                }`}
              >
                FREE
              </button>
              <button
                onClick={() => setDevTier('PRO')}
                className={`px-2 py-0.5 rounded text-[10px] font-semibold transition-colors ${
                  licenseTier === 'PRO' ? 'bg-amber-500 text-black' : 'bg-[#2b2b36] text-zinc-400 hover:text-zinc-200'
                }`}
              >
                PRO
              </button>
            </div>
          </div>

          {/* Preset / Resolution Selector */}
          <div className={`grid gap-3 ${isMobile ? 'grid-cols-1' : 'grid-cols-2'}`}>
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Export Format</label>
              <select
                value={format}
                onChange={(e) => setFormat(e.target.value as any)}
                className={`w-full bg-[#121216] border border-[#2b2b38] rounded px-2.5 text-zinc-100 text-xs focus:border-sky-500 ${isMobile ? 'py-2.5' : 'py-1.5'}`}
              >
                <option value="mp4">H.264 / MP4 (Universal Master)</option>
                <option value="webm">WebM (VP9 High Quality)</option>
                <option value="gif">Animated GIF (Looping Meme)</option>
                <option value="wav">WAV Audio (Master 24-bit PCM)</option>
              </select>
              {format === 'gif' && (
                <p className="text-[10px] text-amber-400 mt-1 flex items-start gap-1">
                  <AlertTriangle className="w-3 h-3 shrink-0 mt-0.5" />
                  <span>True GIF encoding isn't wired up yet — this will render a real WebM video instead of a static image.</span>
                </p>
              )}
              {licenseTier === 'FREE' && format !== 'wav' && (
                <p className="text-[10px] text-zinc-500 mt-1">
                  Free plan exports include a small "VidCraft Pro" watermark. Switch to Pro to remove it.
                </p>
              )}
            </div>

            <div>
              <label className="text-[10px] text-zinc-400 mb-1 flex items-center gap-1.5">
                Resolution Preset
                <PremiumBadge />
              </label>
              <select
                value={resolution}
                onChange={(e) => setResolution(e.target.value as any)}
                className={`w-full bg-[#121216] border border-[#2b2b38] rounded px-2.5 text-zinc-100 text-xs focus:border-sky-500 ${isMobile ? 'py-2.5' : 'py-1.5'}`}
              >
                <option value="1080p">1080p Full HD (1920x1080)</option>
                <option value="4k">4K Ultra HD (3840x2160)</option>
                <option value="shorts">9:16 Shorts/TikTok (1080x1920)</option>
                <option value="720p">720p HD (1280x720)</option>
              </select>
              {resolution === '4k' && !canUseFeature('4k-export') && (
                <p className="text-[10px] text-amber-400 mt-1">
                  4K export is a VidCraft Pro feature — 720p and 1080p remain free.
                </p>
              )}
            </div>
          </div>

          {exportError && (
            <p className="text-[10px] text-red-400 bg-red-500/10 border border-red-500/30 rounded px-2 py-1.5">
              {exportError}
            </p>
          )}

          {lockNotice && (
            <p className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
              {lockNotice}
            </p>
          )}

          {/* Quality & Framerate */}
          <div className={`grid gap-3 ${isMobile ? 'grid-cols-1' : 'grid-cols-2'}`}>
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Encoding Profile & Bitrate</label>
              <select
                value={quality}
                onChange={(e) => setQuality(e.target.value as any)}
                className={`w-full bg-[#121216] border border-[#2b2b38] rounded px-2.5 text-zinc-100 text-xs ${isMobile ? 'py-2.5' : 'py-1.5'}`}
              >
                <option value="cinematic">Cinematic Master (35 Mbps VBR 2-Pass)</option>
                <option value="high">High Bitrate YouTube (20 Mbps VBR)</option>
                <option value="medium">Web Compressed (10 Mbps CBR)</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Frame Rate</label>
              <select
                value={fps}
                onChange={(e) => setFps(parseInt(e.target.value))}
                className={`w-full bg-[#121216] border border-[#2b2b38] rounded px-2.5 text-zinc-100 text-xs ${isMobile ? 'py-2.5' : 'py-1.5'}`}
              >
                <option value={24}>24.00 fps (Cinematic Film)</option>
                <option value={30}>30.00 fps (Standard Web/NTSC)</option>
                <option value={60}>60.00 fps (Fluid High Motion)</option>
              </select>
            </div>
          </div>

          {/* Summary Box */}
          <div className="bg-[#121216] border border-[#262634] rounded-lg p-3 space-y-1.5 text-[11px]">
            <div className="flex justify-between text-zinc-400">
              <span>Sequence Duration:</span>
              <span className="font-mono-code text-zinc-200">{project.duration.toFixed(1)} seconds</span>
            </div>
            <div className="flex justify-between text-zinc-400">
              <span>Audio Format:</span>
              <span className="font-mono-code text-zinc-200">AAC Stereo, 48.0 kHz, 320 kbps</span>
            </div>
            <div className="flex justify-between text-zinc-400">
              <span>Estimated File Size:</span>
              <span className="font-mono-code text-sky-400 font-semibold">~{estimatedSize} MB</span>
            </div>
          </div>

          {/* Progress Bar (When rendering) */}
          {isExporting && (
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-[11px]">
                <span className="text-sky-400 font-semibold flex items-center space-x-1">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Compositing Video Layers...</span>
                </span>
                <span className="font-mono-code text-zinc-200">{progress}%</span>
              </div>
              <div className="w-full h-2 bg-[#121216] rounded-full overflow-hidden border border-[#282834]">
                <div 
                  className="h-full bg-gradient-to-r from-sky-500 to-blue-600 transition-all duration-100"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Export Complete State */}
          {exportedUrl && !isExporting && (
            <div className="p-3 bg-emerald-950/40 border border-emerald-500/50 rounded-lg flex items-center justify-between">
              <div className="flex items-center space-x-2 text-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold text-xs">
                  Render Complete! Ready for Download{fellBackToWebm ? ' (as .webm — MP4 encoding isn\'t supported in this browser)' : ''}.
                </span>
              </div>
              <button
                id="btn-download-exported-video"
                onClick={handleDownload}
                className={`bg-emerald-600 hover:bg-emerald-500 text-white rounded font-semibold text-xs flex items-center space-x-1 shadow ${isMobile ? 'px-3 py-2.5' : 'px-3 py-1.5'}`}
              >
                <Download className="w-3.5 h-3.5" />
                <span>Save Video</span>
              </button>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className={`safe-bottom bg-[#1e1e28] border-t border-[#282836] px-4 flex items-center justify-between shrink-0 ${isMobile ? 'min-h-16 py-2' : 'h-12'}`}>
          <button
            onClick={onClose}
            className={`rounded bg-[#272734] hover:bg-[#353546] text-zinc-300 text-xs font-medium ${isMobile ? 'px-3.5 py-2.5' : 'px-3 py-1.5'}`}
          >
            Cancel
          </button>

          {!exportedUrl ? (
            <button
              id="btn-start-render"
              onClick={handleStartExport}
              disabled={isExporting}
              className={`rounded bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-md ${isMobile ? 'px-4 py-2.5' : 'px-4 py-1.5'}`}
            >
              {isExporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Film className="w-3.5 h-3.5" />}
              <span>{isExporting ? 'Encoding...' : 'Start Export'}</span>
            </button>
          ) : (
            <button
              onClick={handleDownload}
              className={`rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center space-x-1.5 shadow-md ${isMobile ? 'px-4 py-2.5' : 'px-4 py-1.5'}`}
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
