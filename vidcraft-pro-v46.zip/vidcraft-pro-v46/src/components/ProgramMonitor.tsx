import React, { useRef, useEffect, useState } from 'react';
import { 
  Play, Pause, SkipBack, SkipForward, Camera, Maximize, 
  Ratio, Bookmark, Sparkles, Volume2, ShieldCheck, RefreshCw 
} from 'lucide-react';
import { Clip, MediaAsset, Track, ProjectSettings } from '../types';
import { videoCompositor } from '../utils/videoCompositor';
import { audioEngine } from '../utils/audioEngine';
import { computePreviewDimensions } from '../utils/previewResolution';
import { getPreviewResolutionCap } from '../utils/deviceTier';
import { formatTimecode } from '../utils/timecode';

interface ProgramMonitorProps {
  project: ProjectSettings;
  setProject: React.Dispatch<React.SetStateAction<ProjectSettings>>;
  currentTime: number;
  setCurrentTime: (time: number | ((prev: number) => number)) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  clips: Clip[];
  tracks: Track[];
  assets: MediaAsset[];
  selectedClipId: string | null;
  onAddMarker: (time: number) => void;
  onTakeSnapshot: () => void;
}

export const ProgramMonitor: React.FC<ProgramMonitorProps> = ({
  project,
  setProject,
  currentTime,
  setCurrentTime,
  isPlaying,
  onTogglePlay,
  clips,
  tracks,
  assets,
  selectedClipId,
  onAddMarker,
  onTakeSnapshot
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [showSafeMargins, setShowSafeMargins] = useState(false);
  const [zoomFit, setZoomFit] = useState<'fit' | '100%' | '50%'>('fit');
  const [meterLevels, setMeterLevels] = useState<{ left: number; right: number }>({ left: 0, right: 0 });

  // C1 Part 2: cap the live preview's render resolution so an 8GB-RAM
  // machine isn't decoding/compositing/filtering a full 4K frame 60x/sec
  // just to show a preview panel that's rarely displayed larger than this
  // anyway. 1280px on the longer edge is a reasonable default — sharp
  // enough for editing decisions, small enough to meaningfully cut
  // rendering cost on high-resolution projects. `computePreviewDimensions`
  // never upscales, so smaller/equal projects are completely unaffected.
  // This only ever touches the live Program Monitor canvas — export
  // (`ExportModal.tsx`) has always built its own independent canvas at the
  // real export resolution and does not use this value at all.
  // v43: the cap now scales down on lower-tier Android hardware (see
  // deviceTier.ts) instead of being a fixed 1280 everywhere. Desktop/
  // high-end devices still get exactly 1280, so v42 behavior there is
  // unchanged. This only ever affects the live preview canvas — export
  // (ExportModal.tsx) always renders at full project resolution.
  const [previewResolutionCap] = useState<number | null>(() => getPreviewResolutionCap());
  const { width: renderWidth, height: renderHeight } = computePreviewDimensions(
    project.width,
    project.height,
    previewResolutionCap
  );

  // Sync Video & Audio Buffers on each frame
  useEffect(() => {
    clips.forEach(clip => {
      const asset = assets.find(a => a.id === clip.assetId);
      if (asset) {
        if (clip.type === 'video') {
          videoCompositor.syncVideoPlayback(clip, asset, currentTime, isPlaying);
        }
        if (clip.type === 'audio' || clip.type === 'video') {
          audioEngine.playClipAudio(clip, asset, currentTime, isPlaying, tracks, clips);
        }
      }
    });

    if (!isPlaying) {
      audioEngine.seekAll(currentTime, clips);
    }
  }, [currentTime, isPlaying, clips, tracks, assets]);

  // Main Render Loop
  useEffect(() => {
    let animFrame: number;

    const render = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          videoCompositor.renderFrame(
            ctx,
            renderWidth,
            renderHeight,
            currentTime,
            clips,
            tracks,
            assets,
            project,
            selectedClipId,
            showSafeMargins
          );
        }
      }

      if (isPlaying) {
        setMeterLevels(audioEngine.getMeterLevels());
      } else {
        setMeterLevels({ left: 0, right: 0 });
      }

      animFrame = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animFrame);
  }, [currentTime, isPlaying, clips, tracks, assets, project, selectedClipId, showSafeMargins, renderWidth, renderHeight]);

  // Step Frame
  const stepFrame = (frames: number) => {
    const frameDuration = 1 / project.fps;
    setCurrentTime(t => Math.max(0, Math.min(project.duration, t + frames * frameDuration)));
  };

  const handleAspectChange = (ratio: ProjectSettings['aspectRatio']) => {
    let w = 1920;
    let h = 1080;
    if (ratio === '9:16') {
      w = 1080;
      h = 1920;
    } else if (ratio === '1:1') {
      w = 1080;
      h = 1080;
    } else if (ratio === '4:5') {
      w = 1080;
      h = 1350;
    } else if (ratio === '21:9') {
      w = 2560;
      h = 1080;
    }
    setProject(p => ({ ...p, aspectRatio: ratio, width: w, height: h }));
  };

  return (
    <div className="h-full flex flex-col bg-[#141418] select-none">
      {/* Top Header Controls */}
      <div className="h-7 bg-[#1c1c24] border-b border-[#282834] px-2 flex items-center justify-between text-[11px] text-zinc-300">
        <div className="flex items-center space-x-2">
          <span className="text-sky-400 font-semibold">Program:</span>
          <span className="text-zinc-200 font-medium truncate">{project.name}</span>
          <span className="text-[10px] text-zinc-500">
            ({project.width}x{project.height} @ {project.fps}fps)
          </span>
        </div>

        <div className="flex items-center space-x-2">
          {/* Aspect Ratio Switcher */}
          <div className="flex items-center space-x-1 bg-[#121216] px-1.5 py-0.5 rounded border border-[#2c2c38]">
            <span className="text-[10px] text-zinc-400">Aspect:</span>
            <select
              id="aspect-ratio-select"
              value={project.aspectRatio}
              onChange={(e) => handleAspectChange(e.target.value as any)}
              className="bg-transparent text-sky-400 font-mono-code text-[10px] focus:outline-none cursor-pointer"
            >
              <option value="16:9" className="bg-[#1c1c24]">16:9 (Landscape)</option>
              <option value="9:16" className="bg-[#1c1c24]">9:16 (Shorts/TikTok)</option>
              <option value="1:1" className="bg-[#1c1c24]">1:1 (Square)</option>
              <option value="4:5" className="bg-[#1c1c24]">4:5 (Portrait)</option>
              <option value="21:9" className="bg-[#1c1c24]">21:9 (Cinematic)</option>
            </select>
          </div>

          {/* Safe Margins Toggle */}
          <button
            id="safe-margins-btn"
            onClick={() => setShowSafeMargins(s => !s)}
            title="Toggle Safe Margins (Title/Action Guides)"
            className={`p-1 rounded text-[10px] flex items-center space-x-1 transition-colors ${
              showSafeMargins ? 'bg-sky-500/20 text-sky-400 border border-sky-500/30' : 'text-zinc-400 hover:text-zinc-200 hover:bg-[#282834]'
            }`}
          >
            <ShieldCheck className="w-3 h-3" />
            <span className="hidden sm:inline">Safe Guides</span>
          </button>
        </div>
      </div>

      {/* Main Canvas Viewport Area with Audio VU Meters */}
      <div 
        ref={containerRef}
        className="flex-1 bg-[#09090b] relative flex items-center justify-center p-3 overflow-hidden"
      >
        {/* Canvas Stage */}
        <div 
          className="relative max-h-full max-w-full flex items-center justify-center shadow-2xl border border-[#272732] rounded bg-black"
          style={{
            aspectRatio: `${project.width} / ${project.height}`
          }}
        >
          <canvas
            ref={canvasRef}
            width={renderWidth}
            height={renderHeight}
            className="w-full h-full object-contain rounded"
          />
        </div>

        {/* Master Decibel Audio VU Meter on Right Edge */}
        <div className="absolute right-2 top-3 bottom-3 w-4 bg-[#121216] border border-[#2b2b36] rounded flex flex-col justify-end p-0.5 space-y-0.5 opacity-90 hover:opacity-100 transition-opacity">
          <div className="flex-1 w-full flex space-x-0.5 items-end justify-center">
            {/* Left Channel Bar */}
            <div className="w-1 bg-[#1e1e26] rounded-sm h-full flex flex-col justify-end overflow-hidden">
              <div 
                className="w-full transition-all duration-75 rounded-sm"
                style={{
                  height: `${meterLevels.left}%`,
                  background: meterLevels.left > 85 ? '#ef4444' : meterLevels.left > 65 ? '#f59e0b' : '#10b981'
                }}
              />
            </div>
            {/* Right Channel Bar */}
            <div className="w-1 bg-[#1e1e26] rounded-sm h-full flex flex-col justify-end overflow-hidden">
              <div 
                className="w-full transition-all duration-75 rounded-sm"
                style={{
                  height: `${meterLevels.right}%`,
                  background: meterLevels.right > 85 ? '#ef4444' : meterLevels.right > 65 ? '#f59e0b' : '#10b981'
                }}
              />
            </div>
          </div>
          <span className="text-[7px] font-mono-code text-zinc-500 text-center block">dB</span>
        </div>
      </div>

      {/* Transport Controls Bottom Bar */}
      <div className="h-9 bg-[#191920] border-t border-[#262632] px-3 flex items-center justify-between text-zinc-200">
        {/* Left: Timecode Readout */}
        <div className="flex items-center space-x-2">
          <div className="font-mono-code text-xs text-sky-400 font-semibold bg-[#101014] px-2 py-0.5 rounded border border-[#282834]">
            {formatTimecode(currentTime, project.fps)}
          </div>
        </div>

        {/* Center: Playback Transport Buttons */}
        <div className="flex items-center space-x-1">
          <button
            id="transport-step-back-btn"
            onClick={() => stepFrame(-1)}
            title="Step 1 Frame Back (Left Arrow / J)"
            className="p-1.5 rounded hover:bg-[#2c2c3a] text-zinc-300 hover:text-white transition-colors"
          >
            <SkipBack className="w-3.5 h-3.5" />
          </button>

          <button
            id="transport-play-btn"
            onClick={onTogglePlay}
            title="Play / Pause (Space / K)"
            className="w-8 h-8 rounded-full bg-sky-600 hover:bg-sky-500 text-white flex items-center justify-center transition-all shadow-md active:scale-95"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </button>

          <button
            id="transport-step-fwd-btn"
            onClick={() => stepFrame(1)}
            title="Step 1 Frame Forward (Right Arrow / L)"
            className="p-1.5 rounded hover:bg-[#2c2c3a] text-zinc-300 hover:text-white transition-colors"
          >
            <SkipForward className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Right: Quick actions (Marker, Snapshot frame) */}
        <div className="flex items-center space-x-1.5">
          <button
            id="transport-marker-btn"
            onClick={() => onAddMarker(currentTime)}
            title="Add Marker (M)"
            className="p-1.5 rounded hover:bg-[#2c2c3a] text-zinc-300 hover:text-white flex items-center space-x-1 text-xs"
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-[10px] hidden md:inline">Marker</span>
          </button>

          <button
            id="transport-snapshot-btn"
            onClick={onTakeSnapshot}
            title="Take Frame Snapshot (Save Image)"
            className="p-1.5 rounded hover:bg-[#2c2c3a] text-zinc-300 hover:text-white flex items-center space-x-1 text-xs"
          >
            <Camera className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-[10px] hidden md:inline">Snapshot</span>
          </button>
        </div>
      </div>
    </div>
  );
};
