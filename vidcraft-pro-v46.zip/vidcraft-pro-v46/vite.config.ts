import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      // v45: explicit WebView-safe compile target instead of Vite's
      // implicit default. 'es2020' covers Chrome 80+ / Android System
      // WebView from roughly Android 8+, the range Capacitor 7's own
      // minSdkVersion 23 floor can still encounter on a low-end device
      // with an outdated WebView. Nothing in this codebase currently
      // needs newer syntax (checked: no top-level await, no class private
      // fields, no structuredClone/OffscreenCanvas), so this is a safety
      // floor, not a functional change for desktop/web.
      target: 'es2020'
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
