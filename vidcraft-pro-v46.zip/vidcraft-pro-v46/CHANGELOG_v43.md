# VidCraft Pro — v43 Update: Android/Capacitor Foundation + Mobile Optimization

Base: v42 (`vidcraft-pro-v42-payment-boundary.zip`) — every file not listed
below is byte-for-byte unchanged from v42.

Scope, exactly as requested: Capacitor Android foundation, responsive
touch-first UI/UX, safe-area handling, scrolling/touch/timeline
interaction, and performance/memory efficiency — without changing desktop/
web editing behavior, and **without touching** AdMob, Google Play Billing,
payment, subscription, login, or any monetization logic. `license.ts`,
`licenseVerification.ts`, `payment.ts`, `paymentBackendContract.ts`,
`premiumFeatures.ts`, `razorpayConfig.ts`, `watermark.ts`, `auth.ts`,
`googleAuthAdapter.ts`, `firebaseConfig.ts`, `LicensePanel.tsx`,
`PremiumBadge.tsx`, and the license/watermark UI inside `ExportModal.tsx`
are all **untouched** — not read into any change, not imported by any new
file.

## New files

- **`src/utils/deviceTier.ts`** — classifies the current device as
  `low` / `mid` / `high` performance using CPU core count
  (`navigator.hardwareConcurrency`), approximate RAM
  (`navigator.deviceMemory`), and pixel density (`devicePixelRatio`). Fails
  safe to `high` (today's v42 behavior) whenever a signal is unavailable,
  so no device is ever mis-classified as low-end just because an API is
  missing. Also exports `getPreviewResolutionCap(tier)`.

## Changed — Capacitor / Android foundation

- **`capacitor.config.ts`** — added `android.backgroundColor: '#121216'`
  (matches the app's own background so there's no white flash on cold
  start/rotation) and a comment block documenting the one native line
  (`WindowCompat.setDecorFitsSystemWindows`) needed for true edge-to-edge
  rendering on Android <15, to be added by hand once `npm run
  cap:add:android` generates the `android/` project. This sandbox has no
  network access or Android SDK, so `android/` itself could not be
  generated here — see `MOBILE_BUILD.md`'s new v43 section for exactly
  what to run locally; nothing about the existing build steps changed.

## Changed — Safe-area & touch foundation (`src/index.css`)

- Added `--safe-top/bottom/left/right` CSS variables (from
  `env(safe-area-inset-*)`, 0px and therefore inert on desktop/browsers
  without notches) and `.safe-top` / `.safe-bottom` / `.safe-x` utility
  classes.
- `overscroll-behavior: none` on `html, body` — stops the Android
  WebView's rubber-band bounce and Chrome's pull-to-refresh from firing
  during clip drags/timeline scrubs, which are handled entirely by this
  app's own pointer-event logic.
- `touch-action: manipulation` + transparent tap-highlight on `body` —
  removes the ~300ms tap delay and gray tap-flash Android WebViews show.
- A global rule matches every element already using Tailwind's
  `overflow-y-auto` / `overflow-x-auto` / `overflow-auto` classes and adds
  momentum scrolling + `overscroll-behavior: contain`, so no per-component
  edits were needed to fix scroll feel across the media bin, effects list,
  audio mixer, dropdown menus, and the mobile "Tools" tab.
- `.tap-target` utility (44px minimum) for future opt-in use.

## Changed — Responsive/touch-first UI

- **`src/App.tsx`**
  - Root container now gets `.safe-x` padding (protects content from a
    notch/camera-cutout on the left/right edges in landscape — the
    orientation most people actually edit video in).
  - `isMobile` is now passed down to `HeaderMenuBar` and `Timeline`
    (previously only used for the top-level preview/media/timeline/tools
    panel switch that already existed in v42).
  - New: playback now auto-pauses when the app is backgrounded
    (`visibilitychange` → `hidden`) — see Performance section below.
- **`src/components/HeaderMenuBar.tsx`** (new optional `isMobile` prop,
  default `false` — desktop/web output is unchanged unless a caller passes
  `true`, which only `App.tsx`'s mobile path does)
  - `.safe-top` padding so the toolbar clears the status bar/notch.
  - Taller bar (h-12 vs h-10) and larger tap padding on the File/Edit/
    Shortcuts buttons, workspace tabs, undo/redo/snap icons, and the
    Export button when `isMobile`.
  - Workspace tab labels collapse to icon-only on mobile to fit more
    tabs in less width without a horizontal scroll fight.
  - **Fixed a real touch bug**: the File/Edit dropdown menus only closed
    on `onMouseLeave`, which never fires on touch — a menu opened by tap
    had no way to be dismissed except tapping the exact same button again.
    Added a tap/click-outside backdrop that closes any open menu; the
    existing `onMouseLeave` behavior for mouse users is untouched.
- **`src/components/Timeline.tsx`** (new optional `isMobile` prop, default
  `false`)
  - Left/right trim handles widen from 12px to 20px hit width on mobile
    (was hover-revealed and hover doesn't exist on touch, so it's now
    always visible at 70% opacity instead).
  - Zoom in/out buttons: 28px → 36px on mobile.
  - Track visibility/mute/lock buttons: padding increased for a ~44px
    touch target on mobile.
  - Drag/trim/scrub elements already used Pointer Events and `touch-none`
    in v42 — that part needed no change and is confirmed still correct.

## Changed — Performance & memory

- **`src/components/ProgramMonitor.tsx`** — the live preview canvas's
  resolution cap is now `getPreviewResolutionCap()` (640/960/1280px by
  device tier) instead of a fixed `1280`. Desktop/high-end devices still
  get exactly 1280 — identical to v42. Only lower-tier Android hardware
  renders a smaller preview, cutting per-frame canvas-fill/filter cost
  where it matters most (battery, thermal throttling, dropped frames
  during scrubbing). **Export always renders at full project resolution
  regardless of this cap** — `ExportModal.tsx` was not touched and builds
  its own independent full-resolution canvas, exactly as in v42.
- **`src/App.tsx`** — added an auto-pause-on-background effect: when
  `document.visibilityState` becomes `hidden` (Android home button, app
  switcher, or a browser tab switch) and playback is running, it's paused.
  Without this, the Program Monitor's render loop and `audioEngine` kept
  fully decoding/compositing/playing while nothing was visible — wasted
  CPU/GPU/battery, worse on a phone than a desktop. Resuming is a normal
  tap on Play, same gesture as pausing by hand always was; no editing
  state is touched.
- Confirmed `videoCompositor.pruneUnusedAssets` (memory cleanup for
  cached `<video>`/`<img>` elements) is already correctly wired to run on
  every `assets` change (v42's C2 fix) — verified, not modified.

## Verified, not changed

- No mouse-only event handlers exist anywhere in the codebase
  (`onMouseDown`/`onMouseMove`/`onMouseUp`) — every drag/scrub/trim
  interaction already uses Pointer Events or native `<input type="range">`
  sliders, both of which work correctly on touch without modification.
- `ExportModal.tsx` was deliberately left untouched, including its layout
  CSS, because it contains the dev/test license-tier switch used to
  preview the Free-tier watermark — in scope of the "don't touch payment/
  license" instruction even for unrelated responsiveness tweaks. Its
  modal body doesn't yet clamp to viewport height on very short landscape
  phone screens; noted as a follow-up for a future pass that's explicitly
  scoped to touch it.
- `LicensePanel.tsx`, `PremiumBadge.tsx`, `license.ts`,
  `licenseVerification.ts`, `payment.ts`, `paymentBackendContract.ts`,
  `premiumFeatures.ts`, `razorpayConfig.ts`, `watermark.ts`, `auth.ts`,
  `googleAuthAdapter.ts`, `firebaseConfig.ts` — all untouched.

## Known follow-ups (not done in this pass, out of scope by request)

- `ExportModal.tsx` has no `max-h`/scroll clamp for very short landscape
  screens — deferred since touching it means touching license/watermark UI.
- `ProjectMediaBin.tsx`, `EffectsLibrary.tsx`, `EffectControls.tsx`,
  `LumetriColorPanel.tsx`, `EssentialGraphicsPanel.tsx`, and
  `AudioMixerPanel.tsx` still use desktop-density icon buttons in the
  mobile "Media"/"Tools" tabs — functional (scrolling now works correctly
  there via the global CSS fix above) but not yet touch-target-optimized
  like the header and timeline were in this pass.
- The real `android/` native project, Gradle sync, and first APK build
  still have to happen on your own machine (Android Studio + SDK) — see
  `MOBILE_BUILD.md`'s new v43 section.
