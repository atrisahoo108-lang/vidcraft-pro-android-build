import React, { useRef, useState, useEffect } from 'react';
import { 
  Pointer, Scissors, MoveHorizontal, ZoomIn, ZoomOut, Maximize2, 
  Lock, Unlock, Eye, EyeOff, Volume2, VolumeX, Magnet, Plus, 
  Trash2, Layers, Type, Music, Film, SplitSquareVertical, Sparkles 
} from 'lucide-react';
import { Clip, Track, ProjectSettings, ToolMode } from '../types';
import { formatTimecode } from '../utils/timecode';

interface TimelineProps {
  project: ProjectSettings;
  currentTime: number;
  setCurrentTime: (time: number | ((prev: number) => number)) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  tracks: Track[];
  clips: Clip[];
  onUpdateClips: (clips: Clip[]) => void;
  // Called once at the start of a drag/resize/split gesture — before the
  // first onUpdateClips of that gesture — so the whole gesture becomes a
  // single undo step instead of one step per pointermove tick.
  onBeginClipEdit?: (label: string) => void;
  selectedClipId: string | null;
  onSelectClip: (clipId: string | null) => void;
  activeTool: ToolMode;
  setActiveTool: (tool: ToolMode) => void;
  zoomLevel: number;
  setZoomLevel: React.Dispatch<React.SetStateAction<number>>;
  snapping: boolean;
  setSnapping: React.Dispatch<React.SetStateAction<boolean>>;
  onDeleteClip: (clipId: string) => void;
  onAddTrack: (type: 'video' | 'audio') => void;
  onUpdateTrack?: (trackId: string, updates: Partial<Track>) => void;
  // Razor Tool (C): reports the clip clicked + the clicked timeline position
  // so the parent can run the split through the same logic as Ctrl+K
  // (speed-aware source offset, keyframe re-basing) instead of duplicating
  // that math here.
  onSplitClipAtTime?: (clipId: string, time: number) => void;
  // v43: widens trim handles and toolbar hit-targets for touch without
  // changing anything for desktop/mouse (defaults to false there).
  isMobile?: boolean;
}

export const Timeline: React.FC<TimelineProps> = ({
  project,
  currentTime,
  setCurrentTime,
  isPlaying,
  onTogglePlay,
  tracks,
  clips,
  onUpdateClips,
  onBeginClipEdit,
  selectedClipId,
  onSelectClip,
  activeTool,
  setActiveTool,
  zoomLevel,
  setZoomLevel,
  snapping,
  setSnapping,
  onDeleteClip,
  onAddTrack,
  onUpdateTrack,
  onSplitClipAtTime,
  isMobile = false
}) => {
  const rulerRef = useRef<HTMLDivElement | null>(null);
  const tracksContainerRef = useRef<HTMLDivElement | null>(null);
  const [isScrubbing, setIsScrubbing] = useState(false);
  const [draggingClipId, setDraggingClipId] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState<number>(0);
  const [resizingClip, setResizingClip] = useState<{
    id: string;
    edge: 'left' | 'right';
    initialTime: number;
    initialDuration: number;
    // Ripple Trim: clips on the same track positioned after this one,
    // snapshotted once at drag-start (only when the Ripple Edit tool is
    // active) so each pointermove frame can compute their new position as
    // an absolute offset from a fixed baseline — same approach as the
    // trimmed clip's own position, which is always derived fresh from the
    // current mouse position rather than accumulated frame-to-frame.
    rippleFollowers?: { id: string; startTime: number }[];
  } | null>(null);

  // Time conversion helper: seconds to pixels
  const timeToPx = (time: number) => time * zoomLevel;
  const pxToTime = (px: number) => Math.max(0, px / zoomLevel);

  // Magnetic snapping — shared by clip drag and left/right trim below.
  // Targets are the playhead plus every other clip's start/end edge;
  // `excludeClipId` keeps a clip from snapping to its own other edge.
  const getSnapTargets = (excludeClipId: string): number[] => {
    const targets: number[] = [currentTime];
    clips.forEach(c => {
      if (c.id === excludeClipId) return;
      targets.push(c.startTime, c.startTime + c.duration);
    });
    return targets;
  };

  // Returns the closest target within `threshold`, or `value` unchanged if
  // nothing is close enough — i.e. normal free movement when nothing is
  // nearby.
  const snapValue = (value: number, targets: number[], threshold: number): number => {
    let best = value;
    let bestDist = threshold;
    for (const t of targets) {
      const dist = Math.abs(value - t);
      if (dist < bestDist) {
        bestDist = dist;
        best = t;
      }
    }
    return best;
  };

  // Ripple Trim: clips on the same track that start at/after `boundary`
  // (the trimmed clip's current right edge), excluding the trimmed clip
  // itself. Small epsilon tolerance for float rounding on adjacent clips.
  const getRippleFollowers = (trackId: string, excludeClipId: string, boundary: number) => {
    return clips
      .filter(c => c.trackId === trackId && c.id !== excludeClipId && c.startTime >= boundary - 0.01)
      .map(c => ({ id: c.id, startTime: c.startTime }));
  };

  // Scrubbing on Timeline Ruler
  const handleRulerPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!tracksContainerRef.current) return;
    setIsScrubbing(true);
    const rect = tracksContainerRef.current.getBoundingClientRect();
    const scrollLeft = tracksContainerRef.current.scrollLeft;
    const clickX = e.clientX - rect.left + scrollLeft;
    const targetTime = Math.min(project.duration, Math.max(0, pxToTime(clickX)));
    setCurrentTime(targetTime);
  };

  useEffect(() => {
    const handlePointerMove = (e: PointerEvent) => {
      if (isScrubbing && tracksContainerRef.current) {
        const rect = tracksContainerRef.current.getBoundingClientRect();
        const scrollLeft = tracksContainerRef.current.scrollLeft;
        const clickX = e.clientX - rect.left + scrollLeft;
        const targetTime = Math.min(project.duration, Math.max(0, pxToTime(clickX)));
        setCurrentTime(targetTime);
      } else if (draggingClipId && tracksContainerRef.current) {
        const rect = tracksContainerRef.current.getBoundingClientRect();
        const scrollLeft = tracksContainerRef.current.scrollLeft;
        const mouseX = e.clientX - rect.left + scrollLeft;
        let newStartTime = Math.max(0, pxToTime(mouseX - dragOffset));

        // Magnetic Snapping — snap the dragged clip's leading edge first;
        // if that edge isn't near anything, try its trailing edge (e.g.
        // dragging a clip up to butt against the next one's start).
        if (snapping) {
          const draggedClip = clips.find(c => c.id === draggingClipId);
          if (draggedClip) {
            const snapThreshold = 0.25; // seconds — same threshold as before
            const targets = getSnapTargets(draggingClipId);
            const snappedStart = snapValue(newStartTime, targets, snapThreshold);
            if (snappedStart !== newStartTime) {
              newStartTime = snappedStart;
            } else {
              const clipEnd = newStartTime + draggedClip.duration;
              const snappedEnd = snapValue(clipEnd, targets, snapThreshold);
              if (snappedEnd !== clipEnd) {
                newStartTime = Math.max(0, snappedEnd - draggedClip.duration);
              }
            }
          }
        }

        const updated = clips.map(c => c.id === draggingClipId ? { ...c, startTime: newStartTime } : c);
        onUpdateClips(updated);
      } else if (resizingClip && tracksContainerRef.current) {
        const rect = tracksContainerRef.current.getBoundingClientRect();
        const scrollLeft = tracksContainerRef.current.scrollLeft;
        const mouseX = e.clientX - rect.left + scrollLeft;
        let mouseTime = pxToTime(mouseX);

        // Magnetic Snapping — same targets/threshold as clip drag, applied
        // to the edge being trimmed before it feeds into the existing
        // duration/inPoint/outPoint math below (unchanged).
        if (snapping) {
          const snapThreshold = 0.25;
          mouseTime = snapValue(mouseTime, getSnapTargets(resizingClip.id), snapThreshold);
        }

        const updated = clips.map(c => {
          if (c.id !== resizingClip.id) return c;
          if (resizingClip.edge === 'right') {
            const newDur = Math.max(0.2, mouseTime - c.startTime);
            return { ...c, duration: newDur, outPoint: c.inPoint + newDur };
          } else {
            const diff = mouseTime - c.startTime;
            const newStart = Math.max(0, mouseTime);
            const newDur = Math.max(0.2, c.duration - diff);
            const newIn = Math.max(0, c.inPoint + diff);
            return { ...c, startTime: newStart, duration: newDur, inPoint: newIn };
          }
        });

        // Ripple Trim: when the Ripple Edit tool was active at drag-start,
        // shift the clips captured as "following" this one by the same
        // amount this clip's duration changed — closing the gap when it
        // got shorter, opening one when it got longer. Each follower's new
        // position is computed as an absolute offset from its drag-start
        // position (the snapshot taken in rippleFollowers), matching how
        // the trimmed clip's own new position is always derived fresh from
        // the current mouse position rather than accumulated frame-to-
        // frame — avoids any drift across a long drag.
        let finalUpdated = updated;
        if (resizingClip.rippleFollowers && resizingClip.rippleFollowers.length > 0) {
          const trimmedClip = updated.find(c => c.id === resizingClip.id);
          if (trimmedClip) {
            // Followers are anchored to this clip's ORIGINAL right edge (see
            // getRippleFollowers above), so they must shift by how much that
            // right edge actually moved — not by the duration change. Those
            // are the same number for a right-edge trim (start is fixed, so
            // duration delta == right-edge delta), but they diverge for a
            // left-edge trim: trimming the left edge changes duration while
            // leaving the right edge in place (see the left-edge branch
            // above), so followers correctly get shift=0 there instead of
            // incorrectly sliding by the duration change and opening a gap.
            const originalRightEdge = resizingClip.initialTime + resizingClip.initialDuration;
            const newRightEdge = trimmedClip.startTime + trimmedClip.duration;
            const shift = newRightEdge - originalRightEdge;
            if (shift !== 0) {
              const followerMap = new Map<string, number>(resizingClip.rippleFollowers.map(f => [f.id, f.startTime]));
              finalUpdated = updated.map(c => {
                const originalStart = followerMap.get(c.id);
                if (originalStart === undefined) return c;
                return { ...c, startTime: Math.max(0, originalStart + shift) };
              });
            }
          }
        }

        onUpdateClips(finalUpdated);
      }
    };

    const handlePointerUp = () => {
      setIsScrubbing(false);
      setDraggingClipId(null);
      setResizingClip(null);
    };

    if (isScrubbing || draggingClipId || resizingClip) {
      // Pointer events unify mouse, touch, and pen — this makes drag/scrub/trim
      // work on phones and tablets, not just with a mouse.
      window.addEventListener('pointermove', handlePointerMove);
      window.addEventListener('pointerup', handlePointerUp);
      window.addEventListener('pointercancel', handlePointerUp);
    }
    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
    };
  }, [isScrubbing, draggingClipId, dragOffset, resizingClip, clips, zoomLevel, snapping, currentTime, project.duration, onUpdateClips]);

  // Razor Tool (C): click a clip to split it at the clicked position.
  // The actual split (speed-aware source offset, keyframe re-basing) is
  // owned by App.tsx's splitClipAtTime — shared with the Ctrl+K shortcut —
  // this handler only figures out *where* the click landed.
  const handleClipClick = (e: React.MouseEvent, clip: Clip) => {
    e.stopPropagation();

    if (activeTool === 'razor') {
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const splitTimelineTime = clip.startTime + pxToTime(clickX);
      onSplitClipAtTime?.(clip.id, splitTimelineTime);
      return;
    }

    onSelectClip(clip.id);
  };

  const handleClipPointerDown = (e: React.PointerEvent, clip: Clip) => {
    if (activeTool === 'razor') return;
    e.stopPropagation();
    onSelectClip(clip.id);

    if (activeTool === 'select' || activeTool === 'ripple-edit') {
      onBeginClipEdit?.('Move Clip');
      setDraggingClipId(clip.id);
      const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
      setDragOffset(e.clientX - rect.left);
    }
  };

  const totalWidth = Math.max(1200, timeToPx(project.duration) + 300);

  // Ruler time marks (every 1s, 5s) + Project Markers
  const renderRulerTicks = () => {
    const ticks = [];
    const step = zoomLevel > 40 ? 1 : zoomLevel > 15 ? 2 : 5;
    for (let t = 0; t <= project.duration + 10; t += step) {
      ticks.push(
        <div
          key={`tick-${t}`}
          className="absolute top-0 bottom-0 flex flex-col justify-between pointer-events-none border-l border-zinc-700/60"
          style={{ left: `${timeToPx(t)}px` }}
        >
          <span className="text-[9px] font-mono-code text-zinc-400 pl-1 select-none">
            {formatTimecode(t, project.fps, false)}
          </span>
          <div className="h-2 w-px bg-zinc-600" />
        </div>
      );
    }

    // Render Timeline Markers
    (project.markers || []).forEach(m => {
      ticks.push(
        <div
          key={m.id}
          onClick={(e) => {
            e.stopPropagation();
            setCurrentTime(m.time);
          }}
          title={`${m.label} (${formatTimecode(m.time, project.fps, false)})`}
          className="absolute top-0.5 z-20 cursor-pointer group/m flex flex-col items-center -ml-1.5"
          style={{ left: `${timeToPx(m.time)}px` }}
        >
          <div 
            className="w-3 h-3 rotate-45 rounded-[1px] shadow border border-black/40 hover:scale-125 transition-transform"
            style={{ backgroundColor: m.color || '#f59e0b' }}
          />
          <span className="opacity-0 group-hover/m:opacity-100 transition-opacity bg-black/90 text-white text-[9px] px-1 py-0.5 rounded pointer-events-none whitespace-nowrap absolute top-4 shadow-lg border border-zinc-700 z-30">
            {m.label}
          </span>
        </div>
      );
    });

    return ticks;
  };

  return (
    <div className="h-full flex bg-[#16161a] border-t border-[#262632] select-none">
      {/* 1. Left Toolbar: Tool Palette (V, A, B, C, Y, P, H, T) */}
      <div className="w-11 bg-[#1a1a22] border-r border-[#262632] flex flex-col items-center py-2 space-y-1 z-20">
        {[
          { id: 'select', label: 'Selection Tool (V)', icon: Pointer },
          { id: 'track-select', label: 'Track Select Forward (A)', icon: MoveHorizontal },
          { id: 'ripple-edit', label: 'Ripple Edit Tool (B)', icon: SplitSquareVertical },
          { id: 'razor', label: 'Razor Blade Tool (C)', icon: Scissors },
          { id: 'hand', label: 'Hand Tool (H)', icon: Maximize2 },
          { id: 'text', label: 'Type Tool (T)', icon: Type },
        ].map(tool => {
          const Icon = tool.icon;
          const isActive = activeTool === tool.id;
          return (
            <button
              key={tool.id}
              onClick={() => setActiveTool(tool.id as ToolMode)}
              title={tool.label}
              className={`w-7 h-7 rounded flex items-center justify-center transition-all ${
                isActive ? 'bg-sky-600 text-white shadow-md' : 'text-zinc-400 hover:text-zinc-100 hover:bg-[#282834]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
            </button>
          );
        })}

        <div className="w-6 h-px bg-[#2d2d38] my-1" />

        {/* Magnetic Snapping Toggle */}
        <button
          onClick={() => setSnapping(s => !s)}
          title={`Magnetic Snapping (S): ${snapping ? 'ON' : 'OFF'}`}
          className={`w-7 h-7 rounded flex items-center justify-center transition-all ${
            snapping ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-zinc-500 hover:text-zinc-200'
          }`}
        >
          <Magnet className="w-3.5 h-3.5" />
        </button>

        {/* Zoom Controls */}
        <div className="flex flex-col space-y-1 pt-1">
          <button
            onClick={() => setZoomLevel(z => Math.min(120, z * 1.3))}
            title="Zoom In (=)"
            className={`rounded text-zinc-400 hover:text-white hover:bg-[#282834] flex items-center justify-center ${isMobile ? 'w-9 h-9' : 'w-7 h-7'}`}
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoomLevel(z => Math.max(8, z / 1.3))}
            title="Zoom Out (-)"
            className={`rounded text-zinc-400 hover:text-white hover:bg-[#282834] flex items-center justify-center ${isMobile ? 'w-9 h-9' : 'w-7 h-7'}`}
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 2. Track Header Column (Left Side of Tracks) */}
      <div className="w-48 bg-[#181820] border-r border-[#262632] flex flex-col shrink-0 z-10">
        {/* Ruler Corner Spacer */}
        <div className="h-7 bg-[#1e1e26] border-b border-[#282834] px-2 flex items-center justify-between text-[10px] text-zinc-400">
          <span className="font-semibold text-zinc-300">Tracks</span>
          <div className="flex items-center space-x-1">
            <button
              onClick={() => onAddTrack('video')}
              title="Add Video Track"
              className="p-0.5 rounded hover:bg-[#2e2e3c] text-sky-400 text-[10px] flex items-center"
            >
              <Plus className="w-3 h-3" />
              <span>V</span>
            </button>
            <button
              onClick={() => onAddTrack('audio')}
              title="Add Audio Track"
              className="p-0.5 rounded hover:bg-[#2e2e3c] text-emerald-400 text-[10px] flex items-center"
            >
              <Plus className="w-3 h-3" />
              <span>A</span>
            </button>
          </div>
        </div>

        {/* Track Headers */}
        <div className="flex-1 overflow-y-hidden">
          {tracks.map(track => {
            const isVideo = track.type === 'video';
            return (
              <div
                key={track.id}
                style={{ height: `${track.height}px` }}
                className="border-b border-[#242430] bg-[#1a1a24] px-2 flex items-center justify-between text-xs"
              >
                <div className="flex items-center space-x-1.5 truncate">
                  {isVideo ? (
                    <Film className="w-3 h-3 text-sky-400 shrink-0" />
                  ) : (
                    <Music className="w-3 h-3 text-emerald-400 shrink-0" />
                  )}
                  <span className="font-medium text-[11px] text-zinc-300 truncate" title={track.name}>
                    {track.name.split(' - ')[0]}
                  </span>
                </div>

                <div className="flex items-center space-x-1 shrink-0">
                  {isVideo ? (
                    <button
                      onClick={() => onUpdateTrack?.(track.id, { isVisible: !track.isVisible })}
                      className={`${isMobile ? 'p-2' : 'p-1'} ${track.isVisible ? 'text-zinc-400 hover:text-zinc-200' : 'text-zinc-600 hover:text-zinc-400'}`}
                      title={track.isVisible ? "Hide Track Output" : "Show Track Output"}
                    >
                      {track.isVisible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3 text-red-400" />}
                    </button>
                  ) : (
                    <button
                      onClick={() => onUpdateTrack?.(track.id, { isMuted: !track.isMuted })}
                      className={`${isMobile ? 'p-2' : 'p-1'} ${track.isMuted ? 'text-red-500' : 'text-zinc-400 hover:text-zinc-200'}`}
                      title={track.isMuted ? "Unmute Track" : "Mute Track"}
                    >
                      {track.isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3" />}
                    </button>
                  )}

                  <button
                    onClick={() => onUpdateTrack?.(track.id, { isLocked: !track.isLocked })}
                    className={`${isMobile ? 'p-2' : 'p-1'} ${track.isLocked ? 'text-amber-400' : 'text-zinc-500 hover:text-zinc-300'}`}
                    title={track.isLocked ? "Unlock Track" : "Lock Track"}
                  >
                    {track.isLocked ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Main Timeline Tracks Stage with Playhead Needle */}
      <div 
        ref={tracksContainerRef}
        className="flex-1 flex flex-col overflow-x-auto overflow-y-hidden relative bg-[#121216]"
      >
        {/* Timeline SMPTE Ruler */}
        <div
          ref={rulerRef}
          onPointerDown={handleRulerPointerDown}
          style={{ width: `${totalWidth}px` }}
          className="h-7 bg-[#1c1c24] border-b border-[#282834] relative cursor-pointer select-none touch-none"
        >
          {renderRulerTicks()}
        </div>

        {/* Track Lanes */}
        <div style={{ width: `${totalWidth}px` }} className="flex-1 relative">
          {tracks.map(track => {
            const trackClips = clips.filter(c => c.trackId === track.id);
            const isVideo = track.type === 'video';

            return (
              <div
                key={track.id}
                style={{ height: `${track.height}px` }}
                className="border-b border-[#21212c] bg-[#14141a]/60 relative"
              >
                {/* Render Track Clips */}
                {trackClips.map(clip => {
                  const isSelected = selectedClipId === clip.id;
                  const leftPx = timeToPx(clip.startTime);
                  const widthPx = Math.max(12, timeToPx(clip.duration));

                  return (
                    <div
                      key={clip.id}
                      onClick={(e) => handleClipClick(e, clip)}
                      onPointerDown={(e) => handleClipPointerDown(e, clip)}
                      style={{
                        left: `${leftPx}px`,
                        width: `${widthPx}px`,
                        backgroundColor: clip.color || (isVideo ? '#0369a1' : '#047857')
                      }}
                      className={`absolute top-1 bottom-1 rounded border cursor-pointer transition-shadow overflow-hidden group select-none touch-none flex items-center justify-between px-2 ${
                        isSelected 
                          ? 'border-white ring-2 ring-sky-400 shadow-lg z-10' 
                          : 'border-black/40 hover:brightness-110'
                      }`}
                    >
                      {/* Left Trim Handle */}
                      <div
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          onBeginClipEdit?.('Trim Clip');
                          setResizingClip({
                            id: clip.id, edge: 'left', initialTime: clip.startTime, initialDuration: clip.duration,
                            rippleFollowers: activeTool === 'ripple-edit'
                              ? getRippleFollowers(clip.trackId, clip.id, clip.startTime + clip.duration)
                              : undefined
                          });
                        }}
                        className={`absolute left-0 top-0 bottom-0 bg-white/20 hover:bg-white/60 cursor-ew-resize transition-all z-20 touch-none ${
                          isMobile ? 'w-5 opacity-70' : 'w-3 hover:w-4 opacity-40 group-hover:opacity-100'
                        }`}
                      />

                      {/* Clip Label & Icon */}
                      <div className="flex items-center space-x-1 truncate max-w-[85%] pointer-events-none">
                        {clip.type === 'text' && <Type className="w-3 h-3 text-amber-200 shrink-0" />}
                        {clip.type === 'video' && <Film className="w-3 h-3 text-sky-200 shrink-0" />}
                        {clip.type === 'audio' && <Music className="w-3 h-3 text-emerald-200 shrink-0" />}
                        <span className="text-[10px] font-semibold text-white truncate drop-shadow-sm">
                          {clip.name}
                        </span>
                      </div>

                      {/* Transition In / Out Indicators */}
                      {clip.transitionIn && clip.transitionIn.type !== 'none' && (
                        <div 
                          className="absolute left-0 top-0 bottom-0 bg-white/30 border-r border-white/40 pointer-events-none"
                          style={{ width: `${Math.min(widthPx * 0.4, timeToPx(clip.transitionIn.duration))}px` }}
                        />
                      )}
                      {clip.transitionOut && clip.transitionOut.type !== 'none' && (
                        <div 
                          className="absolute right-0 top-0 bottom-0 bg-white/30 border-l border-white/40 pointer-events-none"
                          style={{ width: `${Math.min(widthPx * 0.4, timeToPx(clip.transitionOut.duration))}px` }}
                        />
                      )}

                      {/* Right Trim Handle */}
                      <div
                        onPointerDown={(e) => {
                          e.stopPropagation();
                          onBeginClipEdit?.('Trim Clip');
                          setResizingClip({
                            id: clip.id, edge: 'right', initialTime: clip.startTime, initialDuration: clip.duration,
                            rippleFollowers: activeTool === 'ripple-edit'
                              ? getRippleFollowers(clip.trackId, clip.id, clip.startTime + clip.duration)
                              : undefined
                          });
                        }}
                        className={`absolute right-0 top-0 bottom-0 bg-white/20 hover:bg-white/60 cursor-ew-resize transition-all z-20 touch-none ${
                          isMobile ? 'w-5 opacity-70' : 'w-3 hover:w-4 opacity-40 group-hover:opacity-100'
                        }`}
                      />
                    </div>
                  );
                })}
              </div>
            );
          })}

          {/* Red SMPTE Playhead Needle Line */}
          <div
            className="absolute top-0 bottom-0 w-0.5 bg-red-500 z-30 pointer-events-none flex flex-col items-center"
            style={{ left: `${timeToPx(currentTime)}px` }}
          >
            {/* Playhead Head Marker */}
            <div className="-mt-7 w-3.5 h-4 bg-red-500 rounded-t-sm rotate-180 flex items-center justify-center shadow-md">
              <div className="w-1 h-2 bg-white rounded-full" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
