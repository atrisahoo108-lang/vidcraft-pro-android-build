import React, { useState, useEffect } from 'react';
import { KeyRound, X, ShieldAlert, ShieldCheck, ShieldQuestion, Trash2, LogIn, LogOut, UserCircle2, UserPlus } from 'lucide-react';
import {
  getLicenseStatus,
  setProductionLicense,
  clearProductionLicense,
  isTestOverrideActive,
  type LicenseStatusSnapshot,
  type LicenseStatus,
  type LicenseTier
} from '../utils/license';
import type { LicenseVerificationStatus } from '../utils/licenseVerification';
import {
  getAuthState,
  subscribeToAuthState,
  signInWithGoogle,
  signInWithEmail,
  createAccountWithEmail,
  signOut as authSignOut,
  type AuthState
} from '../utils/auth';

interface LicensePanelProps {
  isOpen: boolean;
  onClose: () => void;
}

// Presentation-only — maps the real verification result (from license.ts /
// licenseVerification.ts) to display text. Does not decide anything.
function verificationLabel(status: LicenseVerificationStatus): string {
  switch (status) {
    case 'verified': return 'Verified';
    case 'unverified': return 'Unverified';
    case 'not-configured': return 'Verification not configured';
    case 'invalid': return 'Invalid';
    default: return 'Unknown';
  }
}

// Presentation-only date formatting. Never throws, never treats an
// unparseable date as "no expiry" — that distinction belongs to license.ts
// (isProductionLicenseUsable), this just has to describe it safely.
function formatExpiry(expiryDate: string | null): string {
  if (expiryDate === null) return 'No expiry';
  const time = new Date(expiryDate).getTime();
  if (Number.isNaN(time)) return 'Invalid date';
  const isPast = time < Date.now();
  const formatted = new Date(time).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
  return isPast ? `${formatted} (expired)` : formatted;
}

// Presentation-only — turns a Firebase Auth error into a short, safe,
// user-facing message. Falls back to the error's own message (Firebase's
// Auth error messages never include secrets/stack traces) for anything
// not explicitly covered.
function describeAuthError(err: unknown): string {
  const code = (err as { code?: string } | undefined)?.code;
  switch (code) {
    case 'auth/invalid-email':
      return 'That email address looks invalid.';
    case 'auth/missing-password':
    case 'auth/weak-password':
      return 'Password is too weak — use at least 6 characters.';
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'Incorrect email or password.';
    case 'auth/user-not-found':
      return 'No account found with that email.';
    case 'auth/email-already-in-use':
      return 'An account with that email already exists — try signing in instead.';
    case 'auth/too-many-requests':
      return 'Too many attempts — please wait a moment and try again.';
    case 'auth/network-request-failed':
      return 'No network connection — signing in requires the internet.';
    case 'auth/operation-not-allowed':
      return 'Email/password sign-in is not enabled for this project.';
    default:
      return err instanceof Error ? err.message : 'Something went wrong. Please try again.';
  }
}

const LICENSE_STATUS_OPTIONS: LicenseStatus[] = ['active', 'expired', 'cancelled', 'none'];

export const LicensePanel: React.FC<LicensePanelProps> = ({ isOpen, onClose }) => {
  const [snapshot, setSnapshot] = useState<LicenseStatusSnapshot>(() => getLicenseStatus());
  const [notice, setNotice] = useState<string | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Account (auth) state — entirely separate from license state above.
  // Signing in/out here never touches getLicenseStatus() or its inputs.
  const [authState, setAuthState] = useState<AuthState>(() => getAuthState());
  const [authNotice, setAuthNotice] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);

  // Email/Password (v40) — transient form-only values. Never written to
  // localStorage/IndexedDB/project data anywhere in this file; `password`
  // only ever exists in this local state long enough to pass it to
  // signInWithEmail()/createAccountWithEmail() below, which themselves
  // only forward it into the one Firebase SDK call that needs it.
  const [emailValue, setEmailValue] = useState('');
  const [passwordValue, setPasswordValue] = useState('');
  const [isEmailBusy, setIsEmailBusy] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setAuthState(getAuthState());
    const unsubscribe = subscribeToAuthState(setAuthState);
    return unsubscribe;
  }, [isOpen]);

  useEffect(() => {
    if (!authNotice) return;
    const timer = setTimeout(() => setAuthNotice(null), 3500);
    return () => clearTimeout(timer);
  }, [authNotice]);

  const handleGoogleSignIn = async () => {
    setIsSigningIn(true);
    setAuthNotice(null);
    try {
      await signInWithGoogle();
    } catch (err) {
      // Covers both "user closed the popup" and any real Firebase error —
      // never lets a rejected sign-in crash the panel.
      setAuthNotice(describeAuthError(err));
    } finally {
      setIsSigningIn(false);
    }
  };

  // Shared guard for both email actions below: never sends a request with
  // an empty field (test E) — Firebase itself would reject these anyway,
  // but this avoids the round-trip and gives an immediate, clear notice.
  const validateEmailForm = (): string | null => {
    if (!emailValue.trim() || !passwordValue) {
      return 'Enter both an email and password.';
    }
    return null;
  };

  const handleEmailSignIn = async () => {
    const validationError = validateEmailForm();
    if (validationError) {
      setAuthNotice(validationError);
      return;
    }
    setIsEmailBusy(true);
    setAuthNotice(null);
    try {
      await signInWithEmail(emailValue.trim(), passwordValue);
      setPasswordValue('');
    } catch (err) {
      setAuthNotice(describeAuthError(err));
    } finally {
      setIsEmailBusy(false);
    }
  };

  const handleCreateAccount = async () => {
    const validationError = validateEmailForm();
    if (validationError) {
      setAuthNotice(validationError);
      return;
    }
    setIsEmailBusy(true);
    setAuthNotice(null);
    try {
      await createAccountWithEmail(emailValue.trim(), passwordValue);
      setPasswordValue('');
    } catch (err) {
      setAuthNotice(describeAuthError(err));
    } finally {
      setIsEmailBusy(false);
    }
  };

  const handleAccountSignOut = async () => {
    try {
      await authSignOut();
      setAuthNotice('Signed out.');
      setEmailValue('');
      setPasswordValue('');
    } catch (err) {
      // Mirrors the sign-in handlers' error handling just above — don't
      // claim success if the provider's sign-out actually failed.
      const message = err instanceof Error ? err.message : 'Sign-out failed. Please try again.';
      setAuthNotice(message);
    }
  };

  // Form fields for the local/test activation form below.
  const [formLicenseId, setFormLicenseId] = useState('');
  const [formTier, setFormTier] = useState<LicenseTier>('PRO');
  const [formStatus, setFormStatus] = useState<LicenseStatus>('active');
  const [formExpiry, setFormExpiry] = useState(''); // yyyy-mm-dd from <input type="date">, or ''
  const [formEmail, setFormEmail] = useState('');
  const [formSignature, setFormSignature] = useState('');
  const [formKeyId, setFormKeyId] = useState('');
  const [formAlgorithm, setFormAlgorithm] = useState('');

  // Re-read current status every time the panel opens, since other UI
  // (e.g. the Export dialog's dev override buttons) may have changed it
  // while this panel was closed.
  useEffect(() => {
    if (isOpen) setSnapshot(getLicenseStatus());
  }, [isOpen]);

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(null), 3500);
    return () => clearTimeout(timer);
  }, [notice]);

  if (!isOpen) return null;

  const refresh = () => setSnapshot(getLicenseStatus());

  const handleActivate = () => {
    const licenseId = formLicenseId.trim();
    if (!licenseId) {
      setNotice('License ID is required.');
      return;
    }

    // yyyy-mm-dd from a date input -> a real ISO instant, or null if left blank.
    let expiryDate: string | null = null;
    if (formExpiry) {
      const parsed = new Date(formExpiry);
      if (Number.isNaN(parsed.getTime())) {
        setNotice('Expiry date could not be read — leave it blank for no expiry.');
        return;
      }
      expiryDate = parsed.toISOString();
    }

    setProductionLicense({
      licenseId,
      tier: formTier,
      status: formStatus,
      expiryDate,
      ...(formEmail.trim() ? { userEmail: formEmail.trim() } : {}),
      ...(formSignature.trim() ? { signature: formSignature.trim() } : {}),
      ...(formKeyId.trim() ? { keyId: formKeyId.trim() } : {}),
      ...(formAlgorithm.trim() ? { algorithm: formAlgorithm.trim() } : {})
    });

    refresh();
    // Deliberately NOT "License verified" / "Purchase confirmed" — this is
    // a local record only. The status panel above shows the real,
    // separately-computed verification result.
    setNotice('Local test license saved. See verification status above — this does not mean it has been cryptographically verified.');
  };

  const handleClear = () => {
    clearProductionLicense();
    refresh();
    setNotice('Production license cleared. Developer/test override (if any) was not affected.');
  };

  const { tier, source, production, verification } = snapshot;
  const testActive = isTestOverrideActive();

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-lg bg-[#181820] border border-[#2b2b38] rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="h-10 bg-[#1e1e28] border-b border-[#282836] px-4 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2">
            <KeyRound className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-zinc-100 text-xs">License</span>
          </div>
          <button onClick={onClose} className="p-1 rounded text-zinc-400 hover:text-white hover:bg-[#2b2b3a]">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 space-y-4 text-xs text-zinc-300 overflow-y-auto">
          {/* Account (sign-in) — separate from license/tier below */}
          <div className="space-y-2">
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
              Account
            </span>
            <div className="p-2.5 rounded border border-[#2b2b38] bg-[#121216] space-y-2">
              {!authState.providerConfigured ? (
                <p className="text-[10px] text-zinc-500">
                  Sign-in isn't configured for this build. It doesn't affect your license tier below either way.
                </p>
              ) : authState.status === 'loading' ? (
                <p className="text-[10px] text-zinc-500">Checking sign-in status…</p>
              ) : authState.status === 'authenticated' && authState.user ? (
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <UserCircle2 className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span className="text-zinc-200 text-[11px] truncate">
                      {authState.user.displayName || authState.user.email}
                    </span>
                  </div>
                  <button
                    onClick={handleAccountSignOut}
                    className="shrink-0 flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium bg-[#1e1e28] hover:bg-[#26262f] border border-[#2b2b38] text-zinc-300"
                  >
                    <LogOut className="w-3 h-3" />
                    Sign out
                  </button>
                </div>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={handleGoogleSignIn}
                    disabled={isSigningIn || isEmailBusy}
                    className="w-full flex items-center justify-center gap-1.5 px-2 py-1.5 rounded text-[11px] font-medium bg-[#1e1e28] hover:bg-[#26262f] disabled:opacity-50 border border-[#2b2b38] text-zinc-200"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    {isSigningIn ? 'Signing in…' : 'Sign in with Google'}
                  </button>

                  <div className="flex items-center gap-2 text-[9px] text-zinc-600">
                    <div className="flex-1 border-t border-[#2b2b38]" />
                    or with email
                    <div className="flex-1 border-t border-[#2b2b38]" />
                  </div>

                  <input
                    type="email"
                    value={emailValue}
                    onChange={(e) => setEmailValue(e.target.value)}
                    placeholder="Email"
                    autoComplete="email"
                    disabled={isEmailBusy || isSigningIn}
                    className="w-full bg-[#0d0d10] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px] focus:outline-none focus:border-amber-500 disabled:opacity-50"
                  />
                  <input
                    type="password"
                    value={passwordValue}
                    onChange={(e) => setPasswordValue(e.target.value)}
                    placeholder="Password"
                    autoComplete="current-password"
                    disabled={isEmailBusy || isSigningIn}
                    className="w-full bg-[#0d0d10] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px] focus:outline-none focus:border-amber-500 disabled:opacity-50"
                  />
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={handleEmailSignIn}
                      disabled={isEmailBusy || isSigningIn}
                      className="flex items-center justify-center gap-1 px-2 py-1.5 rounded text-[11px] font-medium bg-[#1e1e28] hover:bg-[#26262f] disabled:opacity-50 border border-[#2b2b38] text-zinc-200"
                    >
                      <LogIn className="w-3 h-3" />
                      {isEmailBusy ? 'Please wait…' : 'Sign In'}
                    </button>
                    <button
                      onClick={handleCreateAccount}
                      disabled={isEmailBusy || isSigningIn}
                      className="flex items-center justify-center gap-1 px-2 py-1.5 rounded text-[11px] font-medium bg-[#1e1e28] hover:bg-[#26262f] disabled:opacity-50 border border-[#2b2b38] text-zinc-200"
                    >
                      <UserPlus className="w-3 h-3" />
                      Create Account
                    </button>
                  </div>
                </div>
              )}
              {authNotice && (
                <p className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1">
                  {authNotice}
                </p>
              )}
              <p className="text-[9px] text-zinc-600">
                Signing in identifies your account only — it does not by itself grant Pro.
              </p>
            </div>
          </div>

          {/* Current status */}
          <div className="space-y-2">
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
              Current Status
            </span>
            <div className="p-2.5 rounded border border-[#2b2b38] bg-[#121216] space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Tier</span>
                <span className={`font-semibold ${tier === 'PRO' ? 'text-amber-400' : 'text-zinc-300'}`}>{tier}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Source</span>
                <span className="text-zinc-300">
                  {source === 'test' ? 'Developer/Test Override' : source === 'production' ? 'Production License' : 'Default (no license)'}
                </span>
              </div>

              {production && (
                <>
                  <div className="my-1.5 border-t border-[#2d2d38]" />
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400">License ID</span>
                    <span className="text-zinc-300 font-mono-code">{production.licenseId}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400">Status</span>
                    <span className="text-zinc-300">{production.status}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400">Expiry</span>
                    <span className="text-zinc-300">{formatExpiry(production.expiryDate)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-zinc-400">Verification</span>
                    <span className={`flex items-center gap-1 ${verification.verified ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {verification.status === 'verified' ? <ShieldCheck className="w-3 h-3" /> :
                       verification.status === 'invalid' ? <ShieldAlert className="w-3 h-3" /> :
                       <ShieldQuestion className="w-3 h-3" />}
                      {verificationLabel(verification.status)}
                    </span>
                  </div>
                </>
              )}

              <div className="flex items-center justify-between pt-0.5">
                <span className="text-zinc-400">Developer/Test Override</span>
                <span className="text-zinc-300">{testActive ? 'Active (set from Export dialog)' : 'Not set'}</span>
              </div>
            </div>
          </div>

          {production && (
            <button
              onClick={handleClear}
              className="w-full flex items-center justify-center gap-1.5 px-2 py-1.5 rounded text-[11px] font-medium bg-red-950/30 hover:bg-red-950/50 border border-red-800/40 text-red-300"
            >
              <Trash2 className="w-3 h-3" />
              Clear License
            </button>
          )}

          {notice && (
            <p className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
              {notice}
            </p>
          )}

          {/* Local/test activation form */}
          <div className="space-y-2 pt-1 border-t border-[#2d2d38]">
            <div className="pt-2">
              <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block mb-1">
                Local Test Activation
              </span>
              <p className="text-[10px] text-amber-400/90 bg-amber-500/5 border border-dashed border-amber-500/40 rounded px-2 py-1.5">
                LOCAL / DEVELOPMENT USE ONLY. There is no payment system or online
                activation server yet — this only saves a record on this device for
                testing. It does not verify a license, confirm a purchase, or prove it is genuine.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="col-span-2">
                <label className="text-[10px] text-zinc-400 block mb-1">License ID</label>
                <input
                  type="text"
                  value={formLicenseId}
                  onChange={(e) => setFormLicenseId(e.target.value)}
                  placeholder="e.g. test-0001"
                  className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px] focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Tier</label>
                <select
                  value={formTier}
                  onChange={(e) => setFormTier(e.target.value as LicenseTier)}
                  className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
                >
                  <option value="PRO">PRO</option>
                  <option value="FREE">FREE</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Status</label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as LicenseStatus)}
                  className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
                >
                  {LICENSE_STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Expiry Date (optional)</label>
                <input
                  type="date"
                  value={formExpiry}
                  onChange={(e) => setFormExpiry(e.target.value)}
                  className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Email (optional)</label>
                <input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
                />
              </div>
            </div>

            <button
              onClick={() => setShowAdvanced(v => !v)}
              className="text-[10px] text-zinc-500 hover:text-zinc-300 underline underline-offset-2"
            >
              {showAdvanced ? 'Hide' : 'Show'} optional signature metadata (for testing v35's verification boundary)
            </button>
            {showAdvanced && (
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="text-[10px] text-zinc-400 block mb-1">Signature</label>
                  <input
                    type="text"
                    value={formSignature}
                    onChange={(e) => setFormSignature(e.target.value)}
                    className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-zinc-400 block mb-1">Key ID</label>
                  <input
                    type="text"
                    value={formKeyId}
                    onChange={(e) => setFormKeyId(e.target.value)}
                    className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-zinc-400 block mb-1">Algorithm</label>
                  <input
                    type="text"
                    value={formAlgorithm}
                    onChange={(e) => setFormAlgorithm(e.target.value)}
                    className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
                  />
                </div>
              </div>
            )}

            <button
              onClick={handleActivate}
              className="w-full px-2 py-1.5 bg-amber-600/30 hover:bg-amber-600/50 border border-amber-500/40 text-amber-300 rounded text-[11px] font-medium"
            >
              Save Local Test License
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
