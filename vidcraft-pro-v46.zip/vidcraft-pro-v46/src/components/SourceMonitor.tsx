import React, { useRef, useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, ArrowDownToLine, Plus, Scissors, Maximize2, Sparkles, Film } from 'lucide-react';
import { MediaAsset } from '../types';
import { formatTimecode } from '../utils/timecode';

interface SourceMonitorProps {
  asset: MediaAsset | null;
  fps: number;
  onInsertToTimeline: (asset: MediaAsset, inPoint: number, outPoint: number) => void;
  onOverwriteToTimeline: (asset: MediaAsset, inPoint: number, outPoint: number) => void;
}

export const SourceMonitor: React.FC<SourceMonitorProps> = ({
  asset,
  fps,
  onInsertToTimeline,
  onOverwriteToTimeline
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [sourceTime, setSourceTime] = useState(0);
  const [inPoint, setInPoint] = useState(0);
  const [outPoint, setOutPoint] = useState(0);

  useEffect(() => {
    if (asset) {
      setInPoint(0);
      setOutPoint(asset.duration || 10);
      setSourceTime(0);
      setIsPlaying(false);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
      }
    }
  }, [asset]);

  const togglePlay = () => {
    if (!videoRef.current || !asset) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setSourceTime(videoRef.current.currentTime);
      if (outPoint > 0 && videoRef.current.currentTime >= outPoint) {
        videoRef.current.pause();
        setIsPlaying(false);
        videoRef.current.currentTime = inPoint;
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setSourceTime(val);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
    }
  };

  const markIn = () => {
    setInPoint(sourceTime);
    if (outPoint <= sourceTime && asset) {
      setOutPoint(asset.duration);
    }
  };

  const markOut = () => {
    if (sourceTime > inPoint) {
      setOutPoint(sourceTime);
    }
  };

  if (!asset) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#17171c] text-zinc-500 text-xs p-4 select-none">
        <Film className="w-8 h-8 text-zinc-600 mb-2 opacity-60" />
        <span className="font-medium text-zinc-400">Source Monitor</span>
        <span className="text-[11px] text-zinc-600 mt-1 text-center max-w-[200px]">
          Double-click any clip in the Project Bin to load source preview here.
        </span>
      </div>
    );
  }

  const duration = asset.duration || 10;
  const inPercent = (inPoint / duration) * 100;
  const outPercent = (outPoint / duration) * 100;

  return (
    <div className="h-full flex flex-col bg-[#16161a] border-r border-[#262630] select-none">
      {/* Header Bar */}
      <div className="h-7 bg-[#1c1c24] border-b border-[#282834] px-2 flex items-center justify-between text-[11px] text-zinc-300">
        <div className="flex items-center space-x-1.5 truncate max-w-[70%]">
          <span className="text-sky-400 font-semibold">Source:</span>
          <span className="truncate text-zinc-200 font-medium" title={asset.name}>{asset.name}</span>
        </div>
        <div className="font-mono-code text-[10px] text-zinc-400 bg-[#121216] px-1.5 py-0.5 rounded border border-[#2b2b36]">
          {formatTimecode(sourceTime, fps)}
        </div>
      </div>

      {/* Video Viewport */}
      <div className="flex-1 bg-[#09090b] relative flex items-center justify-center overflow-hidden group">
        {asset.type === 'video' ? (
          <video
            ref={videoRef}
            src={asset.src}
            onTimeUpdate={handleTimeUpdate}
            onEnded={() => setIsPlaying(false)}
            className="max-h-full max-w-full object-contain"
            playsInline
          />
        ) : asset.type === 'image' ? (
          <img src={asset.src} alt={asset.name} className="max-h-full max-w-full object-contain" />
        ) : (
          <div className="flex flex-col items-center justify-center text-zinc-400">
            <span className="text-sm font-medium">{asset.name}</span>
            <span className="text-xs text-zinc-600 mt-1">Audio Source File</span>
          </div>
        )}

        {/* Source overlay buttons */}
        <button
          onClick={togglePlay}
          className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-black/40 border border-white/20 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:scale-105"
        >
          {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
        </button>
      </div>

      {/* In / Out Scrubber Track */}
      <div className="bg-[#1a1a22] px-3 pt-2 pb-1 border-t border-[#262632]">
        <div className="relative h-4 flex items-center">
          {/* In-Out shaded range */}
          <div 
            className="absolute top-1 bottom-1 bg-sky-500/30 rounded border-y border-sky-400/50 pointer-events-none"
            style={{
              left: `${inPercent}%`,
              width: `${Math.max(2, outPercent - inPercent)}%`
            }}
          />
          <input
            type="range"
            min={0}
            max={duration}
            step={0.05}
            value={sourceTime}
            onChange={handleSeek}
            className="w-full h-1.5 bg-[#2d2d38] rounded-lg appearance-none cursor-pointer relative z-10"
          />
        </div>

        {/* Controls Bottom Bar */}
        <div className="flex items-center justify-between mt-1 text-xs text-zinc-300">
          <div className="flex items-center space-x-1">
            <button
              id="source-mark-in-btn"
              onClick={markIn}
              title="Mark In Point (I)"
              className="px-2 py-1 rounded bg-[#242430] hover:bg-[#323242] text-sky-300 hover:text-white font-mono-code text-[11px] flex items-center space-x-1"
            >
              <span>{`{ In`}</span>
              <span className="text-[9px] text-zinc-400">({formatTimecode(inPoint, fps, false)})</span>
            </button>

            <button
              id="source-mark-out-btn"
              onClick={markOut}
              title="Mark Out Point (O)"
              className="px-2 py-1 rounded bg-[#242430] hover:bg-[#323242] text-sky-300 hover:text-white font-mono-code text-[11px] flex items-center space-x-1"
            >
              <span>{`Out }`}</span>
              <span className="text-[9px] text-zinc-400">({formatTimecode(outPoint, fps, false)})</span>
            </button>

            <button
              id="source-play-btn"
              onClick={togglePlay}
              className="p-1 rounded bg-[#242430] hover:bg-[#323242] text-zinc-200"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="flex items-center space-x-1">
            <button
              id="source-insert-btn"
              onClick={() => onInsertToTimeline(asset, inPoint, outPoint)}
              title="Insert into Timeline (,)"
              className="px-2 py-1 rounded bg-sky-600 hover:bg-sky-500 text-white flex items-center space-x-1 text-[11px] font-medium"
            >
              <ArrowDownToLine className="w-3 h-3" />
              <span>Insert</span>
            </button>

            <button
              id="source-overwrite-btn"
              onClick={() => onOverwriteToTimeline(asset, inPoint, outPoint)}
              title="Overwrite into Timeline (.)"
              className="px-2 py-1 rounded bg-[#323244] hover:bg-[#404058] text-zinc-100 flex items-center space-x-1 text-[11px]"
            >
              <Scissors className="w-3 h-3" />
              <span>Overwrite</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
