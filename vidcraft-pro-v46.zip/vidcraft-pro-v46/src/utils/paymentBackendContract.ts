// -----------------------------------------------------------------------
// VidCraft Pro — Future payment backend contract (types only, no server)
// -----------------------------------------------------------------------
// This file implements NOTHING. There is no server code here, no Express
// route, no network call — it documents the shape a real backend would
// need to expose for a future Razorpay PaymentAdapter (see payment.ts) to
// talk to, so the frontend/backend split is designed deliberately instead
// of growing ad hoc once someone actually builds that backend.
//
// The backend that eventually implements this holds the Razorpay Key
// Secret and the webhook signing secret (see razorpayConfig.ts's header
// for why those can never live in this repo's frontend). This file's
// types intentionally never include either secret; a real backend reads
// them from its own server-side environment — nothing shaped like these
// types carries them.

import type { PaymentOrder, PaymentStatus } from './payment';

// ---- POST /api/payments/create-order (future) --------------------------
// Backend creates the actual Razorpay order server-side (using the Key
// Secret) and returns only what the frontend needs to open checkout.

export interface CreateOrderRequest {
  amount: number;
  currency: string;
  description?: string;
}

export interface CreateOrderResponse {
  order: PaymentOrder;
  /** The PUBLIC Key ID (see razorpayConfig.ts), echoed back so the
   *  backend can be the single source of truth for it if preferred. */
  keyId: string;
}

// ---- POST /api/payments/verify (future) --------------------------------
// Frontend forwards exactly what Razorpay Checkout handed back after the
// popup closes. The backend is the ONLY thing that decides whether it's
// real, by checking the HMAC signature against the Key Secret — this is
// the authoritative check payment.ts's verifyPaymentResult() is meant to
// eventually call through to.

export interface VerifyPaymentRequest {
  orderId: string;
  paymentId: string;
  /** Razorpay checkout's own signature for this order+payment pair —
   *  meaningless without the Key Secret to check it against, which only
   *  the backend has. */
  signature: string;
}

export interface VerifyPaymentResponse {
  verified: boolean;
  status: PaymentStatus;
}

// ---- POST /api/payments/webhook (future) -------------------------------
// Razorpay calls this directly, server-to-server — the browser is never
// involved. The backend must verify the `x-razorpay-signature` header
// against the RAW request body and the webhook secret before trusting
// anything in the payload. Signature verification is byte-exact, so the
// raw bytes Razorpay actually signed matter — not a JSON.parse'd-and-
// re-serialized copy of them.

export interface WebhookVerificationInput {
  /** Raw, unparsed request body, exactly as received. */
  rawBody: string;
  /** The `x-razorpay-signature` request header, verbatim. */
  signatureHeader: string;
}

/**
 * What a real backend implements for all three endpoints above. No
 * runtime code implements this in v42 — it exists so the eventual server
 * code has a concrete contract to satisfy, and so this repo's frontend
 * has something typed to call once that server exists.
 */
export interface PaymentBackend {
  createOrder(req: CreateOrderRequest): Promise<CreateOrderResponse>;
  verifyPayment(req: VerifyPaymentRequest): Promise<VerifyPaymentResponse>;
  /** Returns whether the webhook's signature is authentic — nothing more.
   *  What to DO once verified (update an order's status, etc.) is a
   *  separate concern for whatever real backend implements this. */
  verifyWebhook(input: WebhookVerificationInput): Promise<boolean>;
}
