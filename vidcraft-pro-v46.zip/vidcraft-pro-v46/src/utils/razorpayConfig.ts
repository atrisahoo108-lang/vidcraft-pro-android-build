// -----------------------------------------------------------------------
// VidCraft Pro — Razorpay client configuration (public Key ID only)
// -----------------------------------------------------------------------
// This file may EVER hold: the Razorpay Key ID — a public client
// identifier Razorpay's own Checkout needs in the browser to open the
// payment sheet. It identifies the merchant account; it does not
// authorize anything by itself, which is why Razorpay's own docs treat it
// as safe to ship in client code.
//
// This file must NEVER hold: the Razorpay Key Secret, or a webhook
// signing secret. Those are used to create trusted orders and verify
// payment/webhook signatures — operations that only mean something if
// done somewhere the browser (and therefore the user, and therefore
// anyone with devtools open) cannot read or influence them. That means a
// backend's own server-side environment — not this file, not a VITE_ env
// var, not anywhere in this repository. A `VITE_` prefix makes Vite bundle
// a value into the client JS; anything with "SECRET" in the name and a
// `VITE_` prefix is a contradiction in terms. See paymentBackendContract.ts
// for where the Secret actually belongs.
//
// Read from Vite env vars only — never hard-coded — and safely reports
// "not configured" (returns null) when missing, exactly like
// firebaseConfig.ts.

export interface RazorpayConfig {
  /** Public Key ID (Razorpay's test/live keys are both prefixed "rzp_"). */
  keyId: string;
}

function readEnvVar(key: string): string | undefined {
  const value = (import.meta.env as Record<string, string | undefined>)[key];
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined;
}

/** Returns the config if the Key ID is present, otherwise null — never throws. */
export function getRazorpayConfig(): RazorpayConfig | null {
  const keyId = readEnvVar('VITE_RAZORPAY_KEY_ID');
  if (!keyId) return null;
  return { keyId };
}

export function isRazorpayConfigured(): boolean {
  return getRazorpayConfig() !== null;
}
