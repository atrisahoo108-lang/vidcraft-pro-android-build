import type { CapacitorConfig } from '@capacitor/cli';

// appId should be a reverse-domain identifier unique to this app — you can
// change "com.vidcraft.pro" to your own domain-style id before your first
// real release (Google Play requires it to be unique and, once published,
// it can never be changed again).
const config: CapacitorConfig = {
  appId: 'com.vidcraft.pro',
  appName: 'VidCraft Pro',
  // Capacitor packages whatever is in this folder as the app's UI. This must
  // match Vite's build output directory (see vite.config.ts / "build:mobile").
  webDir: 'dist',
  server: {
    // Serve the bundled app over https:// inside the WebView (Android
    // default anyway) rather than the custom capacitor:// scheme, which a
    // couple of browser APIs used here (MediaRecorder, captureStream) are
    // fussier about.
    androidScheme: 'https'
  },
  android: {
    // Video/export work benefits from hardware-accelerated WebView rendering.
    allowMixedContent: false,
    // Matches the app's own background (see index.html / #121216) so there
    // is no white flash behind the WebView during cold start or rotation,
    // before the app's own CSS has painted.
    backgroundColor: '#121216'
  },
  // v43: the web app already reserves space for the status bar / notch /
  // gesture-navigation bar itself via CSS env(safe-area-inset-*) (see
  // src/index.css — .safe-top / .safe-bottom / .safe-x, used in
  // HeaderMenuBar.tsx and App.tsx). For those to receive non-zero values
  // at all, the native Android shell must draw edge-to-edge instead of
  // leaving the WebView inset by the system bars itself. Capacitor 7 does
  // this by default on Android 15+ (mandatory edge-to-edge); on older
  // Android versions it needs one native-side line, added by hand after
  // `npm run cap:add:android` generates the android/ project (that folder
  // doesn't exist yet in this zip — see MOBILE_BUILD.md):
  //   android/app/src/main/java/.../MainActivity.java
  //     @Override
  //     public void onCreate(Bundle savedInstanceState) {
  //       WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
  //       super.onCreate(savedInstanceState);
  //     }
  // Without it the app still works correctly — safe-area padding is just
  // 0px, same as v42 today, and the system bars keep drawing their own
  // (non-edge-to-edge) space the WebView doesn't occupy.
  //
  // v45 — native-side checklist for once `npm run cap:add:android` has
  // generated the android/ project (still not present in this zip; no
  // Android SDK or network in this sandbox to generate or build it, so
  // none of this could be run or verified here — see CHANGELOG_v45.md):
  //
  // 1. Orientation (portrait + landscape): leave
  //    AndroidManifest.xml's <activity> WITHOUT an
  //    android:screenOrientation attribute (Capacitor's default template
  //    already omits it). That's what allows both orientations — adding
  //    android:screenOrientation="portrait" (a common copy-pasted
  //    "template" line for camera/social apps) would silently break the
  //    landscape editing layout this app depends on.
  //
  // 2. Memory headroom for low/mid-end devices: video compositing/export
  //    (ProgramMonitor.tsx's canvas, ExportModal.tsx's MediaRecorder) is
  //    memory-heavier than a typical app. Add
  //    android:largeHeap="true" to <application> in AndroidManifest.xml.
  //    This raises the heap ceiling Android grants the process — it does
  //    not by itself reduce memory use (v43/v44's device-tier preview
  //    scaling and asset-cache pruning already do that), it just gives
  //    more room before an OutOfMemoryError on a long editing session.
  //
  // 3. Permissions: nothing in this project (core Capacitor + the
  //    Android platform package only, no camera/mic/storage/ads/billing
  //    plugins) requests a dangerous permission. `cap sync` will merge
  //    only whatever each installed plugin's own manifest declares — with
  //    today's dependency list that's nothing beyond the INTERNET
  //    permission Capacitor's WebView needs by default. Re-check this
  //    list if a plugin is ever added; don't add one "just in case."
  //
  // 4. WebView build compatibility: minSdkVersion is whatever Capacitor
  //    7's template sets (23 / Android 6.0) unless changed by hand in
  //    android/variables.gradle — left as the template default here since
  //    changing it either way needs a real low-end device or emulator to
  //    validate against, which this sandbox doesn't have.
};

export default config;
