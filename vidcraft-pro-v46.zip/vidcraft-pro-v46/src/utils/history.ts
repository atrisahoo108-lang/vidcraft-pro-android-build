// Undo/Redo history for the whole editable document (project settings +
// tracks + clips), not just clips like the old implementation.
//
// Design notes:
// - Call recordSnapshot(label) *before* mutating state. It pushes the
//   current (pre-change) project/tracks/clips onto the undo stack.
// - Rapid-fire calls with the SAME label within COALESCE_MS are merged into
//   a single undo step. This is what makes dragging a clip across the
//   timeline, or dragging a color/volume slider, undo in one step instead
//   of one step per pixel/tick — those UI pieces fire their update callback
//   continuously while the user drags, same as before, but only the first
//   call in a burst actually pushes history.
import { useCallback, useRef, useState } from 'react';
import { Clip, ProjectSettings, Track } from '../types';

export interface EditorSnapshot {
  project: ProjectSettings;
  tracks: Track[];
  clips: Clip[];
  label: string;
  timestamp: number;
}

const MAX_HISTORY = 60;
const COALESCE_MS = 600;

interface UseEditorHistoryArgs {
  project: ProjectSettings;
  tracks: Track[];
  clips: Clip[];
  setProject: (p: ProjectSettings) => void;
  setTracks: (t: Track[]) => void;
  setClips: (c: Clip[]) => void;
}

export function useEditorHistory({ project, tracks, clips, setProject, setTracks, setClips }: UseEditorHistoryArgs) {
  const pastRef = useRef<EditorSnapshot[]>([]);
  const futureRef = useRef<EditorSnapshot[]>([]);
  const lastLabelRef = useRef<string | null>(null);
  const lastTimeRef = useRef<number>(0);

  // Always mirrors the latest committed state so recordSnapshot/undo/redo
  // can read "the current document" without needing it passed in.
  const currentRef = useRef({ project, tracks, clips });
  currentRef.current = { project, tracks, clips };

  // Refs don't trigger re-renders on their own; this dummy counter forces
  // one so canUndo/canRedo/labels reflect the latest ref values in the UI.
  const [, setTick] = useState(0);
  const bump = () => setTick(t => t + 1);

  const recordSnapshot = useCallback((label: string) => {
    const now = Date.now();
    if (label === lastLabelRef.current && now - lastTimeRef.current < COALESCE_MS) {
      // Still mid-gesture (e.g. same slider/drag firing repeatedly) — don't
      // push another entry, just extend the "still going" window.
      lastTimeRef.current = now;
      return;
    }
    lastLabelRef.current = label;
    lastTimeRef.current = now;

    const snapshot = { ...currentRef.current, label, timestamp: now };
    pastRef.current = [...pastRef.current.slice(-(MAX_HISTORY - 1)), snapshot];
    futureRef.current = [];
    bump();
  }, []);

  const undo = useCallback(() => {
    const last = pastRef.current[pastRef.current.length - 1];
    if (!last) return;
    pastRef.current = pastRef.current.slice(0, -1);
    futureRef.current = [{ ...currentRef.current, label: last.label, timestamp: Date.now() }, ...futureRef.current];
    lastLabelRef.current = null; // next edit shouldn't coalesce with pre-undo history
    setProject(last.project);
    setTracks(last.tracks);
    setClips(last.clips);
    bump();
  }, [setProject, setTracks, setClips]);

  const redo = useCallback(() => {
    const next = futureRef.current[0];
    if (!next) return;
    futureRef.current = futureRef.current.slice(1);
    pastRef.current = [...pastRef.current, { ...currentRef.current, label: next.label, timestamp: Date.now() }];
    lastLabelRef.current = null;
    setProject(next.project);
    setTracks(next.tracks);
    setClips(next.clips);
    bump();
  }, [setProject, setTracks, setClips]);

  // Wipes the undo/redo stacks without touching current state — use this
  // after loading a different project, since undoing "past" a freshly
  // opened project into the previous project's edits would be confusing.
  const clearHistory = useCallback(() => {
    pastRef.current = [];
    futureRef.current = [];
    lastLabelRef.current = null;
    bump();
  }, []);

  return {
    recordSnapshot,
    undo,
    redo,
    clearHistory,
    canUndo: pastRef.current.length > 0,
    canRedo: futureRef.current.length > 0,
    undoLabel: pastRef.current[pastRef.current.length - 1]?.label,
    redoLabel: futureRef.current[0]?.label,
  };
}

// Best-effort label for a generic clip patch (App.tsx's handleUpdateClip is
// one shared function used by every panel — Lumetri, filters, transform,
// text, audio, keyframes — so this keeps each kind of edit as its own undo
// step without every single panel needing to know about history at all).
export function describeClipEdit(updates: Partial<Clip>): string {
  const keys = Object.keys(updates);
  if (keys.includes('lumetri')) return 'Adjust Color';
  if (keys.includes('filters')) return 'Edit Filters';
  if (keys.includes('textConfig')) return 'Edit Text';
  if (keys.includes('audioConfig')) return 'Adjust Audio';
  if (keys.includes('keyframes')) return 'Edit Keyframes';
  if (keys.includes('transitionIn') || keys.includes('transitionOut')) return 'Edit Transition';
  if (keys.some(k => ['positionX', 'positionY', 'scale', 'rotation', 'opacity', 'blendMode'].includes(k))) {
    return 'Transform Clip';
  }
  return 'Edit Clip';
}

export function describeTrackEdit(updates: Partial<Track>): string {
  const keys = Object.keys(updates);
  if (keys.includes('volume') || keys.includes('pan')) return 'Adjust Track Mix';
  if (keys.includes('isMuted')) return 'Mute Track';
  if (keys.includes('isSolo')) return 'Solo Track';
  if (keys.includes('isLocked')) return 'Lock Track';
  if (keys.includes('isVisible')) return 'Hide Track';
  if (keys.includes('name')) return 'Rename Track';
  return 'Update Track';
}
