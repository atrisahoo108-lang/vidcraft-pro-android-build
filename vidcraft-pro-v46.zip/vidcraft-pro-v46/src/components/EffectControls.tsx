import React from 'react';
import { 
  Sliders, Move, RotateCw, Eye, Sparkles, Volume2, 
  Layers, Plus, Trash2, Key, SplitSquareVertical, Focus 
} from 'lucide-react';
import { Clip, BlendMode, TransitionType } from '../types';

interface EffectControlsProps {
  selectedClip: Clip | null;
  onUpdateClip: (clipId: string, updates: Partial<Clip>) => void;
  onAddKeyframe: (clipId: string, property: 'positionX' | 'positionY' | 'scale' | 'rotation' | 'opacity' | 'volume' | 'speed') => void;
  // v44: accepted for consistency with the other workspace panels. Slider
  // touch-target sizing here is handled by a global (pointer: coarse) rule
  // in index.css rather than per-component classes, since this panel has
  // a large number of range inputs — see that rule's comment for why.
  // Defaults to false; desktop/web behavior is unaffected either way.
  isMobile?: boolean;
}

export const EffectControls: React.FC<EffectControlsProps> = ({
  selectedClip,
  onUpdateClip,
  onAddKeyframe,
  isMobile = false
}) => {
  if (!selectedClip) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#17171c] text-zinc-500 text-xs p-4 select-none">
        <Sliders className="w-8 h-8 text-zinc-600 mb-2 opacity-60" />
        <span className="font-medium text-zinc-400">Effect Controls</span>
        <span className="text-[11px] text-zinc-600 mt-1 text-center max-w-[200px]">
          Select any clip on the timeline to inspect and edit its motion, opacity, audio, and effects.
        </span>
      </div>
    );
  }

  const blendModes: { id: BlendMode; label: string }[] = [
    { id: 'normal', label: 'Normal' },
    { id: 'screen', label: 'Screen (Lighten)' },
    { id: 'multiply', label: 'Multiply (Darken)' },
    { id: 'overlay', label: 'Overlay' },
    { id: 'color-dodge', label: 'Color Dodge' },
    { id: 'lighten', label: 'Lighten' },
    { id: 'darken', label: 'Darken' },
    { id: 'difference', label: 'Difference' },
  ];

  const transitions: { id: TransitionType; label: string }[] = [
    { id: 'none', label: 'None' },
    { id: 'cross-dissolve', label: 'Cross Dissolve' },
    { id: 'dip-to-black', label: 'Dip to Black' },
    { id: 'dip-to-white', label: 'Dip to White' },
    { id: 'blur-dissolve', label: 'Blur Dissolve' },
    { id: 'wipe-left', label: 'Wipe Left' },
    { id: 'wipe-right', label: 'Wipe Right' },
    { id: 'wipe-up', label: 'Wipe Up' },
    { id: 'wipe-down', label: 'Wipe Down' },
    { id: 'iris', label: 'Iris Reveal' },
    { id: 'slide-left', label: 'Slide Left' },
    { id: 'slide-right', label: 'Slide Right' },
    { id: 'slide-up', label: 'Slide Up' },
    { id: 'slide-down', label: 'Slide Down' },
    { id: 'zoom-in', label: 'Zoom In' },
  ];

  const kfCount = (property: 'positionX' | 'positionY' | 'scale' | 'rotation' | 'opacity' | 'volume' | 'speed') =>
    (selectedClip.keyframes || []).filter(k => k.property === property).length;

  const KeyframeButton: React.FC<{ property: 'positionX' | 'positionY' | 'scale' | 'rotation' | 'opacity' | 'volume' | 'speed'; title: string }> = ({ property, title }) => {
    const count = kfCount(property);
    return (
      <button
        onClick={() => onAddKeyframe(selectedClip.id, property)}
        title={title}
        className={`flex items-center space-x-0.5 px-1.5 py-0.5 rounded text-[9px] font-semibold border transition-colors ${
          count > 0
            ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
            : 'bg-[#121216] border-[#2b2b36] text-zinc-500 hover:text-amber-300 hover:border-amber-500/50'
        }`}
      >
        <Key className="w-2.5 h-2.5" />
        {count > 0 && <span>{count}</span>}
      </button>
    );
  };

  return (
    <div className="h-full flex flex-col bg-[#16161b] text-zinc-200 text-xs select-none overflow-y-auto">
      {/* Header */}
      <div className="h-7 bg-[#1e1e26] border-b border-[#282834] px-3 flex items-center justify-between text-[11px]">
        <div className="flex items-center space-x-1.5 truncate">
          <Sliders className="w-3.5 h-3.5 text-sky-400" />
          <span className="font-semibold text-zinc-100 truncate">{selectedClip.name}</span>
        </div>
        <span className="text-[10px] text-zinc-400 font-mono-code">
          {(selectedClip.duration).toFixed(2)}s
        </span>
      </div>

      <div className="p-3 space-y-4">
        {/* Section 1: Motion Transforms */}
        <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
          <div className="flex items-center justify-between border-b border-[#2a2a36] pb-1.5">
            <div className="flex items-center space-x-1 text-sky-400 font-semibold text-[11px]">
              <Move className="w-3.5 h-3.5" />
              <span>Motion & Transform</span>
            </div>
            <button
              onClick={() => onUpdateClip(selectedClip.id, { positionX: 0, positionY: 0, scale: 100, rotation: 0 })}
              className="text-[10px] text-zinc-400 hover:text-sky-300"
            >
              Reset
            </button>
          </div>

          {/* Position X / Y */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] text-zinc-400">Position X (px)</label>
                <KeyframeButton property="positionX" title="Add keyframe at playhead" />
              </div>
              <input
                type="number"
                value={Math.round(selectedClip.positionX)}
                onChange={(e) => onUpdateClip(selectedClip.id, { positionX: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 font-mono-code text-[11px] focus:outline-none focus:border-sky-500"
              />
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[10px] text-zinc-400">Position Y (px)</label>
                <KeyframeButton property="positionY" title="Add keyframe at playhead" />
              </div>
              <input
                type="number"
                value={Math.round(selectedClip.positionY)}
                onChange={(e) => onUpdateClip(selectedClip.id, { positionY: parseFloat(e.target.value) || 0 })}
                className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 font-mono-code text-[11px] focus:outline-none focus:border-sky-500"
              />
            </div>
          </div>

          {/* Scale Slider */}
          <div>
            <div className="flex justify-between items-center text-[10px] mb-1">
              <span className="text-zinc-400">Scale (%)</span>
              <div className="flex items-center space-x-1.5">
                <span className="font-mono-code text-sky-400">{Math.round(selectedClip.scale)}%</span>
                <KeyframeButton property="scale" title="Add keyframe at playhead" />
              </div>
            </div>
            <input
              type="range"
              min={10}
              max={300}
              value={selectedClip.scale}
              onChange={(e) => onUpdateClip(selectedClip.id, { scale: parseFloat(e.target.value) })}
              className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer"
            />
          </div>

          {/* Rotation Slider */}
          <div>
            <div className="flex justify-between items-center text-[10px] mb-1">
              <span className="text-zinc-400">Rotation (deg)</span>
              <div className="flex items-center space-x-1.5">
                <span className="font-mono-code text-sky-400">{Math.round(selectedClip.rotation)}°</span>
                <KeyframeButton property="rotation" title="Add keyframe at playhead" />
              </div>
            </div>
            <input
              type="range"
              min={-180}
              max={180}
              value={selectedClip.rotation}
              onChange={(e) => onUpdateClip(selectedClip.id, { rotation: parseFloat(e.target.value) })}
              className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer"
            />
          </div>
          {(selectedClip.keyframes?.length ?? 0) > 0 && (
            <p className="text-[9px] text-amber-400/80 pt-0.5">
              ⏱ Animated — this clip has keyframes. Move the playhead to preview the motion.
            </p>
          )}
        </div>

        {/* Section 1.5: Speed / Time Remapping (video clips only) */}
        {selectedClip.type === 'video' && (
          <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
            <div className="flex items-center justify-between border-b border-[#2a2a36] pb-1.5">
              <div className="flex items-center space-x-1 text-orange-400 font-semibold text-[11px]">
                <RotateCw className="w-3.5 h-3.5" />
                <span>Speed & Time</span>
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center text-[10px] mb-1">
                <span className="text-zinc-400">Clip Speed</span>
                <div className="flex items-center space-x-1.5">
                  <span className="font-mono-code text-orange-300">{(selectedClip.speed ?? 1).toFixed(2)}x</span>
                  <KeyframeButton property="speed" title="Add a speed keyframe at playhead (for a speed ramp)" />
                </div>
              </div>
              <input
                type="range"
                min={0.1}
                max={4}
                step={0.05}
                value={selectedClip.speed ?? 1}
                disabled={!!selectedClip.freezeFrame}
                onChange={(e) => onUpdateClip(selectedClip.id, { speed: parseFloat(e.target.value) })}
                className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer accent-orange-500 disabled:opacity-40"
              />
              <div className="flex flex-wrap gap-1 mt-1.5">
                {[0.25, 0.5, 0.75, 1, 1.5, 2, 4].map(p => (
                  <button
                    key={p}
                    disabled={!!selectedClip.freezeFrame}
                    onClick={() => onUpdateClip(selectedClip.id, { speed: p })}
                    className={`px-1.5 py-0.5 rounded text-[9px] font-mono-code border disabled:opacity-30 ${
                      (selectedClip.speed ?? 1) === p
                        ? 'bg-orange-500/20 border-orange-500/50 text-orange-300'
                        : 'bg-[#121216] border-[#2b2b36] text-zinc-500 hover:text-orange-300'
                    }`}
                  >
                    {p}x
                  </button>
                ))}
              </div>
              {(selectedClip.keyframes || []).some(k => k.property === 'speed') && (
                <p className="text-[9px] text-amber-400/80 pt-1">
                  ⏱ Speed-ramped — this clip has speed keyframes, so the slider above shows the
                  value at the playhead only.
                </p>
              )}
            </div>

            <div className="border-t border-[#2a2a36] pt-2">
              <label className="flex items-center justify-between text-[10px] text-zinc-400">
                <span>Freeze Frame (hold this clip's first frame)</span>
                <input
                  type="checkbox"
                  checked={!!selectedClip.freezeFrame}
                  onChange={(e) => onUpdateClip(selectedClip.id, { freezeFrame: e.target.checked })}
                  className="accent-orange-500"
                />
              </label>
              <p className="text-[9px] text-zinc-500 mt-1">
                Use the Razor tool to split off the exact moment you want to hold, then enable this
                on that piece and drag its right edge to stretch how long the freeze lasts.
              </p>
            </div>
          </div>
        )}

        {/* Section 2: Opacity & Blending */}
        <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
          <div className="flex items-center justify-between border-b border-[#2a2a36] pb-1.5">
            <div className="flex items-center space-x-1 text-purple-400 font-semibold text-[11px]">
              <Eye className="w-3.5 h-3.5" />
              <span>Opacity & Compositing</span>
            </div>
          </div>

          {/* Opacity */}
          <div>
            <div className="flex justify-between items-center text-[10px] mb-1">
              <span className="text-zinc-400">Opacity</span>
              <div className="flex items-center space-x-1.5">
                <span className="font-mono-code text-purple-300">{Math.round(selectedClip.opacity)}%</span>
                <KeyframeButton property="opacity" title="Add keyframe at playhead" />
              </div>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={selectedClip.opacity}
              onChange={(e) => onUpdateClip(selectedClip.id, { opacity: parseFloat(e.target.value) })}
              className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer"
            />
          </div>

          {/* Blend Mode */}
          <div>
            <label className="text-[10px] text-zinc-400 block mb-1">Blend Mode</label>
            <select
              value={selectedClip.blendMode}
              onChange={(e) => onUpdateClip(selectedClip.id, { blendMode: e.target.value as BlendMode })}
              className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px] focus:outline-none focus:border-purple-500"
            >
              {blendModes.map(b => (
                <option key={b.id} value={b.id} className="bg-[#1c1c24]">{b.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Section 2.5: Shape Mask */}
        {selectedClip.type !== 'audio' && (
          <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
            <div className="flex items-center justify-between border-b border-[#2a2a36] pb-1.5">
              <div className="flex items-center space-x-1 text-rose-400 font-semibold text-[11px]">
                <Focus className="w-3.5 h-3.5" />
                <span>Shape Mask</span>
              </div>
              {selectedClip.mask && (
                <button
                  onClick={() => onUpdateClip(selectedClip.id, { mask: undefined })}
                  className="text-[10px] text-zinc-400 hover:text-red-400"
                >
                  Remove
                </button>
              )}
            </div>

            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Shape</label>
              <select
                value={selectedClip.mask?.shape || 'none'}
                onChange={(e) => {
                  const shape = e.target.value;
                  if (shape === 'none') {
                    onUpdateClip(selectedClip.id, { mask: undefined });
                  } else if (selectedClip.mask) {
                    onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask, shape: shape as 'rectangle' | 'ellipse' } });
                  } else {
                    onUpdateClip(selectedClip.id, {
                      mask: {
                        shape: shape as 'rectangle' | 'ellipse',
                        xPercent: 50, yPercent: 50, widthPercent: 50, heightPercent: 50,
                        feather: 20, invert: false, mode: 'crop', blurAmount: 15
                      }
                    });
                  }
                }}
                className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[11px]"
              >
                <option value="none">None</option>
                <option value="rectangle">Rectangle</option>
                <option value="ellipse">Ellipse / Circle</option>
              </select>
            </div>

            {selectedClip.mask && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1">Center X ({selectedClip.mask.xPercent}%)</label>
                    <input type="range" min={0} max={100} value={selectedClip.mask.xPercent}
                      onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, xPercent: parseFloat(e.target.value) } })}
                      className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer" />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1">Center Y ({selectedClip.mask.yPercent}%)</label>
                    <input type="range" min={0} max={100} value={selectedClip.mask.yPercent}
                      onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, yPercent: parseFloat(e.target.value) } })}
                      className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer" />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1">Width ({selectedClip.mask.widthPercent}%)</label>
                    <input type="range" min={5} max={150} value={selectedClip.mask.widthPercent}
                      onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, widthPercent: parseFloat(e.target.value) } })}
                      className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer" />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1">Height ({selectedClip.mask.heightPercent}%)</label>
                    <input type="range" min={5} max={150} value={selectedClip.mask.heightPercent}
                      onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, heightPercent: parseFloat(e.target.value) } })}
                      className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer" />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] text-zinc-400 block mb-1">Feather ({selectedClip.mask.feather}px)</label>
                  <input type="range" min={0} max={100} value={selectedClip.mask.feather}
                    onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, feather: parseFloat(e.target.value) } })}
                    className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer" />
                </div>

                <div className="grid grid-cols-2 gap-2 items-end">
                  <label className="flex items-center space-x-1.5 text-[10px] text-zinc-400 pb-1.5">
                    <input type="checkbox" checked={selectedClip.mask.invert}
                      onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, invert: e.target.checked } })}
                      className="accent-rose-500" />
                    <span>Invert (affect outside)</span>
                  </label>
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1">Effect</label>
                    <select
                      value={selectedClip.mask.mode}
                      onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, mode: e.target.value as 'crop' | 'blur' } })}
                      className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 text-[10px]"
                    >
                      <option value="crop">Crop / Reveal</option>
                      <option value="blur">Blur (privacy / tilt-shift)</option>
                    </select>
                  </div>
                </div>

                {selectedClip.mask.mode === 'blur' && (
                  <div>
                    <label className="text-[10px] text-zinc-400 block mb-1">Blur Amount ({selectedClip.mask.blurAmount}px)</label>
                    <input type="range" min={1} max={40} value={selectedClip.mask.blurAmount}
                      onChange={(e) => onUpdateClip(selectedClip.id, { mask: { ...selectedClip.mask!, blurAmount: parseFloat(e.target.value) } })}
                      className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer" />
                  </div>
                )}

                <p className="text-[9px] text-zinc-500">
                  {selectedClip.mask.mode === 'crop'
                    ? (selectedClip.mask.invert
                        ? 'The shape area is cut away; everything outside it stays visible.'
                        : 'Only the shape area stays visible; the rest becomes transparent — good for framed inserts or picture-in-picture.')
                    : (selectedClip.mask.invert
                        ? 'Blurs everything outside the shape (spotlight look).'
                        : 'Blurs only the shape area (e.g. blur a face or license plate).')}
                </p>
              </>
            )}
          </div>
        )}

        {/* Section 3: Transitions In / Out */}
        <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
          <div className="flex items-center justify-between border-b border-[#2a2a36] pb-1.5">
            <div className="flex items-center space-x-1 text-emerald-400 font-semibold text-[11px]">
              <SplitSquareVertical className="w-3.5 h-3.5" />
              <span>Transitions</span>
            </div>
          </div>

          {/* Transition In */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Transition In</label>
              <select
                value={selectedClip.transitionIn?.type || 'none'}
                onChange={(e) => onUpdateClip(selectedClip.id, { 
                  transitionIn: { type: e.target.value as TransitionType, duration: selectedClip.transitionIn?.duration || 0.8 } 
                })}
                className="w-full bg-[#121216] border border-[#2b2b36] rounded px-1.5 py-1 text-zinc-200 text-[10px]"
              >
                {transitions.map(t => (
                  <option key={t.id} value={t.id} className="bg-[#1c1c24]">{t.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Duration (s)</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="3"
                value={selectedClip.transitionIn?.duration || 0.8}
                onChange={(e) => onUpdateClip(selectedClip.id, {
                  transitionIn: { 
                    type: selectedClip.transitionIn?.type || 'cross-dissolve', 
                    duration: parseFloat(e.target.value) || 0.8 
                  }
                })}
                className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 font-mono-code text-[10px]"
              />
            </div>
          </div>

          {/* Transition Out */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Transition Out</label>
              <select
                value={selectedClip.transitionOut?.type || 'none'}
                onChange={(e) => onUpdateClip(selectedClip.id, { 
                  transitionOut: { type: e.target.value as TransitionType, duration: selectedClip.transitionOut?.duration || 0.8 } 
                })}
                className="w-full bg-[#121216] border border-[#2b2b36] rounded px-1.5 py-1 text-zinc-200 text-[10px]"
              >
                {transitions.map(t => (
                  <option key={t.id} value={t.id} className="bg-[#1c1c24]">{t.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Duration (s)</label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="3"
                value={selectedClip.transitionOut?.duration || 0.8}
                onChange={(e) => onUpdateClip(selectedClip.id, {
                  transitionOut: { 
                    type: selectedClip.transitionOut?.type || 'cross-dissolve', 
                    duration: parseFloat(e.target.value) || 0.8 
                  }
                })}
                className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 font-mono-code text-[10px]"
              />
            </div>
          </div>
        </div>

        {/* Section 4: Audio Volume & Pan (for video or audio clips) */}
        {(selectedClip.type === 'audio' || selectedClip.type === 'video') && (
          <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
            <div className="flex items-center justify-between border-b border-[#2a2a36] pb-1.5">
              <div className="flex items-center space-x-1 text-emerald-400 font-semibold text-[11px]">
                <Volume2 className="w-3.5 h-3.5" />
                <span>Clip Audio Channel</span>
              </div>
            </div>

            {/* Volume */}
            <div>
              <div className="flex justify-between items-center text-[10px] mb-1">
                <span className="text-zinc-400">Clip Volume</span>
                <div className="flex items-center space-x-1.5">
                  <span className="font-mono-code text-emerald-400">
                    {Math.round((selectedClip.audioConfig?.volume ?? 1) * 100)}%
                  </span>
                  <KeyframeButton property="volume" title="Add keyframe at playhead (audio fade)" />
                </div>
              </div>
              <input
                type="range"
                min={0}
                max={2}
                step={0.05}
                value={selectedClip.audioConfig?.volume ?? 1}
                onChange={(e) => onUpdateClip(selectedClip.id, {
                  audioConfig: {
                    ...(selectedClip.audioConfig || { pan: 0, mute: false }),
                    volume: parseFloat(e.target.value)
                  }
                })}
                className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer accent-emerald-500"
              />
            </div>

            {/* Fade In / Fade Out — also applied automatically wherever this
                clip overlaps another on the same track (auto-crossfade), on
                top of whatever's set here. */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Fade In (s)</label>
                <input
                  type="number"
                  min={0}
                  max={selectedClip.duration / 2}
                  step={0.1}
                  value={selectedClip.audioConfig?.fadeIn ?? 0}
                  onChange={(e) => onUpdateClip(selectedClip.id, {
                    audioConfig: {
                      ...(selectedClip.audioConfig || { volume: 1, pan: 0, mute: false }),
                      fadeIn: Math.max(0, parseFloat(e.target.value) || 0)
                    }
                  })}
                  className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 font-mono-code text-[11px] focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Fade Out (s)</label>
                <input
                  type="number"
                  min={0}
                  max={selectedClip.duration / 2}
                  step={0.1}
                  value={selectedClip.audioConfig?.fadeOut ?? 0}
                  onChange={(e) => onUpdateClip(selectedClip.id, {
                    audioConfig: {
                      ...(selectedClip.audioConfig || { volume: 1, pan: 0, mute: false }),
                      fadeOut: Math.max(0, parseFloat(e.target.value) || 0)
                    }
                  })}
                  className="w-full bg-[#121216] border border-[#2b2b36] rounded px-2 py-1 text-zinc-200 font-mono-code text-[11px] focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
