// -----------------------------------------------------------------------
// VidCraft Pro — device performance tier (v43, new)
// -----------------------------------------------------------------------
// Pure, side-effect-free heuristics for scaling preview rendering cost
// (resolution, meter update rate) down on weaker Android hardware, without
// touching export quality — exports always render at full project
// resolution regardless of this file (see ExportModal.tsx).
//
// This intentionally does not try to be a precise device database. It uses
// only signals every Chromium-based WebView (including Capacitor's Android
// WebView) exposes, and always fails safe toward 'high' (i.e. today's v42
// behavior) when a signal is unavailable — so a browser that doesn't
// support `navigator.deviceMemory`, for example, is never mis-classified
// as low-end just because the API is missing.

export type DeviceTier = 'low' | 'mid' | 'high';

interface NavigatorWithHints extends Navigator {
  deviceMemory?: number; // GiB, Chromium-only
}

let cachedTier: DeviceTier | null = null;

/**
 * Classifies the current device into a coarse performance tier using CPU
 * core count, approximate RAM, and pixel density — the same signals
 * Chromium itself exposes for "lite" heuristics. Result is computed once
 * and cached (these values don't change during a session).
 */
export function getDeviceTier(): DeviceTier {
  if (cachedTier) return cachedTier;

  if (typeof navigator === 'undefined') {
    cachedTier = 'high';
    return cachedTier;
  }

  const nav = navigator as NavigatorWithHints;
  const cores = nav.hardwareConcurrency ?? 8; // unknown → assume capable
  const memoryGiB = nav.deviceMemory ?? 8; // unknown → assume capable
  const dpr = typeof window !== 'undefined' ? (window.devicePixelRatio || 1) : 1;

  // Low-end: budget Android phones commonly report 2-4 cores and
  // deviceMemory <= 2 (Chrome buckets this value, e.g. reports 2 for
  // anything from ~2-4GB actual RAM).
  if (cores <= 4 && memoryGiB <= 2) {
    cachedTier = 'low';
    return cachedTier;
  }

  // Mid-range: typical mid-tier Android (2024-era) — 6-8 cores, 3-4GB
  // reported, often a high-density (>2x) panel that's expensive to
  // composite/export preview frames at full resolution.
  if (cores <= 6 || memoryGiB <= 4 || dpr >= 3) {
    cachedTier = 'mid';
    return cachedTier;
  }

  cachedTier = 'high';
  return cachedTier;
}

/** True on any signal that this is a touch-primary mobile device (used to
 *  decide UI density/hit-target sizing, not just performance). */
export function isTouchPrimaryDevice(): boolean {
  if (typeof window === 'undefined') return false;
  return window.matchMedia?.('(pointer: coarse)').matches ?? false;
}

/**
 * Recommended cap (px, longer edge) for the live Program Monitor preview
 * canvas, by tier. Desktop/high-end is unchanged from v42 (1280). Lower
 * tiers trade preview sharpness for meaningfully less per-frame canvas
 * fill + filter cost, which is where mobile CPU/GPU and battery drain
 * shows up first during scrubbing/playback. Export resolution is never
 * affected — see computePreviewDimensions in previewResolution.ts.
 */
export function getPreviewResolutionCap(tier: DeviceTier = getDeviceTier()): number {
  switch (tier) {
    case 'low': return 640;
    case 'mid': return 960;
    case 'high': return 1280;
  }
}
