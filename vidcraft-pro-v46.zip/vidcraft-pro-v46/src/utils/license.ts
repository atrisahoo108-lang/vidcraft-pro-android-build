// -----------------------------------------------------------------------
// VidCraft Pro — Free / Pro licensing foundation
// -----------------------------------------------------------------------
// This file is intentionally still not a real licensing system: there is
// no server, no payment provider, and no real cryptographic verification
// active yet. It clearly separates THREE things that used to be blurred
// together:
//
//   1. TEST/DEV override      — a local, explicit "pretend to be FREE/PRO"
//                                switch for development only.
//   2. PRODUCTION license     — the shape a real license record will have
//                                once an external payment/licensing system
//                                exists, now including optional metadata
//                                (signature/keyId/algorithm/issuedAt) for
//                                a future signed license — see
//                                licenseVerification.ts for why carrying
//                                that metadata does NOT mean it's checked.
//   3. Resolved license tier  — what the rest of the app actually asks for
//                                via isProUser()/getLicenseTier(), combining
//                                the two sources above with a clear priority.
//                                This tier resolution is UNCHANGED by the
//                                verification boundary below — it still
//                                depends only on status/expiry, exactly as
//                                before, so nothing already wired to
//                                isProUser() breaks. Verification is
//                                surfaced separately (see
//                                LicenseStatusSnapshot.verification) so a
//                                future activation system can start
//                                requiring it once a real key exists,
//                                without this file's shape needing to
//                                change again.
//
// Every function that existed before (isProUser, getLicenseTier,
// setDevLicenseOverride, the LicenseTier type) still has the exact same
// name and signature, so nothing else in the app needs to change.

import { verifyProductionLicense, type LicenseVerificationResult } from './licenseVerification';

export type LicenseTier = 'FREE' | 'PRO';

/** Everyone is FREE until a real license says otherwise. */
const DEFAULT_TIER: LicenseTier = 'FREE';

// ---------------------------------------------------------------------
// 1. TEST/DEV override — TEST ONLY, never treat this as a real license.
// ---------------------------------------------------------------------
// Lets Free/Pro behavior be tested locally before any real payment system
// exists. Persisted in localStorage under a name that says "test" so it's
// unmistakable in devtools, and kept in its own section so it can never be
// confused with (or accidentally merged into) real license data below.

const TEST_OVERRIDE_KEY = 'vidcraft:testLicenseOverride';

/**
 * TEMPORARY DEV/TEST SWITCH — not a real licensing system (see file header).
 * Pass `null` to clear the override and fall back to whatever the
 * production license (or the default) says.
 */
export function setDevLicenseOverride(tier: LicenseTier | null): void {
  try {
    if (tier === null) {
      window.localStorage.removeItem(TEST_OVERRIDE_KEY);
    } else {
      window.localStorage.setItem(TEST_OVERRIDE_KEY, tier);
    }
  } catch {
    // localStorage unavailable (private browsing, etc.) — the override
    // just won't persist across reloads; not worth surfacing an error.
  }
}

function getDevLicenseOverride(): LicenseTier | null {
  try {
    const stored = window.localStorage.getItem(TEST_OVERRIDE_KEY);
    return stored === 'PRO' || stored === 'FREE' ? stored : null;
  } catch {
    return null;
  }
}

/** True if a TEST/DEV override is currently forcing the license tier. */
export function isTestOverrideActive(): boolean {
  return getDevLicenseOverride() !== null;
}

// ---------------------------------------------------------------------
// 2. Production license — the future real license record.
// ---------------------------------------------------------------------
// This is a data shape and local read/write helpers only. Nothing in the
// app currently sets one — there is no payment provider integrated yet.
// It exists so that when one is, it has a single obvious place to store
// its result: setProductionLicense(...), read by getLicenseStatus().

export type LicenseStatus = 'active' | 'expired' | 'cancelled' | 'none';

export interface ProductionLicense {
  licenseId: string;
  tier: LicenseTier;
  status: LicenseStatus;
  /** ISO date string, or null if the license doesn't expire. */
  expiryDate: string | null;
  userEmail?: string;

  // Optional metadata for a future SIGNED license (see
  // licenseVerification.ts). Nothing in this codebase produces real
  // values for these yet — no signing key exists. Their presence is
  // structurally validated below (right type), but is deliberately never
  // treated as cryptographic proof of anything by this file.
  /** Base64/hex-encoded signature over the rest of the license fields. */
  signature?: string;
  /** Identifies which public key the signature should be checked against. */
  keyId?: string;
  /** e.g. 'RSA-SHA256' — informational until a real verifier exists. */
  algorithm?: string;
  /** ISO date string — when the license record itself was issued. */
  issuedAt?: string;
}

const PRODUCTION_LICENSE_KEY = 'vidcraft:productionLicense';

function isValidProductionLicense(value: unknown): value is ProductionLicense {
  if (!value || typeof value !== 'object') return false;
  const v = value as Record<string, unknown>;
  const baseValid = (
    typeof v.licenseId === 'string' &&
    (v.tier === 'FREE' || v.tier === 'PRO') &&
    (v.status === 'active' || v.status === 'expired' || v.status === 'cancelled' || v.status === 'none') &&
    (v.expiryDate === null || typeof v.expiryDate === 'string')
  );
  if (!baseValid) return false;
  // Optional signed-license metadata: if present at all, it must at least
  // be the right type. This is structural validation only — it says
  // nothing about whether a signature is genuine (see verifyProductionLicense).
  if (v.signature !== undefined && typeof v.signature !== 'string') return false;
  if (v.keyId !== undefined && typeof v.keyId !== 'string') return false;
  if (v.algorithm !== undefined && typeof v.algorithm !== 'string') return false;
  if (v.issuedAt !== undefined && typeof v.issuedAt !== 'string') return false;
  return true;
}

function readProductionLicense(): ProductionLicense | null {
  try {
    const raw = window.localStorage.getItem(PRODUCTION_LICENSE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    // A corrupted or unexpected value (e.g. from a future format change)
    // is treated as "no license" rather than crashing the app.
    return isValidProductionLicense(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/**
 * Stores a production license record locally. Intended to be called once a
 * real payment/licensing backend has verified a purchase and returned a
 * license — nothing in this codebase calls this yet.
 */
export function setProductionLicense(license: ProductionLicense): void {
  try {
    window.localStorage.setItem(PRODUCTION_LICENSE_KEY, JSON.stringify(license));
  } catch {
    // localStorage unavailable — see setDevLicenseOverride() above.
  }
}

/** Removes any stored production license (e.g. on logout/cancellation). */
export function clearProductionLicense(): void {
  try {
    window.localStorage.removeItem(PRODUCTION_LICENSE_KEY);
  } catch {
    // localStorage unavailable — see setDevLicenseOverride() above.
  }
}

function isProductionLicenseUsable(license: ProductionLicense): boolean {
  if (license.status !== 'active') return false;
  if (license.expiryDate !== null) {
    const expiry = new Date(license.expiryDate).getTime();
    // v30 edge case fix: a malformed expiryDate must NOT silently become a
    // non-expiring license. `Number.isNaN(expiry)` means the date string
    // couldn't be parsed at all — that's an invalid/unusable license, not
    // "no expiry", so this must reject it rather than fall through.
    if (Number.isNaN(expiry)) return false;
    if (expiry < Date.now()) return false;
  }
  return true;
}

// ---------------------------------------------------------------------
// 3. Resolved license status — what the rest of the app should use.
// ---------------------------------------------------------------------
// Priority: an active TEST override always wins (that's the point of a
// dev switch — it should reliably force a state for testing regardless of
// whatever production data is or isn't present), then a valid, currently-
// usable production license, then the default (FREE).

export interface LicenseStatusSnapshot {
  tier: LicenseTier;
  /** Which source decided `tier`: an explicit test override, a real
   *  production license, or neither (the default). */
  source: 'test' | 'production' | 'default';
  /** The stored production license, if any — present even if it's expired
   *  or was overridden by a test switch, so callers can e.g. show
   *  "Pro expired on <date>" instead of just "Free". */
  production: ProductionLicense | null;
  /** Result of passing `production` through the verification boundary
   *  (see licenseVerification.ts). Informational only for now — it does
   *  NOT affect `tier` above, since no real verifier/key exists yet. A
   *  future activation system can start requiring
   *  `verification.verified === true` once one does, without this
   *  snapshot's shape needing to change again. */
  verification: LicenseVerificationResult;
}

/** Full picture of the current license — tier plus where it came from. */
export function getLicenseStatus(): LicenseStatusSnapshot {
  const production = readProductionLicense();
  const verification = verifyProductionLicense(production);

  const testOverride = getDevLicenseOverride();
  if (testOverride) {
    return { tier: testOverride, source: 'test', production, verification };
  }

  if (production && isProductionLicenseUsable(production)) {
    return { tier: production.tier, source: 'production', production, verification };
  }

  return { tier: DEFAULT_TIER, source: 'default', production, verification };
}

/** The app's current license tier — unchanged signature/behavior from before. */
export function getLicenseTier(): LicenseTier {
  return getLicenseStatus().tier;
}

/** Reusable check for any current/future Pro-only feature — unchanged. */
export function isProUser(): boolean {
  return getLicenseTier() === 'PRO';
}
