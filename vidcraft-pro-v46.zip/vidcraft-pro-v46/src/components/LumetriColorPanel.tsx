import React, { useState, useRef, useEffect } from 'react';
import { 
  Palette, Sun, SlidersHorizontal, RefreshCcw, 
  Layers, Check, Eye, Activity 
} from 'lucide-react';
import { Clip, LumetriGrade } from '../types';
import { LUT_PRESETS, DEFAULT_LUMETRI } from '../data/sampleMedia';
import { canUseFeature, PRO_LOCK_MESSAGE } from '../utils/premiumFeatures';
import { PremiumBadge } from './PremiumBadge';

interface LumetriColorPanelProps {
  selectedClip: Clip | null;
  onUpdateClip: (clipId: string, updates: Partial<Clip>) => void;
  // v44: taller header/tab bar on mobile; slider thumbs are enlarged for
  // touch globally (see index.css). Doesn't touch the Pro/LUT gating logic
  // below. Defaults to false — desktop/web is unchanged.
  isMobile?: boolean;
}

export const LumetriColorPanel: React.FC<LumetriColorPanelProps> = ({
  selectedClip,
  onUpdateClip,
  isMobile = false
}) => {
  const [activeTab, setActiveTab] = useState<'basic' | 'creative' | 'wheels' | 'scopes'>('basic');
  // Premium Feature Lock Foundation (v31): a simple, self-clearing notice
  // for when a PRO-gated action is blocked in FREE mode. Not a payment
  // prompt — just the required "available in VidCraft Pro" message.
  const [lockNotice, setLockNotice] = useState<string | null>(null);
  useEffect(() => {
    if (!lockNotice) return;
    const timer = setTimeout(() => setLockNotice(null), 3500);
    return () => clearTimeout(timer);
  }, [lockNotice]);

  const scopesCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const lumetri: LumetriGrade = selectedClip?.lumetri || DEFAULT_LUMETRI;

  const updateLumetri = (key: keyof LumetriGrade, value: any) => {
    if (!selectedClip) return;
    const newLumetri: LumetriGrade = {
      ...lumetri,
      [key]: value
    };
    onUpdateClip(selectedClip.id, { lumetri: newLumetri });
  };

  const applyLut = (lut: typeof LUT_PRESETS[0]) => {
    if (!selectedClip) return;
    // Cinematic LUT Looks are the one feature gated in this pass — basic
    // color correction (exposure/contrast/wheels/etc.) is untouched and
    // stays fully available regardless of license.
    if (!canUseFeature('cinematic-luts')) {
      setLockNotice(PRO_LOCK_MESSAGE);
      return;
    }
    onUpdateClip(selectedClip.id, {
      lumetri: {
        ...lumetri,
        ...lut.lumetri,
        presetName: lut.name
      }
    });
  };

  const handleResetLumetri = () => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, { lumetri: { ...DEFAULT_LUMETRI } });
  };

  // Render Real-time RGB Parade / Lumetri Waveform Scopes
  useEffect(() => {
    if (activeTab !== 'scopes') return;
    const canvas = scopesCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    ctx.fillStyle = '#09090c';
    ctx.fillRect(0, 0, w, h);

    // Draw scope grid lines
    ctx.strokeStyle = '#22222a';
    ctx.lineWidth = 1;
    for (let y = 0; y < h; y += h / 5) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // RGB Parade channels: Red (Left), Green (Center), Blue (Right)
    const channelW = w / 3;
    const exposureShift = (lumetri.exposure || 0) * 15;
    const contrastMod = 1 + (lumetri.contrast || 0) / 100;
    const tempShift = (lumetri.temperature || 0) * 0.4;
    const tintShift = (lumetri.tint || 0) * 0.4;

    // 1. Red Channel
    ctx.strokeStyle = '#ef4444';
    ctx.beginPath();
    for (let x = 0; x < channelW; x += 2) {
      const noise = Math.sin(x * 0.1) * 20 + Math.cos(x * 0.05) * 15;
      const baseVal = (h * 0.5) - exposureShift - tempShift;
      const y = Math.max(10, Math.min(h - 10, baseVal + noise * contrastMod));
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // 2. Green Channel
    ctx.strokeStyle = '#22c55e';
    ctx.beginPath();
    for (let x = 0; x < channelW; x += 2) {
      const noise = Math.sin(x * 0.12 + 1) * 22 + Math.cos(x * 0.04) * 14;
      const baseVal = (h * 0.5) - exposureShift + tintShift;
      const y = Math.max(10, Math.min(h - 10, baseVal + noise * contrastMod));
      if (x === 0) ctx.moveTo(channelW + x, y);
      else ctx.lineTo(channelW + x, y);
    }
    ctx.stroke();

    // 3. Blue Channel
    ctx.strokeStyle = '#38bdf8';
    ctx.beginPath();
    for (let x = 0; x < channelW; x += 2) {
      const noise = Math.sin(x * 0.09 + 2) * 18 + Math.cos(x * 0.06) * 16;
      const baseVal = (h * 0.5) - exposureShift + tempShift;
      const y = Math.max(10, Math.min(h - 10, baseVal + noise * contrastMod));
      if (x === 0) ctx.moveTo(channelW * 2 + x, y);
      else ctx.lineTo(channelW * 2 + x, y);
    }
    ctx.stroke();

    // Channel Labels
    ctx.font = '10px Fira Code, monospace';
    ctx.fillStyle = '#ef4444';
    ctx.fillText('R', 10, 15);
    ctx.fillStyle = '#22c55e';
    ctx.fillText('G', channelW + 10, 15);
    ctx.fillStyle = '#38bdf8';
    ctx.fillText('B', channelW * 2 + 10, 15);

  }, [activeTab, lumetri]);

  if (!selectedClip) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#17171c] text-zinc-500 text-xs p-4 select-none">
        <Palette className="w-8 h-8 text-zinc-600 mb-2 opacity-60" />
        <span className="font-medium text-zinc-400">Lumetri Color</span>
        <span className="text-[11px] text-zinc-600 mt-1 text-center max-w-[200px]">
          Select a clip on the timeline to perform color correction, LUT grades, and color wheel adjustments.
        </span>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-[#16161b] text-zinc-200 text-xs select-none overflow-y-auto">
      {/* Top Header */}
      <div className={`bg-[#1e1e26] border-b border-[#282834] px-3 flex items-center justify-between ${isMobile ? 'h-11' : 'h-8'}`}>
        <div className="flex items-center space-x-1.5">
          <Palette className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-semibold text-zinc-100 text-[11px]">Lumetri Color</span>
          {lumetri.presetName && (
            <span className="text-[10px] text-sky-400 font-mono-code bg-[#121216] px-1.5 py-0.5 rounded border border-[#2b2b36]">
              {lumetri.presetName}
            </span>
          )}
        </div>
        <button
          id="lumetri-reset-btn"
          onClick={handleResetLumetri}
          title="Reset Lumetri Color"
          className={`text-zinc-400 hover:text-zinc-100 rounded hover:bg-[#282834] ${isMobile ? 'p-2' : 'p-1'}`}
        >
          <RefreshCcw className="w-3 h-3" />
        </button>
      </div>

      {/* Lumetri Sub-Tabs */}
      <div className="flex bg-[#141418] border-b border-[#242430] p-1 text-[11px]">
        {[
          { id: 'basic', label: 'Basic Correction' },
          { id: 'creative', label: 'Creative LUTs' },
          { id: 'wheels', label: 'Color Wheels' },
          { id: 'scopes', label: 'RGB Scopes' },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`flex-1 text-center rounded transition-colors ${isMobile ? 'py-2.5' : 'py-1'} ${
              activeTab === t.id ? 'bg-[#282834] text-amber-400 font-medium' : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab Contents */}
      <div className="p-3 space-y-4">
        {/* 1. Basic Correction */}
        {activeTab === 'basic' && (
          <div className="space-y-3">
            {/* White Balance Group */}
            <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
              <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
                White Balance
              </span>

              {/* Temperature */}
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-zinc-400">Temperature (Kelvin)</span>
                  <span className={`font-mono-code ${lumetri.temperature > 0 ? 'text-amber-400' : lumetri.temperature < 0 ? 'text-sky-400' : 'text-zinc-400'}`}>
                    {lumetri.temperature > 0 ? `+${lumetri.temperature}` : lumetri.temperature}
                  </span>
                </div>
                <input
                  type="range"
                  min={-100}
                  max={100}
                  value={lumetri.temperature}
                  onChange={(e) => updateLumetri('temperature', parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-gradient-to-r from-sky-500 via-zinc-600 to-amber-500 rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Tint */}
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-zinc-400">Tint (Magenta/Green)</span>
                  <span className={`font-mono-code ${lumetri.tint > 0 ? 'text-pink-400' : lumetri.tint < 0 ? 'text-emerald-400' : 'text-zinc-400'}`}>
                    {lumetri.tint > 0 ? `+${lumetri.tint}` : lumetri.tint}
                  </span>
                </div>
                <input
                  type="range"
                  min={-100}
                  max={100}
                  value={lumetri.tint}
                  onChange={(e) => updateLumetri('tint', parseFloat(e.target.value))}
                  className="w-full h-1.5 bg-gradient-to-r from-emerald-500 via-zinc-600 to-pink-500 rounded appearance-none cursor-pointer"
                />
              </div>
            </div>

            {/* Tone Group */}
            <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5 space-y-2.5">
              <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
                Tone & Dynamic Range
              </span>

              {/* Exposure */}
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-zinc-400">Exposure</span>
                  <span className="font-mono-code text-zinc-200">{(lumetri.exposure).toFixed(2)} EV</span>
                </div>
                <input
                  type="range"
                  min={-3}
                  max={3}
                  step={0.05}
                  value={lumetri.exposure}
                  onChange={(e) => updateLumetri('exposure', parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Contrast */}
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-zinc-400">Contrast</span>
                  <span className="font-mono-code text-zinc-200">{Math.round(lumetri.contrast)}</span>
                </div>
                <input
                  type="range"
                  min={-100}
                  max={100}
                  value={lumetri.contrast}
                  onChange={(e) => updateLumetri('contrast', parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Saturation */}
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-zinc-400">Saturation</span>
                  <span className="font-mono-code text-amber-400">{Math.round(lumetri.saturation)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={200}
                  value={lumetri.saturation}
                  onChange={(e) => updateLumetri('saturation', parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer"
                />
              </div>

              {/* Vignette */}
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-zinc-400">Vignette Amount</span>
                  <span className="font-mono-code text-zinc-200">{Math.round(lumetri.vignette)}</span>
                </div>
                <input
                  type="range"
                  min={-100}
                  max={100}
                  value={lumetri.vignette}
                  onChange={(e) => updateLumetri('vignette', parseFloat(e.target.value))}
                  className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* 2. Creative LUT Presets */}
        {activeTab === 'creative' && (
          <div className="space-y-2">
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
              Cinematic LUT Looks
              <PremiumBadge />
            </span>
            {lockNotice && (
              <p className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5">
                {lockNotice}
              </p>
            )}
            <div className="grid grid-cols-1 gap-2">
              {LUT_PRESETS.map((lut) => {
                const isActive = lumetri.presetName === lut.name;
                return (
                  <button
                    key={lut.name}
                    onClick={() => applyLut(lut)}
                    className={`text-left p-2.5 rounded-md border transition-all flex items-start justify-between ${
                      isActive 
                        ? 'bg-amber-950/30 border-amber-500/60 text-amber-200' 
                        : 'bg-[#1b1b22] border-[#272732] hover:border-[#3a3a4c] text-zinc-300'
                    }`}
                  >
                    <div>
                      <div className="font-semibold text-xs text-zinc-100">{lut.name}</div>
                      <div className="text-[10px] text-zinc-400 mt-0.5">{lut.description}</div>
                    </div>
                    {isActive && <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* 3. 3-Way Color Wheels */}
        {activeTab === 'wheels' && (
          <div className="space-y-3">
            <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
              3-Way Color Wheels
            </span>

            {/* Shadows / Lift */}
            <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[11px] font-semibold text-sky-400">Lift (Shadows)</span>
                <input
                  type="color"
                  value={lumetri.liftColor || '#000000'}
                  onChange={(e) => updateLumetri('liftColor', e.target.value)}
                  className="w-5 h-5 rounded border-0 bg-transparent cursor-pointer"
                />
              </div>
              <p className="text-[9px] text-zinc-500">Tint the darkest shadow tones of the footage.</p>
            </div>

            {/* Midtones / Gamma */}
            <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[11px] font-semibold text-emerald-400">Gamma (Midtones)</span>
                <input
                  type="color"
                  value={lumetri.gammaColor || '#808080'}
                  onChange={(e) => updateLumetri('gammaColor', e.target.value)}
                  className="w-5 h-5 rounded border-0 bg-transparent cursor-pointer"
                />
              </div>
              <p className="text-[9px] text-zinc-500">Tint the natural skin tones and middle brightness range.</p>
            </div>

            {/* Highlights / Gain */}
            <div className="bg-[#1b1b22] border border-[#272732] rounded-md p-2.5">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[11px] font-semibold text-amber-400">Gain (Highlights)</span>
                <input
                  type="color"
                  value={lumetri.gainColor || '#ffffff'}
                  onChange={(e) => updateLumetri('gainColor', e.target.value)}
                  className="w-5 h-5 rounded border-0 bg-transparent cursor-pointer"
                />
              </div>
              <p className="text-[9px] text-zinc-500">Tint the sky and bright specular highlights.</p>
            </div>
          </div>
        )}

        {/* 4. RGB Parade Scopes */}
        {activeTab === 'scopes' && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider">
                RGB Parade / Waveform
              </span>
              <Activity className="w-3 h-3 text-sky-400" />
            </div>
            <div className="bg-[#09090c] border border-[#272732] rounded p-1 flex justify-center">
              <canvas
                ref={scopesCanvasRef}
                width={280}
                height={160}
                className="w-full h-40 rounded"
              />
            </div>
            <p className="text-[10px] text-zinc-500 text-center">
              Real-time exposure distribution across Red, Green, and Blue color channels.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
