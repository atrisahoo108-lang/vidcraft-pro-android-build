import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Mic, Sliders, Radio, Music } from 'lucide-react';
import { Track } from '../types';
import { audioEngine } from '../utils/audioEngine';
import { getDeviceTier } from '../utils/deviceTier';

interface AudioMixerPanelProps {
  tracks: Track[];
  onUpdateTrack: (trackId: string, updates: Partial<Track>) => void;
  masterVolume: number;
  setMasterVolume: (val: number) => void;
  isPlaying: boolean;
  // v44: wider fader strips and bigger Mute/Solo touch targets on mobile;
  // also slows the VU-meter refresh on lower-tier hardware (see below).
  // Defaults to false — desktop/web is unchanged.
  isMobile?: boolean;
}

export const AudioMixerPanel: React.FC<AudioMixerPanelProps> = ({
  tracks,
  onUpdateTrack,
  masterVolume,
  setMasterVolume,
  isPlaying,
  isMobile = false
}) => {
  const [meterLevels, setMeterLevels] = useState<{ left: number; right: number }>({ left: 0, right: 0 });

  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      // v44: the VU meter was always polled at a fixed 50ms (20fps)
      // regardless of device. That's a steady stream of React state
      // updates purely for a cosmetic meter — on a low/mid-tier Android
      // phone that's competing with actual video compositing for the
      // same main thread, so it's throttled there. High-end/desktop keeps
      // the original 50ms responsiveness.
      const tier = getDeviceTier();
      const intervalMs = tier === 'low' ? 150 : tier === 'mid' ? 90 : 50;
      timer = setInterval(() => {
        setMeterLevels(audioEngine.getMeterLevels());
      }, intervalMs);
    } else {
      setMeterLevels({ left: 0, right: 0 });
    }
    return () => clearInterval(timer);
  }, [isPlaying]);

  return (
    <div className="h-full flex flex-col bg-[#16161b] text-zinc-200 text-xs select-none">
      {/* Header */}
      <div className={`bg-[#1e1e26] border-b border-[#282834] px-3 flex items-center justify-between ${isMobile ? 'h-11' : 'h-8'}`}>
        <div className="flex items-center space-x-1.5">
          <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
          <span className="font-semibold text-zinc-100 text-[11px]">Audio Track Mixer</span>
        </div>
      </div>

      <div className={`flex-1 overflow-x-auto flex items-stretch justify-start ${isMobile ? 'p-2 space-x-2' : 'p-3 space-x-3'}`}>
        {/* Per-Track Fader Strips */}
        {tracks.map(track => {
          const isAudio = track.type === 'audio';
          return (
            <div
              key={track.id}
              className={`bg-[#1b1b22] border border-[#272732] rounded-lg flex flex-col items-center justify-between shrink-0 ${
                isMobile ? 'w-28 p-2.5' : 'w-24 p-2'
              }`}
            >
              {/* Track Name */}
              <div className="text-center w-full truncate">
                <span className="font-semibold text-[10px] text-zinc-200 truncate block" title={track.name}>
                  {track.name.split(' - ')[0]}
                </span>
                <span className="text-[8px] text-zinc-500 uppercase">{track.type}</span>
              </div>

              {/* Solo & Mute Buttons */}
              <div className={`flex items-center my-2 ${isMobile ? 'space-x-1.5' : 'space-x-1'}`}>
                <button
                  onClick={() => onUpdateTrack(track.id, { isMuted: !track.isMuted })}
                  className={`rounded font-bold ${isMobile ? 'px-2.5 py-1.5 text-[10px]' : 'px-1.5 py-0.5 text-[9px]'} ${
                    track.isMuted ? 'bg-red-600 text-white' : 'bg-[#2b2b36] text-zinc-400 hover:text-zinc-200'
                  }`}
                  title="Mute Track (M)"
                >
                  M
                </button>
                <button
                  onClick={() => onUpdateTrack(track.id, { isSolo: !track.isSolo })}
                  className={`rounded font-bold ${isMobile ? 'px-2.5 py-1.5 text-[10px]' : 'px-1.5 py-0.5 text-[9px]'} ${
                    track.isSolo ? 'bg-amber-500 text-black' : 'bg-[#2b2b36] text-zinc-400 hover:text-zinc-200'
                  }`}
                  title="Solo Track (S)"
                >
                  S
                </button>
              </div>

              {/* Vertical Fader Slider */}
              <div className={`flex-1 flex items-center justify-center my-2 relative ${isMobile ? 'h-36' : 'h-32'}`}>
                <input
                  type="range"
                  min={0}
                  max={1.5}
                  step={0.05}
                  value={track.volume}
                  onChange={(e) => onUpdateTrack(track.id, { volume: parseFloat(e.target.value) })}
                  className={`-rotate-90 bg-[#2b2b36] appearance-none cursor-pointer accent-emerald-500 touch-none ${
                    isMobile ? 'h-32 w-28' : 'h-28 w-24'
                  }`}
                />
              </div>

              {/* Track Volume Readout */}
              <div className="text-center font-mono-code text-[10px] text-emerald-400 font-semibold mt-1">
                {Math.round(track.volume * 100)}%
              </div>
            </div>
          );
        })}

        {/* Master Output Channel Strip */}
        <div className={`bg-[#1f1f28] border border-[#3b3b4c] rounded-lg flex flex-col items-center justify-between shrink-0 shadow-lg ${
          isMobile ? 'w-32 p-2.5' : 'w-28 p-2'
        }`}>
          <div className="text-center w-full">
            <span className="font-bold text-[11px] text-sky-400 block">MASTER</span>
            <span className="text-[8px] text-zinc-400">OUT (L/R)</span>
          </div>

          {/* Master VU Meter */}
          <div className="w-10 h-28 bg-[#111116] border border-[#2c2c38] rounded flex space-x-1 p-1 items-end my-2">
            <div className="flex-1 bg-[#1e1e28] rounded-sm h-full flex flex-col justify-end overflow-hidden">
              <div 
                className="w-full transition-all duration-75"
                style={{
                  height: `${meterLevels.left}%`,
                  background: meterLevels.left > 85 ? '#ef4444' : meterLevels.left > 65 ? '#f59e0b' : '#10b981'
                }}
              />
            </div>
            <div className="flex-1 bg-[#1e1e28] rounded-sm h-full flex flex-col justify-end overflow-hidden">
              <div 
                className="w-full transition-all duration-75"
                style={{
                  height: `${meterLevels.right}%`,
                  background: meterLevels.right > 85 ? '#ef4444' : meterLevels.right > 65 ? '#f59e0b' : '#10b981'
                }}
              />
            </div>
          </div>

          {/* Master Volume Slider */}
          <div className="w-full">
            <input
              type="range"
              min={0}
              max={1.5}
              step={0.05}
              value={masterVolume}
              onChange={(e) => {
                const v = parseFloat(e.target.value);
                setMasterVolume(v);
                audioEngine.setMasterVolume(v);
              }}
              className={`w-full bg-[#2b2b36] rounded appearance-none cursor-pointer accent-sky-500 touch-none ${isMobile ? 'h-2.5' : 'h-1.5'}`}
            />
            <div className="text-center font-mono-code text-[10px] text-sky-300 font-semibold mt-1">
              {Math.round(masterVolume * 100)}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
