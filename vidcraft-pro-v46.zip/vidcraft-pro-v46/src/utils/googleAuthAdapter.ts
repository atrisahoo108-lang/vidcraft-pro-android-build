// -----------------------------------------------------------------------
// VidCraft Pro — Google Sign-In adapter (implements AuthAdapter from auth.ts)
// -----------------------------------------------------------------------
// This is the ONLY file in the app that imports the Firebase SDK or knows
// what "Firebase" is. The rest of the app — including every UI component —
// talks to auth.ts's provider-neutral API (getAuthState, signInWithGoogle,
// signOut, subscribeToAuthState) and never imports this file directly. See
// auth.ts's own header for why that separation matters.
//
// If Firebase isn't configured (see firebaseConfig.ts), this module does
// nothing at import time: no SDK code even loads, no adapter registers,
// no network request happens. auth.ts's getAuthState().providerConfigured
// stays false, exactly as it was before this file existed.
//
// This file also never imports license.ts or premiumFeatures.ts, and never
// will by accident — signing in here has no effect on isProUser().

import { getFirebaseConfig } from './firebaseConfig';
import { registerAuthAdapter, notifyAuthStateChanged, type AuthAdapter, type AuthUser } from './auth';

const config = getFirebaseConfig();

if (config) {
  // Registered synchronously so getAuthState() can report `providerConfigured:
  // true` (and `status: 'loading'`, via isReady() below) immediately — the
  // actual Firebase SDK import and session restore happen asynchronously
  // inside the adapter's methods/init below.
  registerAuthAdapter(createGoogleAdapter(config));
}

function createGoogleAdapter(firebaseConfig: NonNullable<ReturnType<typeof getFirebaseConfig>>): AuthAdapter {
  type FirebaseAuthModule = typeof import('firebase/auth');

  let auth: import('firebase/auth').Auth | null = null;
  let googleProvider: import('firebase/auth').GoogleAuthProvider | null = null;
  let authModule: FirebaseAuthModule | null = null;
  let currentUser: AuthUser | null = null;
  let ready = false;

  function detectProvider(fbUser: import('firebase/auth').User): AuthUser['provider'] {
    // Fallback for the ambient auth-state listener, which doesn't know
    // which sign-in method was just used (e.g. a persisted session
    // restoring on load). A linked account could carry both provider
    // entries; Google is checked first since that's the adapter's
    // original/primary flow.
    const usesGoogle = fbUser.providerData.some((p) => p.providerId === 'google.com');
    return usesGoogle ? 'google' : 'email';
  }

  function toAuthUser(fbUser: import('firebase/auth').User, provider?: AuthUser['provider']): AuthUser {
    return {
      id: fbUser.uid,
      email: fbUser.email || '',
      displayName: fbUser.displayName || undefined,
      provider: provider ?? detectProvider(fbUser)
    };
  }

  // Lazily loads the Firebase SDK (so it's never fetched/evaluated unless a
  // config is actually present — see file header) and wires up the auth-
  // state listener exactly once. Every adapter method awaits this first.
  const initPromise = (async () => {
    const { initializeApp } = await import('firebase/app');
    authModule = await import('firebase/auth');

    const app = initializeApp(firebaseConfig);
    auth = authModule.getAuth(app);
    googleProvider = new authModule.GoogleAuthProvider();

    authModule.onAuthStateChanged(auth, (fbUser) => {
      currentUser = fbUser ? toAuthUser(fbUser) : null;
      ready = true;
      notifyAuthStateChanged();
    });
  })();

  return {
    provider: 'google',

    isReady() {
      return ready;
    },

    getCurrentUser() {
      return currentUser;
    },

    async signInWithGoogle() {
      await initPromise;
      if (!auth || !googleProvider || !authModule) {
        throw new Error('Google Sign-In failed to initialize.');
      }
      // Rejects on cancel (user closes the popup) or any other Firebase
      // Auth error — callers (UI) must catch this, not assume success.
      const result = await authModule.signInWithPopup(auth, googleProvider);
      const user = toAuthUser(result.user, 'google');
      currentUser = user;
      return user;
    },

    async signInWithEmail(email: string, password: string) {
      await initPromise;
      if (!auth || !authModule) {
        throw new Error('Email Sign-In failed to initialize.');
      }
      // `password` only ever passes through to this one call — never
      // stored, logged, or retained anywhere in this adapter.
      const result = await authModule.signInWithEmailAndPassword(auth, email, password);
      const user = toAuthUser(result.user, 'email');
      currentUser = user;
      return user;
    },

    async createAccountWithEmail(email: string, password: string) {
      await initPromise;
      if (!auth || !authModule) {
        throw new Error('Account creation failed to initialize.');
      }
      const result = await authModule.createUserWithEmailAndPassword(auth, email, password);
      const user = toAuthUser(result.user, 'email');
      currentUser = user;
      return user;
    },

    async signOut() {
      await initPromise;
      if (!auth || !authModule) return;
      await authModule.signOut(auth);
      currentUser = null;
    }
  };
}
