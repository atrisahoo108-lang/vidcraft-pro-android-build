// -----------------------------------------------------------------------
// VidCraft Pro — Premium feature definitions
// -----------------------------------------------------------------------
// A single, simple catalog of which non-critical features are FREE vs
// PRO. This file only ANSWERS "is this feature available right now?" —
// it renders nothing and has no opinion on how a caller reacts to the
// answer (that's left entirely to whichever UI uses it).
//
// All gating decisions are driven by the existing license system
// (utils/license.ts / isProUser()) — this file adds no new licensing
// logic of its own, just a lookup table over feature ids on top of it.
//
// Deliberately excluded from this catalog, on purpose: import, basic
// timeline editing (split/trim/ripple/delete/move), normal preview,
// basic audio/video playback, and basic export. Those must always work
// regardless of license and should never be looked up here.

import { isProUser } from './license';

export type FeatureTier = 'FREE' | 'PRO';

export interface PremiumFeatureDefinition {
  id: string;
  name: string;
  tier: FeatureTier;
  /** One line describing the feature — handy if a future UI wants to explain what unlocking it gets you. */
  description?: string;
}

// A small, hand-picked set of non-critical creative extras. Only
// 'cinematic-luts' is actually wired to a gate in this pass (see
// LumetriColorPanel.tsx) — the rest are cataloged here, ready for a future
// pass to wire up, without needing to touch this file again.
export const PREMIUM_FEATURES: Record<string, PremiumFeatureDefinition> = {
  'cinematic-luts': {
    id: 'cinematic-luts',
    name: 'Cinematic LUT Looks',
    tier: 'PRO',
    description: 'One-click cinematic color look presets.'
  },
  'karaoke-captions': {
    id: 'karaoke-captions',
    name: 'Karaoke-Style Word Captions',
    tier: 'PRO',
    description: 'Word-by-word animated caption styling.'
  },
  '4k-export': {
    id: '4k-export',
    name: '4K Export Resolution',
    tier: 'PRO',
    description: 'Export masters at 3840×2160.'
  }
};

/** Shown wherever a PRO feature is unavailable — centralized so the wording never drifts between locations. */
export const PRO_LOCK_MESSAGE = 'This feature is available in VidCraft Pro.';

/**
 * Whether `featureId` is classified as PRO-only. An id that isn't in the
 * catalog is treated as FREE (fail-open) — a typo or a not-yet-classified
 * feature should never accidentally lock something out from under a user.
 */
export function isFeaturePro(featureId: string): boolean {
  return PREMIUM_FEATURES[featureId]?.tier === 'PRO';
}

/**
 * Whether the feature can be used right now. FREE features are always
 * usable; PRO features defer entirely to isProUser() — which already
 * accounts for the dev/test override and a real production license, so
 * this function adds no licensing logic of its own.
 */
export function canUseFeature(featureId: string): boolean {
  if (!isFeaturePro(featureId)) return true;
  return isProUser();
}
