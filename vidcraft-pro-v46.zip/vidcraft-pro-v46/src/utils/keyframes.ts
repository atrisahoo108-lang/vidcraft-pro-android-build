import { Clip, Keyframe } from '../types';

/**
 * Linearly interpolates an animatable clip property from its keyframe track.
 * - Before the first keyframe: holds the first keyframe's value.
 * - After the last keyframe: holds the last keyframe's value.
 * - Between two keyframes: linear ease between them.
 * - No keyframes for this property: returns `fallback` (the clip's static value).
 */
export function getKeyframedValue(
  clip: Pick<Clip, 'keyframes'>,
  property: Keyframe['property'],
  timeFromStart: number,
  fallback: number
): number {
  const track = clip.keyframes?.filter(k => k.property === property);
  if (!track || track.length === 0) return fallback;

  const sorted = [...track].sort((a, b) => a.time - b.time);
  if (timeFromStart <= sorted[0].time) return sorted[0].value;
  const last = sorted[sorted.length - 1];
  if (timeFromStart >= last.time) return last.value;

  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i];
    const b = sorted[i + 1];
    if (timeFromStart >= a.time && timeFromStart <= b.time) {
      const span = b.time - a.time;
      const t = span > 0 ? (timeFromStart - a.time) / span : 0;
      return a.value + (b.value - a.value) * t;
    }
  }
  return fallback;
}

/** Convenience bundle of every animatable transform property for a given instant. */
export function getKeyframedTransform(clip: Clip, timeFromStart: number) {
  return {
    positionX: getKeyframedValue(clip, 'positionX', timeFromStart, clip.positionX),
    positionY: getKeyframedValue(clip, 'positionY', timeFromStart, clip.positionY),
    scale: getKeyframedValue(clip, 'scale', timeFromStart, clip.scale),
    rotation: getKeyframedValue(clip, 'rotation', timeFromStart, clip.rotation),
    opacity: getKeyframedValue(clip, 'opacity', timeFromStart, clip.opacity),
  };
}

/**
 * The instantaneous playback speed at `timeFromStart` — either the clip's
 * static `speed` (default 1), or the keyframed value if a 'speed' track
 * exists (holding at the first/last keyframe's value outside its range).
 */
export function getInstantaneousSpeed(clip: Clip, timeFromStart: number): number {
  return getKeyframedValue(clip, 'speed', timeFromStart, clip.speed ?? 1);
}

/**
 * How far into the SOURCE media we should be at `timeFromStart` timeline-
 * seconds into the clip, accounting for a (possibly time-varying) speed.
 * At constant speed this is just `timeFromStart * speed`. With a keyframed
 * speed ramp, it's the exact integral of the piecewise-linear speed curve —
 * so a dip to slow-mo and back doesn't leave the source position drifting
 * out of sync with a naive instantaneous multiply.
 */
export function getSpeedAdjustedSourceOffset(clip: Clip, timeFromStart: number): number {
  const staticSpeed = clip.speed ?? 1;
  const track = clip.keyframes?.filter(k => k.property === 'speed');
  if (!track || track.length === 0) {
    return timeFromStart * staticSpeed;
  }

  const sorted = [...track].sort((a, b) => a.time - b.time);

  if (timeFromStart <= sorted[0].time) {
    return timeFromStart * sorted[0].value;
  }

  // Held flat from 0 up to the first keyframe.
  let elapsedSource = sorted[0].time * sorted[0].value;

  for (let i = 0; i < sorted.length - 1; i++) {
    const a = sorted[i];
    const b = sorted[i + 1];
    if (timeFromStart >= b.time) {
      // Full segment — trapezoidal rule (exact for a linear ramp).
      elapsedSource += ((a.value + b.value) / 2) * (b.time - a.time);
    } else if (timeFromStart > a.time) {
      // Partial segment — analytic integral of the linear interpolation
      // from a.value to b.value over the fraction f we've covered.
      const segDur = b.time - a.time;
      const f = segDur > 0 ? (timeFromStart - a.time) / segDur : 0;
      elapsedSource += segDur * (a.value * f + ((b.value - a.value) * f * f) / 2);
      return elapsedSource;
    }
  }

  // Past the last keyframe — held flat at its value.
  const last = sorted[sorted.length - 1];
  if (timeFromStart > last.time) {
    elapsedSource += (timeFromStart - last.time) * last.value;
  }
  return elapsedSource;
}

const clamp01 = (v: number): number => Math.max(0, Math.min(1, v));
// Equal-power curve (constant perceived loudness through a crossfade) —
// standard for audio fades, and barely more code than a linear ramp.
const equalPower = (progress01: number): number => Math.sin(clamp01(progress01) * (Math.PI / 2));

/**
 * Effective fade-in/fade-out duration (seconds, clip-local) for `clip`,
 * combining its own explicit `audioConfig.fadeIn`/`fadeOut` with an
 * automatic crossfade wherever it overlaps another clip on the same track
 * (`sameTrackClips` should be every clip on `clip.trackId`, including
 * `clip` itself — it's filtered out below).
 *
 * Pulled out as its own function so both the real-time playback path
 * (`getClipAudioFadeMultiplier` below) and the offline WAV export mixer
 * (`ExportModal.exportWav`) compute the exact same fade window instead of
 * two copies of the overlap-detection math drifting apart.
 */
export function getEffectiveClipFadeSeconds(
  clip: Clip,
  sameTrackClips: Clip[]
): { fadeIn: number; fadeOut: number } {
  const clipStart = clip.startTime;
  const clipEnd = clip.startTime + clip.duration;

  let autoFadeIn = 0;
  let autoFadeOut = 0;
  for (const other of sameTrackClips) {
    if (other.id === clip.id) continue;
    const otherStart = other.startTime;
    const otherEnd = other.startTime + other.duration;

    // `other` starts before `clip` and is still playing when `clip` starts
    // → the overlap at clip's head is an automatic crossfade-in.
    if (otherStart < clipStart && otherEnd > clipStart) {
      autoFadeIn = Math.max(autoFadeIn, otherEnd - clipStart);
    }
    // `other` starts before `clip` ends, but at/after `clip` starts
    // → the overlap at clip's tail is an automatic crossfade-out.
    if (otherStart >= clipStart && otherStart < clipEnd) {
      autoFadeOut = Math.max(autoFadeOut, clipEnd - otherStart);
    }
  }

  let fadeIn = Math.max(clip.audioConfig?.fadeIn ?? 0, autoFadeIn);
  let fadeOut = Math.max(clip.audioConfig?.fadeOut ?? 0, autoFadeOut);

  // A very short clip (or two heavily overlapping ones) could ask for more
  // fade than the clip has room for — scale both down proportionally rather
  // than let them overshoot past the clip's midpoint.
  const total = fadeIn + fadeOut;
  if (total > clip.duration && total > 0) {
    const scale = clip.duration / total;
    fadeIn *= scale;
    fadeOut *= scale;
  }

  return { fadeIn, fadeOut };
}

/**
 * Per-clip audio fade-in/fade-out multiplier (0..1) at `timeFromStart`
 * seconds into `clip`. Multiply this into a clip's volume the same way
 * `getKeyframedValue(..., 'volume', ...)` already is — it's another
 * independent multiplier on top, not a replacement for volume/keyframes.
 */
export function getClipAudioFadeMultiplier(
  clip: Clip,
  timeFromStart: number,
  sameTrackClips: Clip[]
): number {
  const { fadeIn, fadeOut } = getEffectiveClipFadeSeconds(clip, sameTrackClips);
  const remaining = clip.duration - timeFromStart;
  const inMul = fadeIn > 0 ? equalPower(timeFromStart / fadeIn) : 1;
  const outMul = fadeOut > 0 ? equalPower(remaining / fadeOut) : 1;
  return inMul * outMul;
}
