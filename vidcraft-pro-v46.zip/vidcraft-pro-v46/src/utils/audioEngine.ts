import { Track, Clip, MediaAsset } from '../types';
import { getKeyframedValue, getInstantaneousSpeed, getSpeedAdjustedSourceOffset, getClipAudioFadeMultiplier } from './keyframes';

class AudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private trackGains: Map<string, GainNode> = new Map();
  private audioElements: Map<string, HTMLAudioElement> = new Map();
  private sourceNodes: Map<string, MediaElementAudioSourceNode> = new Map();
  private peakLeft: number = 0;
  private peakRight: number = 0;

  public init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
        this.masterGain = this.ctx.createGain();
        this.analyser = this.ctx.createAnalyser();
        this.analyser.fftSize = 128;
        this.masterGain.connect(this.analyser);
        this.analyser.connect(this.ctx.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public getContext(): AudioContext | null {
    this.init();
    return this.ctx;
  }

  public getMasterDestination(): AudioNode | null {
    this.init();
    return this.masterGain;
  }

  public setMasterVolume(val: number) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(Math.max(0, Math.min(2, val)), this.ctx.currentTime);
    }
  }

  public updateTrackGain(trackId: string, volume: number, isMuted: boolean) {
    this.init();
    if (!this.ctx || !this.masterGain) return;

    let gainNode = this.trackGains.get(trackId);
    if (!gainNode) {
      gainNode = this.ctx.createGain();
      gainNode.connect(this.masterGain);
      this.trackGains.set(trackId, gainNode);
    }

    const effectiveVolume = isMuted ? 0 : volume;
    gainNode.gain.setValueAtTime(effectiveVolume, this.ctx.currentTime);
  }

  public getMeterLevels(): { left: number; right: number } {
    if (!this.analyser) {
      return { left: 0, right: 0 };
    }
    const bufferLength = this.analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    this.analyser.getByteFrequencyData(dataArray);

    let sum = 0;
    for (let i = 0; i < bufferLength; i++) {
      sum += dataArray[i];
    }
    const average = sum / bufferLength;
    const normalized = Math.min(100, Math.round((average / 255) * 100));

    // Smooth falloff
    this.peakLeft = Math.max(normalized * 1.05, this.peakLeft * 0.92);
    this.peakRight = Math.max(normalized * 0.95, this.peakRight * 0.92);

    return {
      left: Math.round(Math.min(100, this.peakLeft)),
      right: Math.round(Math.min(100, this.peakRight))
    };
  }

  public playClipAudio(clip: Clip, asset: MediaAsset, currentTime: number, isPlaying: boolean, tracks: Track[], allClips: Clip[] = []) {
    this.init();
    if (!this.ctx || !asset.src) return;

    const track = tracks.find(t => t.id === clip.trackId);
    const isTrackMuted = track ? track.isMuted : false;
    const trackVolume = track ? track.volume : 1;

    let audioEl = this.audioElements.get(clip.id);
    if (!audioEl) {
      audioEl = new Audio(asset.src);
      audioEl.crossOrigin = 'anonymous';
      audioEl.preload = 'auto';
      this.audioElements.set(clip.id, audioEl);

      try {
        if (this.ctx && this.masterGain) {
          let trackGain = this.trackGains.get(clip.trackId);
          if (!trackGain) {
            trackGain = this.ctx.createGain();
            trackGain.connect(this.masterGain);
            this.trackGains.set(clip.trackId, trackGain);
          }
          const source = this.ctx.createMediaElementSource(audioEl);
          source.connect(trackGain);
          this.sourceNodes.set(clip.id, source);
        }
      } catch {
        // Fallback for browsers with strict media element restrictions
      }
    }

    const clipStart = clip.startTime;
    const clipEnd = clip.startTime + clip.duration;
    const isInsideClip = currentTime >= clipStart && currentTime < clipEnd;

    if (isInsideClip && isPlaying) {
      const timeFromStart = currentTime - clipStart;
      const staticVolume = clip.audioConfig?.volume ?? 1;
      // Volume keyframes (e.g. a fade set via "Add Keyframe" on the Volume slider) animate over the clip.
      const keyframedVolume = getKeyframedValue(clip, 'volume', timeFromStart, staticVolume);
      // Fade in/out (explicit audioConfig.fadeIn/fadeOut, and automatic
      // crossfade wherever this clip overlaps another on the same track) —
      // an independent multiplier on top of volume/keyframes, not a
      // replacement for them. Restricted to audio/video clips: a text or
      // image clip can share a video track with this one, but has no audio
      // of its own, so it shouldn't be treated as a crossfade partner.
      const sameTrackClips = allClips.length > 0
        ? allClips.filter(c => c.trackId === clip.trackId && (c.type === 'audio' || c.type === 'video'))
        : [clip];
      const fadeMultiplier = getClipAudioFadeMultiplier(clip, timeFromStart, sameTrackClips);
      const isFrozen = !!clip.freezeFrame;
      // A frozen frame has no matching moment of audio to play — mute
      // rather than loop/stick on one sample, which would be jarring.
      const effectiveVol = (isFrozen || clip.audioConfig?.mute || isTrackMuted) ? 0 : keyframedVolume * trackVolume * fadeMultiplier;
      audioEl.volume = Math.max(0, Math.min(1, effectiveVol));

      if (isFrozen) {
        if (!audioEl.paused) audioEl.pause();
        return;
      }

      const maxOffset = Math.max(0, clip.sourceDuration - 0.05);
      const clipOffset = Math.max(0, Math.min(maxOffset, clip.inPoint + getSpeedAdjustedSourceOffset(clip, timeFromStart)));
      const speed = getInstantaneousSpeed(clip, timeFromStart);

      if (Math.abs(audioEl.currentTime - clipOffset) > 0.25) {
        audioEl.currentTime = clipOffset;
      }
      audioEl.playbackRate = Math.max(0.1, Math.min(4, speed));
      if (audioEl.paused) {
        audioEl.play().catch(() => {});
      }
    } else {
      if (!audioEl.paused) {
        audioEl.pause();
      }
    }
  }

  public stopAll() {
    this.audioElements.forEach((el) => {
      if (!el.paused) {
        el.pause();
      }
    });
  }

  public seekAll(currentTime: number, clips: Clip[]) {
    clips.forEach(clip => {
      const el = this.audioElements.get(clip.id);
      if (el) {
        const clipStart = clip.startTime;
        const clipEnd = clip.startTime + clip.duration;
        if (currentTime >= clipStart && currentTime < clipEnd) {
          el.currentTime = currentTime - clipStart + clip.inPoint;
        } else {
          el.pause();
        }
      }
    });
  }

  /**
   * Releases the cached <audio> element and Web Audio source node for one
   * clip (keyed by clip id, matching how playClipAudio caches them). Safe to
   * call for a clip id that was never cached — it's just a no-op then.
   *
   * Mirrors VideoCompositor.disposeAsset()'s shape/naming for consistency,
   * but this one is scoped per-clip rather than per-asset: audio elements
   * here are cached by clip id, not asset id (splitting/duplicating a clip
   * currently creates its own separate decoded element even when it shares
   * a source file with another clip — see the "Discovered but Not Changed"
   * note in this step's report; that's a bigger change than this pass).
   */
  public disposeClip(clipId: string) {
    const audioEl = this.audioElements.get(clipId);
    if (audioEl) {
      if (!audioEl.paused) audioEl.pause();
      // Clearing src + calling load() is what actually releases the
      // decoded-media resources in the browser — just dropping the JS
      // reference isn't enough while the element is still attached to a
      // MediaElementAudioSourceNode.
      audioEl.removeAttribute('src');
      audioEl.load();
      this.audioElements.delete(clipId);
    }

    const source = this.sourceNodes.get(clipId);
    if (source) {
      try { source.disconnect(); } catch { /* already disconnected */ }
      this.sourceNodes.delete(clipId);
    }
  }

  /**
   * Call whenever the set of clip ids actually in the project changes
   * (a clip is deleted, a project is closed/switched, etc.) — releases
   * every cached audio resource for a clip id that's no longer present.
   * Deliberately NOT called from anywhere yet in this pass (Part 1 only
   * adds the mechanism); wiring it into the app is the recommended next
   * step, the same way VideoCompositor.pruneUnusedAssets() was added and
   * wired in two separate, reviewable steps.
   */
  public pruneUnusedClips(activeClipIds: Set<string>) {
    this.audioElements.forEach((_el, clipId) => {
      if (!activeClipIds.has(clipId)) {
        this.disposeClip(clipId);
      }
    });
  }

  /**
   * Releases a track's gain node once the track itself no longer exists.
   * Trivial by design — trackGains legitimately persist for as long as the
   * track does (every clip on that track shares one gain node), so this is
   * separate from per-clip cleanup and should only be called when a track
   * is actually deleted, not on ordinary clip edits.
   */
  public disposeTrack(trackId: string) {
    const gain = this.trackGains.get(trackId);
    if (gain) {
      try { gain.disconnect(); } catch { /* already disconnected */ }
      this.trackGains.delete(trackId);
    }
  }
}

export const audioEngine = new AudioEngine();
