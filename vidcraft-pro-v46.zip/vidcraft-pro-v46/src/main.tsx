import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
// Side-effect only: registers the Google Sign-In adapter with auth.ts if
// (and only if) Firebase is configured via env vars — see
// utils/googleAuthAdapter.ts and utils/firebaseConfig.ts. Does nothing
// otherwise. No other file needs to know this import exists.
import './utils/googleAuthAdapter';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
