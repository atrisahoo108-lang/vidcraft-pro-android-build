// -----------------------------------------------------------------------
// VidCraft Pro — Authentication provider boundary
// -----------------------------------------------------------------------
// A real provider IS wired in: googleAuthAdapter.ts implements this file's
// `AuthAdapter` interface using Firebase Authentication (Google Sign-In,
// Email/Password sign-in, and email/password account creation), and
// registers itself via `registerAuthAdapter` — see main.tsx's side-effect
// import. That registration only happens if Firebase is configured (see
// firebaseConfig.ts); with no configuration, nothing in this file makes a
// network request and `getAuthState()` safely reports "not configured"
// (`providerConfigured: false`) rather than throwing.
//
// This file itself still contains no Firebase-specific code and makes no
// network request directly — it's the provider-neutral boundary UI talks
// to (`getAuthState`, `signInWithGoogle`, `signInWithEmail`,
// `createAccountWithEmail`, `signOut`, `subscribeToAuthState`), so a
// different or additional provider could register here later without any
// UI code changing.
//
// IMPORTANT — SEPARATION OF CONCERNS:
// Authentication and licensing (see license.ts) are two completely
// separate systems on purpose. Being "signed in" here says nothing about
// whether isProUser() is true. This file does not import from license.ts
// or premiumFeatures.ts, and never will by accident — there is simply no
// code path here that touches PRO access.

export type AuthProvider = 'google' | 'email' | 'test';

export interface AuthUser {
  id: string;
  email: string;
  displayName?: string;
  provider: AuthProvider;
}

export type AuthStatus = 'authenticated' | 'unauthenticated' | 'loading';

export interface AuthState {
  status: AuthStatus;
  user: AuthUser | null;
  /** False whenever no real provider is registered. Also currently false
   *  while a test override is active, even if a real provider happens to
   *  be registered too — test auth and a registered provider's
   *  "configured" reporting aren't combined (see getAuthState()). Lets a
   *  UI show "Not configured" instead of a misleading plain "Signed out"
   *  when there's genuinely no real provider available. */
  providerConfigured: boolean;
}

/**
 * The boundary a real provider implements — googleAuthAdapter.ts does this
 * today, backed by Firebase Authentication, covering both Google Sign-In
 * and email/password. `signInWithGoogle`/`signInWithEmail` are optional
 * because a given adapter may only support one method.
 */
export interface AuthAdapter {
  readonly provider: AuthProvider;
  signInWithGoogle?(): Promise<AuthUser>;
  signInWithEmail?(email: string, password: string): Promise<AuthUser>;
  /** Creates a new account via email/password (Firebase's "sign up"). Optional — an adapter that only supports Google can omit this. */
  createAccountWithEmail?(email: string, password: string): Promise<AuthUser>;
  signOut(): Promise<void> | void;
  getCurrentUser(): AuthUser | null;
  /**
   * Optional. Returns false while a real provider is still resolving its
   * initial session (e.g. Firebase restoring a persisted sign-in from
   * IndexedDB — that happens asynchronously, so `getCurrentUser()` can be a
   * false "null" for a moment even for an already-signed-in user). Omit
   * this for an adapter that's always synchronously ready (e.g. `test`).
   */
  isReady?(): boolean;
}

// googleAuthAdapter.ts registers itself here at startup (via main.tsx's
// side-effect import) if Firebase is configured; otherwise this stays null
// and every function below falls back to its safe "not configured" behavior.
let productionAdapter: AuthAdapter | null = null;

/** Lets a real provider plug in without this file's public API changing again. */
export function registerAuthAdapter(adapter: AuthAdapter | null): void {
  productionAdapter = adapter;
  notifyListeners();
}

// -----------------------------------------------------------------------
// TEST/DEV auth override
// -----------------------------------------------------------------------
// Simulates a signed-in user for local development only. Stored under its
// own key, entirely separate from any future production auth session and
// from every license.ts storage key. No password or credential of any
// kind is ever accepted or stored here — just an id/email/displayName the
// developer chooses.

const TEST_AUTH_KEY = 'vidcraft:testAuthUser';

function isValidTestUser(value: unknown): value is AuthUser {
  if (!value || typeof value !== 'object') return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.id === 'string' &&
    typeof v.email === 'string' &&
    (v.displayName === undefined || typeof v.displayName === 'string') &&
    v.provider === 'test'
  );
}

function readTestAuthUser(): AuthUser | null {
  try {
    const raw = window.localStorage.getItem(TEST_AUTH_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return isValidTestUser(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/**
 * TEMPORARY DEV/TEST SWITCH — not real authentication (see section header
 * above). Pass `null` to clear it. This intentionally does NOT grant PRO
 * access by itself — licensing is checked separately via license.ts.
 */
export function setTestAuthUser(user: { id: string; email: string; displayName?: string } | null): void {
  try {
    if (user === null) {
      window.localStorage.removeItem(TEST_AUTH_KEY);
    } else {
      const testUser: AuthUser = {
        id: user.id,
        email: user.email,
        displayName: user.displayName,
        provider: 'test'
      };
      window.localStorage.setItem(TEST_AUTH_KEY, JSON.stringify(testUser));
    }
  } catch {
    // localStorage unavailable (private browsing, etc.) — nothing to
    // persist to; the override just won't survive a reload.
  }
  notifyListeners();
}

// -----------------------------------------------------------------------
// Public, provider-neutral API — this is what the rest of the app (and a
// future settings/account UI) should call. Never performs a network
// request and never throws merely because no provider is configured.
// -----------------------------------------------------------------------

/** Full current auth picture: status, user (if any), and whether a real provider is even configured. */
export function getAuthState(): AuthState {
  const testUser = readTestAuthUser();
  if (testUser) {
    return { status: 'authenticated', user: testUser, providerConfigured: false };
  }

  if (productionAdapter) {
    if (productionAdapter.isReady && !productionAdapter.isReady()) {
      // Configured, but still resolving its initial session (e.g. Firebase
      // restoring persisted auth) — deliberately distinct from
      // "unauthenticated" so the UI doesn't flash "signed out" first.
      return { status: 'loading', user: null, providerConfigured: true };
    }
    const user = productionAdapter.getCurrentUser();
    return { status: user ? 'authenticated' : 'unauthenticated', user, providerConfigured: true };
  }

  // No test override and no real provider registered — safely
  // unauthenticated. Never an error, never a fabricated user.
  return { status: 'unauthenticated', user: null, providerConfigured: false };
}

export function getCurrentUser(): AuthUser | null {
  return getAuthState().user;
}

export function isAuthenticated(): boolean {
  return getAuthState().status === 'authenticated';
}

// -----------------------------------------------------------------------
// Reactivity — a registered provider's own state can change asynchronously
// (a Firebase popup resolving, a session restoring on load), so UI must be
// able to subscribe rather than only read getAuthState() once.
// -----------------------------------------------------------------------

type AuthStateListener = (state: AuthState) => void;
const listeners = new Set<AuthStateListener>();

function notifyListeners(): void {
  const state = getAuthState();
  listeners.forEach(listener => listener(state));
}

/**
 * Subscribe to auth state changes — test override changes, a real
 * provider registering, or that provider's own async state changing.
 * Returns an unsubscribe function; call it from a UI component's effect
 * cleanup. Fires immediately is NOT guaranteed — read getAuthState() for
 * the initial value, then subscribe for updates.
 */
export function subscribeToAuthState(listener: AuthStateListener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/**
 * Called by a registered real provider whenever ITS underlying auth state
 * changes on its own (e.g. Firebase's onAuthStateChanged firing after a
 * popup completes, or a session restoring from persistence). Not meant to
 * be called from UI — UI should call subscribeToAuthState instead.
 */
export function notifyAuthStateChanged(): void {
  notifyListeners();
}

/**
 * Signs in via the registered provider's Google flow. Throws if no
 * provider is configured, or if the registered provider doesn't support
 * Google Sign-In — callers (UI) must catch this rather than assume it
 * always resolves (the user can also simply cancel the popup, which
 * rejects the same way).
 */
export async function signInWithGoogle(): Promise<AuthUser> {
  if (!productionAdapter || !productionAdapter.signInWithGoogle) {
    throw new Error('Google Sign-In is not configured.');
  }
  const user = await productionAdapter.signInWithGoogle();
  notifyListeners();
  return user;
}

/**
 * Signs in via the registered provider's email/password flow. Throws if
 * no provider is configured, or if the registered provider doesn't
 * support it — mirrors signInWithGoogle() above exactly. `password` is
 * only ever forwarded to the adapter's own call; this function does not
 * store, log, or retain it.
 */
export async function signInWithEmail(email: string, password: string): Promise<AuthUser> {
  if (!productionAdapter || !productionAdapter.signInWithEmail) {
    throw new Error('Email Sign-In is not configured.');
  }
  const user = await productionAdapter.signInWithEmail(email, password);
  notifyListeners();
  return user;
}

/**
 * Creates a new account via the registered provider's email/password
 * flow (Firebase's "sign up"). Same shape and guarantees as
 * signInWithEmail() above — `password` is only ever forwarded to the
 * adapter's own call.
 */
export async function createAccountWithEmail(email: string, password: string): Promise<AuthUser> {
  if (!productionAdapter || !productionAdapter.createAccountWithEmail) {
    throw new Error('Account creation is not configured.');
  }
  const user = await productionAdapter.createAccountWithEmail(email, password);
  notifyListeners();
  return user;
}

/**
 * Signs out of test auth (if active) and the registered real provider (if
 * any). Returns a Promise so callers can await the FINAL signed-out state
 * and react to a failure — previously this fired the registered adapter's
 * `signOut()` without awaiting it (a fire-and-forget call on a function
 * that returns `Promise<void> | void`), then notified listeners
 * immediately, before the real (possibly async, e.g. Firebase) sign-out
 * had actually completed. That meant: (a) listeners could be notified with
 * a stale "still authenticated" state right after sign-out was requested,
 * and (b) if the adapter's sign-out rejected, that rejection was an
 * unhandled promise rejection the caller had no way to observe — the
 * function's `void` return type made it impossible to even await in the
 * first place.
 *
 * Test-auth clearing always happens first and can't fail in a way that
 * should block anything else. The real provider's sign-out is awaited
 * inside a try/catch that can actually catch a rejection (only possible
 * now that this function is itself `async`); listeners are notified
 * afterwards either way, from `getAuthState()`'s live read of the
 * adapter — so on success that reports the real unauthenticated state, and
 * on failure it reports whatever the adapter's `getCurrentUser()` still
 * says (unchanged, since a rejected Firebase signOut never reaches the
 * `currentUser = null` line in googleAuthAdapter.ts) rather than a falsely
 * finalized "signed out". The error is then re-thrown so a caller that
 * does await this can surface it; a caller that doesn't await it behaves
 * exactly as before.
 */
export async function signOut(): Promise<void> {
  setTestAuthUser(null);
  try {
    await productionAdapter?.signOut();
    notifyListeners();
  } catch (err) {
    // Notify regardless — this just re-reads the current true state, it
    // does not claim any particular outcome, so it's safe to call even
    // though the provider's sign-out failed.
    notifyListeners();
    throw err instanceof Error ? err : new Error('Sign-out failed.');
  }
}
