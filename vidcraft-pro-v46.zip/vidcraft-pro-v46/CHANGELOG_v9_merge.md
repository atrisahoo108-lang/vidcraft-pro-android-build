# v8 → v9 baseline — Merging the "undo/redo + project save" branch into v8

You had two branches going (one chat hit its message limit, so this work continued
in a separate chat as `v7-undo-redo-project-save.zip`, while another chat kept
building forward and produced `v8.zip` with text-animation/masking/speed-ramp).
This pass reconciles them into one codebase — nothing from either branch was
discarded.

## What was actually done (not just trusted from labels)
Extracted both zips and diffed every shared file line-by-line before touching
anything, specifically to find cases where **both** branches had changed the
same file (which would need a real manual merge) versus cases where one
branch was a clean superset of the other (safe to take wholesale). Result:

- `videoCompositor.ts`, `EffectControls.tsx`, `EssentialGraphicsPanel.tsx`,
  `audioEngine.ts`, `keyframes.ts` — **v8 was already a strict superset** of
  v7's changes here (masking, speed ramps, freeze frame, karaoke captions,
  mirrored exit animations). Kept as-is, untouched.
- `HeaderMenuBar.tsx`, `Timeline.tsx`, `ProjectMediaBin.tsx` — **v7 was the
  superset** (File/Save menu, save-status indicator, `onBeginClipEdit` drag-
  coalescing hook, offline-relink UI). Took v7's versions.
- `history.ts`, `projectStorage.ts` — new files, only existed in the v7
  branch. Added as-is.
- `App.tsx` — the one file both branches had genuinely diverged on. Rebuilt
  it from the v7 (history/project-save) version, then manually re-applied the
  one v8-only piece of logic it was missing: `handleAddKeyframe` needs a
  `speed` case (`clip.speed ?? 1`) alongside the existing `volume`/generic
  cases, or adding a keyframe on the Speed slider would have stored
  `undefined` instead of a real number.
- `types.ts` — merged: kept all of v8's additions (`ClipMask`, `speed`,
  `freezeFrame`, `captionWords`, the extended animation/transition unions)
  and added back v7's `MediaAsset.isLocalFile` / `isOfflineMissing` fields
  that the project-save system depends on.
- `package.json` — kept v8's Capacitor dependencies, added back v7's
  `@types/react` / `@types/react-dom` (harmless, just better editor/type
  support).

## Bug found and fixed during the merge
`HeaderMenuBar.tsx` in v8 had `onClick={() => setWorkspace('AI Magic')}` on
the "AI Co-Pilot" quick-access button — `'AI Magic'` isn't a valid workspace
id (the real one is `'ai-tools'`), so that button either silently did nothing
or would have failed `tsc` once type-checked. v7's version already had the
correct `setWorkspace('ai-tools')`, which is what the merged file now uses.

## Net result — what the merged app now has, all together
- Undo/redo across the whole document (project settings + tracks + clips),
  not just clips — with drag/slider gestures coalesced into one undo step
  instead of one step per pixel.
- Offline project persistence via IndexedDB (auto-save, Save/Save As, Open
  Recent Project, restore-last-session prompt) — works with zero internet.
- Real filters/keyframes/transitions (v6), text/title kinetic animation +
  karaoke captions + shape masking (v7-text-anim), speed ramping + freeze
  frame (v8), real MP4/WebM/WAV export with real audio (v8 export fix),
  touch/mobile layout, Capacitor scaffolding, and the VidCraft Pro rename —
  all present together in one file tree.

## Not yet verified by a real build
No internet in this sandbox → no `npm install`. Everything here was checked
by: (1) diffing every file byte-for-byte before merging so nothing silently
overwrote the other branch's work, (2) an isolated `tsc --noEmit` run against
every pure-logic file (`types.ts`, `history.ts`, `projectStorage.ts`,
`keyframes.ts`, `audioEngine.ts`, `videoCompositor.ts`) with zero errors, and
(3) a prop-contract cross-check confirming every prop each component expects
is exactly what `App.tsx` passes it (no missing/extra props on
`HeaderMenuBar`, `Timeline`, `ProjectMediaBin`, `EffectControls`). Please
still run `npm install && npm run lint && npm run dev` locally and click
through Save/Open/Undo/Redo once before you consider this final — a full
`tsc` pass with real `node_modules` can catch things an isolated check can't.
