// -----------------------------------------------------------------------
// VidCraft Pro — Payment provider boundary (architecture only, v42)
// -----------------------------------------------------------------------
// Mirrors auth.ts's shape on purpose: a provider-neutral boundary
// (`PaymentAdapter`, registered via `registerPaymentAdapter`) that a real
// provider (Razorpay) implements later, so payment-provider-specific code
// never scatters through the editor or UI.
//
// NOTHING IN THIS FILE PROCESSES A REAL PAYMENT. There is no Razorpay SDK
// import here, no network call, and no adapter registered by default —
// `registerPaymentAdapter` is never called anywhere in v42. The only
// adapter that exists at all is the Test adapter at the bottom of this
// file, which is explicitly incapable of touching real money and is never
// wired up automatically.
//
// IMPORTANT — WHY THE REAL FLOW NEEDS A BACKEND, NOT JUST THIS FILE:
// A trustworthy payment can't be verified by the browser alone — anyone
// could open devtools and claim a payment succeeded. The real future flow
// (see paymentBackendContract.ts) looks like:
//   1. Frontend asks a backend to create a Razorpay order. The backend
//      holds the Key Secret, calls Razorpay's server API, and returns
//      only an order id + the public Key ID to the frontend.
//   2. Frontend opens Razorpay Checkout with that order id — the only
//      part of the real flow that happens in the browser.
//   3. Frontend forwards the payment id + signature Checkout hands back
//      to the backend.
//   4. Backend verifies that signature against the Key Secret (HMAC) —
//      the ONLY authoritative "did this payment really succeed" check.
//      The frontend's own opinion about step 2's outcome is never
//      trusted by itself.
//   5. Only after that server-side verification would a future step
//      issue a production license — and even then, payment success and
//      PRO status stay two separate systems (see the note below).
// None of steps 1, 3, 4, or 5 exist yet. This file only defines the
// shapes they'll eventually fill in, plus a Test adapter for exercising
// those shapes without any of that existing.
//
// IMPORTANT — SEPARATION FROM LICENSING:
// Exactly like auth.ts, this file does not import license.ts or
// premiumFeatures.ts, and never will by accident. A successful
// PaymentResult here has zero effect on isProUser() — there is simply no
// code path from this file to PRO access. Wiring a verified payment to an
// actual license grant is a deliberate future step, not something that
// falls out of this boundary automatically.

export type PaymentProvider = 'razorpay' | 'test';

export type PaymentStatus = 'pending' | 'success' | 'failed' | 'cancelled';

export interface PaymentOrder {
  /** Provider's order identifier. For a real Razorpay order this comes
   *  from the backend (see paymentBackendContract.ts) — never generated
   *  client-side, since only the backend (holding the Key Secret) can
   *  create an order Razorpay will actually recognize. */
  id: string;
  /** Smallest currency unit (e.g. paise for INR), matching Razorpay's own convention. */
  amount: number;
  currency: string;
  provider: PaymentProvider;
  createdAt: number;
}

export interface PaymentResult {
  orderId: string;
  /** Null until the checkout step actually completes. */
  paymentId: string | null;
  status: PaymentStatus;
  provider: PaymentProvider;
}

export interface CreatePaymentOrderParams {
  amount: number;
  currency: string;
  /** Free-form, provider-agnostic description shown in checkout/receipts. */
  description?: string;
}

/**
 * The boundary a real payment provider implements later (Razorpay is the
 * intended one; another provider could implement this same interface).
 * No adapter implements this for a real payment in v42 — see file header.
 */
export interface PaymentAdapter {
  readonly provider: PaymentProvider;
  /** Asks the (future) backend to create a trusted order. A real adapter
   *  never creates the order client-side — see file header for why. */
  createPaymentOrder(params: CreatePaymentOrderParams): Promise<PaymentOrder>;
  /** Opens the provider's checkout UI for an existing order and resolves
   *  with whatever the checkout step itself reports. NOT authoritative on
   *  its own — see verifyPaymentResult(). */
  openPaymentCheckout(order: PaymentOrder): Promise<PaymentResult>;
  /** Asks the (future) backend to authoritatively verify a checkout
   *  result's signature. This — not openPaymentCheckout()'s return value —
   *  is what a future step should actually trust. */
  verifyPaymentResult(result: PaymentResult): Promise<PaymentStatus>;
}

// No provider registers itself here in v42 — stays null.
let productionAdapter: PaymentAdapter | null = null;

/** Lets a real provider (Razorpay) plug in later without this file's public API changing again. Nothing calls this in v42. */
export function registerPaymentAdapter(adapter: PaymentAdapter | null): void {
  productionAdapter = adapter;
}

export function isPaymentConfigured(): boolean {
  return productionAdapter !== null;
}

export function getActivePaymentProvider(): PaymentProvider | null {
  return productionAdapter?.provider ?? null;
}

// -----------------------------------------------------------------------
// Public, provider-neutral API — mirrors auth.ts's shape. Throws a clear,
// specific error if no adapter is registered rather than silently doing
// nothing; in v42 that's every call, since no adapter is registered by
// default. Callers should treat that the same way they'd treat "payments
// aren't available yet" (there's no UI wired to any of this in v42 — see
// file header — but the functions still behave safely if something calls
// them directly, e.g. from a console or a future test).
// -----------------------------------------------------------------------

export async function createPaymentOrder(params: CreatePaymentOrderParams): Promise<PaymentOrder> {
  if (!productionAdapter) {
    throw new Error('Payment is not configured.');
  }
  return productionAdapter.createPaymentOrder(params);
}

export async function openPaymentCheckout(order: PaymentOrder): Promise<PaymentResult> {
  if (!productionAdapter) {
    throw new Error('Payment is not configured.');
  }
  return productionAdapter.openPaymentCheckout(order);
}

export async function verifyPaymentResult(result: PaymentResult): Promise<PaymentStatus> {
  if (!productionAdapter) {
    throw new Error('Payment is not configured.');
  }
  return productionAdapter.verifyPaymentResult(result);
}

// -----------------------------------------------------------------------
// TEST ADAPTER — architecture testing only. Nothing in the app calls
// registerPaymentAdapter with this; it exists purely so this file's own
// boundary can be exercised end to end (create order -> checkout ->
// verify) without a backend, without Razorpay, and without real money.
// Deliberately incapable of touching real money:
//  - imports or calls nothing Razorpay-related
//  - makes no network request of any kind
//  - resolves deterministically based on the `outcome` you pass in
//  - has zero effect on isProUser() — this file never imports license.ts,
//    so there's no code path that could grant PRO even by accident
// -----------------------------------------------------------------------

/**
 * Builds a Test payment adapter for exercising payment.ts's boundary
 * end-to-end without a backend or real money. `outcome` decides what
 * openPaymentCheckout()/verifyPaymentResult() resolve to, so a test can
 * assert deterministic success/failure/cancellation behavior.
 *
 * TEST ONLY — never register this outside a dev/test context.
 */
export function createTestPaymentAdapter(
  outcome: Extract<PaymentStatus, 'success' | 'failed' | 'cancelled'> = 'success'
): PaymentAdapter {
  return {
    provider: 'test',

    async createPaymentOrder(params) {
      return {
        id: `test-order-${Date.now()}`,
        amount: params.amount,
        currency: params.currency,
        provider: 'test',
        createdAt: Date.now()
      };
    },

    async openPaymentCheckout(order) {
      return {
        orderId: order.id,
        paymentId: outcome === 'success' ? `test-payment-${Date.now()}` : null,
        status: outcome,
        provider: 'test'
      };
    },

    async verifyPaymentResult(result) {
      // A real adapter would ask the backend to check a signature here.
      // The Test adapter just echoes back what openPaymentCheckout()
      // already decided — deterministic, no network call, nothing to verify.
      return result.status;
    }
  };
}
