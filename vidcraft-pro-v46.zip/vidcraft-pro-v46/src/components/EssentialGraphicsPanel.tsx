import React, { useState, useEffect } from 'react';
import { 
  Type, AlignLeft, AlignCenter, AlignRight,
  Plus, Palette, Layers, Box
} from 'lucide-react';
import { Clip, TextConfig } from '../types';
import { TITLE_TEMPLATES } from '../data/sampleMedia';
import { canUseFeature } from '../utils/premiumFeatures';
import { PremiumBadge } from './PremiumBadge';

interface EssentialGraphicsPanelProps {
  selectedClip: Clip | null;
  onUpdateClip: (clipId: string, updates: Partial<Clip>) => void;
  onAddTextClipToTimeline: (textConfig: TextConfig) => void;
  // v44: taller header on mobile; slider/button touch sizing elsewhere in
  // this panel relies on the global (pointer: coarse) rule in index.css.
  // Defaults to false — desktop/web is unchanged.
  isMobile?: boolean;
}

export const EssentialGraphicsPanel: React.FC<EssentialGraphicsPanelProps> = ({
  selectedClip,
  onUpdateClip,
  onAddTextClipToTimeline,
  isMobile = false
}) => {
  const isTextClip = selectedClip?.type === 'text' && selectedClip.textConfig;
  const textConfig: TextConfig = selectedClip?.textConfig || {
    text: 'TITLE TEXT',
    fontSize: 42,
    fontFamily: 'Plus Jakarta Sans',
    color: '#ffffff',
    align: 'center',
    animation: 'none'
  };

  const updateText = (key: keyof TextConfig, value: any) => {
    if (!selectedClip) return;
    onUpdateClip(selectedClip.id, {
      textConfig: {
        ...textConfig,
        [key]: value
      }
    });
  };

  // Karaoke Captions Premium Gate (v33): same small self-clearing local
  // notice pattern already used in LumetriColorPanel.tsx (cinematic-LUT
  // gate) and ExportModal.tsx (4K export gate) — reused here rather than
  // building a new notification system.
  const KARAOKE_LOCK_MESSAGE = 'Karaoke Captions are available in VidCraft Pro.';
  const [lockNotice, setLockNotice] = useState<string | null>(null);
  useEffect(() => {
    if (!lockNotice) return;
    const timer = setTimeout(() => setLockNotice(null), 3500);
    return () => clearTimeout(timer);
  }, [lockNotice]);

  const generateKaraokeCaptions = () => {
    if (!selectedClip) return;
    // Gate only the generation action itself — clearing existing captions
    // (below) stays available regardless of tier, same as every other
    // "remove/undo" action in the app.
    if (!canUseFeature('karaoke-captions')) {
      setLockNotice(KARAOKE_LOCK_MESSAGE);
      return;
    }
    const words = textConfig.text.trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) return;
    const perWord = selectedClip.duration / words.length;
    const captionWords = words.map((w, i) => ({
      text: w,
      start: i * perWord,
      end: (i + 1) * perWord
    }));
    updateText('captionWords', captionWords);
  };

  return (
    <div className="h-full flex flex-col bg-[#16161b] text-zinc-200 text-xs select-none overflow-y-auto">
      {/* Header */}
      <div className={`bg-[#1e1e26] border-b border-[#282834] px-3 flex items-center justify-between ${isMobile ? 'h-11' : 'h-8'}`}>
        <div className="flex items-center space-x-1.5">
          <Type className="w-3.5 h-3.5 text-amber-400" />
          <span className="font-semibold text-zinc-100 text-[11px]">Essential Graphics & Titles</span>
        </div>
      </div>

      <div className="p-3 space-y-4">
        {/* If Text Clip is Selected: Edit Active Properties */}
        {isTextClip ? (
          <div className="space-y-3 bg-[#1a1a22] border border-[#2b2b38] rounded-lg p-3">
            <div className="flex items-center justify-between border-b border-[#292936] pb-1.5">
              <span className="text-[11px] font-semibold text-amber-400">Edit Active Title</span>
              <span className="text-[10px] text-zinc-400">Track: {selectedClip.trackId}</span>
            </div>

            {/* Textarea */}
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Headline Text</label>
              <textarea
                value={textConfig.text}
                onChange={(e) => updateText('text', e.target.value)}
                rows={2}
                className="w-full bg-[#111116] border border-[#2b2b38] rounded p-2 text-zinc-100 text-xs focus:outline-none focus:border-amber-500 resize-none"
              />
            </div>

            {/* Font Family & Size */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Font Family</label>
                <select
                  value={textConfig.fontFamily}
                  onChange={(e) => updateText('fontFamily', e.target.value)}
                  className="w-full bg-[#111116] border border-[#2b2b38] rounded px-2 py-1 text-zinc-200 text-[11px]"
                >
                  <option value="Plus Jakarta Sans">Plus Jakarta Sans</option>
                  <option value="Fira Code">Fira Code (Tech/Mono)</option>
                  <option value="Impact">Impact (Meme/Bold)</option>
                  <option value="Georgia">Georgia (Serif)</option>
                  <option value="Arial">Arial (Clean)</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Font Size ({textConfig.fontSize}px)</label>
                <input
                  type="range"
                  min={16}
                  max={96}
                  value={textConfig.fontSize}
                  onChange={(e) => updateText('fontSize', parseInt(e.target.value))}
                  className="w-full h-1 bg-[#2b2b36] rounded appearance-none cursor-pointer accent-amber-500 mt-2"
                />
              </div>
            </div>

            {/* Alignment & Colors */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Alignment</label>
                <div className="flex bg-[#111116] rounded border border-[#2b2b38] p-0.5">
                  {(['left', 'center', 'right'] as const).map(align => (
                    <button
                      key={align}
                      onClick={() => updateText('align', align)}
                      className={`flex-1 py-1 rounded flex items-center justify-center ${
                        textConfig.align === align ? 'bg-[#2b2b3a] text-amber-400' : 'text-zinc-400'
                      }`}
                    >
                      {align === 'left' && <AlignLeft className="w-3 h-3" />}
                      {align === 'center' && <AlignCenter className="w-3 h-3" />}
                      {align === 'right' && <AlignRight className="w-3 h-3" />}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] text-zinc-400 block mb-1">Fill Color</label>
                <div className="flex items-center space-x-2 bg-[#111116] border border-[#2b2b38] rounded px-2 py-1">
                  <input
                    type="color"
                    value={textConfig.color}
                    onChange={(e) => updateText('color', e.target.value)}
                    className="w-4 h-4 rounded border-0 bg-transparent cursor-pointer"
                  />
                  <span className="font-mono-code text-[10px] text-zinc-300">{textConfig.color}</span>
                </div>
              </div>
            </div>

            {/* Kinetic Animation Preset */}
            <div>
              <label className="text-[10px] text-zinc-400 block mb-1">Kinetic Animation</label>
              <select
                value={textConfig.animation || 'none'}
                onChange={(e) => updateText('animation', e.target.value)}
                className="w-full bg-[#111116] border border-[#2b2b38] rounded px-2 py-1 text-zinc-200 text-[11px] focus:border-amber-500"
              >
                <option value="none">None (Static)</option>
                <option value="fade">Simple Fade In/Out</option>
                <option value="typewriter">Typewriter (Word by Word)</option>
                <option value="bounce">TikTok Pop Bounce</option>
                <option value="slide-up">Cinematic Slide Up</option>
                <option value="slide-down">Slide Down</option>
                <option value="slide-left">Slide In From Right</option>
                <option value="slide-right">Slide In From Left</option>
                <option value="zoom-in">Dynamic Zoom In</option>
                <option value="glitch">Cyberpunk Glitch</option>
              </select>
              <p className="text-[9px] text-zinc-500 mt-1">Every preset now animates both in and out, mirrored near the end of the clip.</p>
            </div>

            {/* Karaoke-style Animated Captions */}
            <div className="border-t border-[#292936] pt-2.5">
              <label className="text-[10px] text-zinc-400 mb-1 flex items-center gap-1.5">
                Karaoke Captions (word-by-word highlight)
                <PremiumBadge />
              </label>
              {textConfig.captionWords && textConfig.captionWords.length > 0 ? (
                <div className="flex items-center justify-between bg-[#111116] border border-emerald-600/40 rounded px-2 py-1.5">
                  <span className="text-[10px] text-emerald-300">
                    {textConfig.captionWords.length} words timed evenly over {selectedClip.duration.toFixed(1)}s
                  </span>
                  <button
                    onClick={() => updateText('captionWords', undefined)}
                    className="text-[10px] text-zinc-400 hover:text-red-400 underline"
                  >
                    Clear
                  </button>
                </div>
              ) : (
                <button
                  onClick={generateKaraokeCaptions}
                  className="w-full px-2 py-1.5 bg-emerald-700/30 hover:bg-emerald-700/50 border border-emerald-600/40 text-emerald-300 rounded text-[10px] font-medium"
                >
                  Auto-Generate from Headline Text
                </button>
              )}
              {lockNotice && (
                <p className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 rounded px-2 py-1.5 mt-1.5">
                  {lockNotice}
                </p>
              )}
              <p className="text-[9px] text-zinc-500 mt-1">
                Splits the headline into words and lights each one up in turn as the clip plays — the
                CapCut/TikTok auto-caption look. Evenly timed for now; edit word timing precisely from
                a future update if you need it synced to exact speech.
              </p>
            </div>
          </div>
        ) : null}

        {/* Built-in Essential Title Templates */}
        <div className="space-y-2">
          <span className="text-[10px] font-semibold text-zinc-400 uppercase tracking-wider block">
            Essential Title Templates
          </span>
          <div className="grid grid-cols-1 gap-2">
            {TITLE_TEMPLATES.map((tpl, i) => (
              <div
                key={i}
                className="bg-[#1b1b22] border border-[#272732] hover:border-sky-500/40 rounded-md p-2.5 transition-all flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-xs text-zinc-100">{tpl.name}</div>
                  <div className="text-[10px] text-zinc-400 mt-0.5">
                    Category: <span className="text-sky-300">{tpl.category}</span>
                  </div>
                </div>

                <button
                  onClick={() => onAddTextClipToTimeline(tpl.textConfig)}
                  className="px-2.5 py-1 bg-sky-600 hover:bg-sky-500 text-white rounded text-[11px] font-medium flex items-center space-x-1"
                >
                  <Plus className="w-3 h-3" />
                  <span>Insert</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
