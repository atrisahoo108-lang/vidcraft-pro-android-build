# VidCraft Pro — v46: Mobile preview + export fix (from real-phone test of v45)

Reported on a phone (10s clip): timeline playback doesn't show video correctly in
the monitor, and export gives a ~1 second black file.

NOT verified on a device here (no Android hardware/SDK/network in this sandbox) —
these are fixes for the most likely causes found by reading the code. Needs your retest.

## src/utils/videoCompositor.ts (touch devices only; desktop path unchanged)
- <video> elements were never attached to the page. On Android WebView/Chrome that
  often means no decoded frames (black/blank). They now live in a hidden 1px host.
- First frame is nudged to decode so a paused/scrubbed clip isn't blank.
- Seek thrash fix: on touch devices it no longer issues a new seek every frame while
  the previous seek is unfinished (this froze playback); drift tolerance 0.45s while
  playing, 0.04s while paused. Desktop keeps 0.2s.
- New helpers: ensureVideoReady(), waitForVideosIdle(). disposeAsset also removes the element.

## src/components/ExportModal.tsx (export logic only; license/watermark/gate UI untouched)
- Preflight before recording: resume audio context (a suspended one can stall the
  recorder), wait for videos to have a frame, park at t=0, paint one frame first.
- Encoder errors are now caught; if the encoder dies or output is tiny, a red error
  message is shown instead of silently offering a junk file.
- Touch devices: bitrate capped by device tier (low 3 / mid 6 Mbps). Desktop unchanged.
- Calls requestFrame() per drawn frame when supported.

## Still open / unknown
- Whether the encoder on your phone can do 1080p in real time (try 720p + Web Compressed).
- Exact preview symptom (black / frozen / stuttering) and whether you ran the APK or a browser.
