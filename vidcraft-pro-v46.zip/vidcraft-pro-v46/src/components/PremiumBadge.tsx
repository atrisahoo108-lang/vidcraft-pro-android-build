import React from 'react';

interface PremiumBadgeProps {
  /** Optional extra classes for spacing/alignment at the call site (e.g. "ml-1.5"). */
  className?: string;
}

/**
 * Small static "PRO" label used to proactively mark PRO-tier features next
 * to their existing controls, so a user can tell before trying a feature
 * that it's part of VidCraft Pro.
 *
 * Purely informational — it decides nothing:
 *  - Not a button: no onClick/href, not keyboard-focusable (plain <span>).
 *  - canUseFeature() remains the only source of truth for whether a
 *    feature actually runs; this badge renders identically for FREE and
 *    PRO users on purpose.
 *  - Communicates its meaning through visible "PRO" text, not color alone.
 */
export const PremiumBadge: React.FC<PremiumBadgeProps> = ({ className = '' }) => (
  <span
    title="Part of VidCraft Pro"
    className={`inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wide leading-none bg-amber-500/15 text-amber-400 border border-amber-500/40 select-none ${className}`}
  >
    PRO
  </span>
);
