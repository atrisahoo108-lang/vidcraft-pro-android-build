export type MediaType = 'video' | 'audio' | 'image' | 'text';

export type BlendMode = 
  | 'normal' 
  | 'screen' 
  | 'multiply' 
  | 'overlay' 
  | 'lighten' 
  | 'darken' 
  | 'color-dodge' 
  | 'difference';

export type TransitionType = 
  | 'none'
  | 'cross-dissolve' 
  | 'dip-to-black' 
  | 'dip-to-white' 
  | 'wipe-left' 
  | 'wipe-right' 
  | 'wipe-up'
  | 'wipe-down'
  | 'iris'
  | 'slide-left'
  | 'slide-right'
  | 'slide-up'
  | 'slide-down'
  | 'blur-dissolve'
  | 'zoom-in' 
  | 'glitch';

export interface Keyframe {
  id: string;
  time: number; // in seconds relative to clip start
  property: 'positionX' | 'positionY' | 'scale' | 'rotation' | 'opacity' | 'volume' | 'speed';
  value: number;
}

export interface LumetriGrade {
  temperature: number; // -100 to 100
  tint: number; // -100 to 100
  exposure: number; // -5 to +5
  contrast: number; // -100 to 100
  highlights: number; // -100 to 100
  shadows: number; // -100 to 100
  whites: number; // -100 to 100
  blacks: number; // -100 to 100
  saturation: number; // 0 to 200 (100 normal)
  vibrance: number; // -100 to 100
  vignette: number; // -100 to 100
  liftColor: string; // Shadow tint hex e.g. #000000
  gammaColor: string; // Midtone tint hex e.g. #808080
  gainColor: string; // Highlight tint hex e.g. #ffffff
  presetName?: string;
}

export interface VideoFilter {
  id: string;
  type: 'blur' | 'brightness' | 'contrast' | 'hue-rotate' | 'invert' | 'sepia' | 'grayscale' | 'chromatic' | 'glitch' | 'scanlines' | 'sharpen';
  name: string;
  enabled: boolean;
  value: number; // usually 0 - 100
}

export interface CaptionWord {
  text: string;
  start: number; // seconds, relative to clip start
  end: number;   // seconds, relative to clip start
}

export interface TextConfig {
  text: string;
  fontSize: number;
  fontFamily: string;
  color: string;
  backgroundColor?: string;
  strokeColor?: string;
  strokeWidth?: number;
  align: 'left' | 'center' | 'right';
  animation?: 'none' | 'typewriter' | 'fade' | 'slide-up' | 'slide-down' | 'slide-left' | 'slide-right' | 'glitch' | 'zoom-in' | 'bounce';
  shadowColor?: string;
  shadowBlur?: number;
  highlightWord?: string;
  highlightColor?: string;
  // Karaoke-style animated captions: each word lights up in highlightColor
  // during its own [start, end] window. When present, this takes over
  // rendering from the plain `text` + `highlightWord` fields.
  captionWords?: CaptionWord[];
}

export interface ClipMask {
  shape: 'rectangle' | 'ellipse';
  xPercent: number;      // 0-100, center X as % of frame width
  yPercent: number;      // 0-100, center Y as % of frame height
  widthPercent: number;  // 0-100, shape width as % of frame width
  heightPercent: number; // 0-100, shape height as % of frame height
  feather: number;       // px, edge softness
  invert: boolean;       // true = affect area OUTSIDE the shape instead of inside
  mode: 'crop' | 'blur'; // 'crop' = only the shape area is visible (rest transparent)
                          // 'blur' = only the shape area is blurred (rest stays sharp)
  blurAmount: number;    // px, used when mode === 'blur'
}

export interface AudioConfig {
  volume: number; // 0 to 2 (1 is 100%)
  pan: number; // -1 (Left) to +1 (Right)
  mute: boolean;
  bass?: number; // -20dB to +20dB
  treble?: number; // -20dB to +20dB
  speed?: number; // 0.5x to 2x
  fadeIn?: number; // seconds, clip-local — ramps in from silence at clip start
  fadeOut?: number; // seconds, clip-local — ramps out to silence at clip end
}

export interface Clip {
  id: string;
  assetId: string;
  trackId: string;
  type: MediaType;
  name: string;
  color?: string; // Timeline block tint color
  
  // Timeline timing (in seconds)
  startTime: number; // position on timeline
  duration: number;  // playback duration on timeline
  inPoint: number;   // source start offset
  outPoint: number;  // source end offset
  sourceDuration: number;

  // Visual Transforms
  positionX: number; // pixel offset from center
  positionY: number; // pixel offset from center
  scale: number;     // 100 = 100%
  rotation: number;  // degrees
  opacity: number;   // 0 - 100
  blendMode: BlendMode;

  // Effects & Color
  lumetri: LumetriGrade;
  filters: VideoFilter[];
  mask?: ClipMask;
  // Time remapping: 1 = normal speed. 0.5 = half-speed slow-mo, 2 = double
  // speed. Can be keyframed (property 'speed') for a classic speed RAMP —
  // e.g. 1 -> 0.2 -> 1 dips into slow-mo and back out mid-clip.
  speed?: number;
  // Freeze Frame: when true, this clip always displays its single inPoint
  // frame instead of playing through — split a clip with the razor tool at
  // the moment you want to hold, then flag the resulting piece as frozen and
  // stretch its duration to taste.
  freezeFrame?: boolean;
  transitionIn?: {
    type: TransitionType;
    duration: number; // in seconds
  };
  transitionOut?: {
    type: TransitionType;
    duration: number; // in seconds
  };

  // Specific Modalities
  textConfig?: TextConfig;
  audioConfig?: AudioConfig;
  keyframes?: Keyframe[];

  isLocked?: boolean;
  isMuted?: boolean;
}

export interface Track {
  id: string;
  name: string;
  type: 'video' | 'audio';
  index: number;
  isMuted: boolean;
  isSolo: boolean;
  isLocked: boolean;
  isVisible: boolean;
  volume: number; // 0 to 2 (1 = 0dB)
  pan: number;    // -1 to 1
  height: number; // pixel height in timeline
}

export interface MediaAsset {
  id: string;
  name: string;
  type: MediaType;
  src: string;
  duration: number; // in seconds
  width?: number;
  height?: number;
  thumbnailUrl?: string;
  waveformData?: number[];
  category?: string;
  fileSize?: string;

  // Offline project persistence (see src/utils/projectStorage.ts):
  // true for anything imported via the file picker, whose actual bytes are
  // cached in IndexedDB (keyed by this asset's id) so it survives a reload
  // without needing the internet or the file to be re-picked.
  isLocalFile?: boolean;
  // Set on load when a project file references a local asset whose bytes
  // weren't found in this browser's IndexedDB (e.g. project opened on a
  // different device). The UI should offer a "relink" action for these.
  isOfflineMissing?: boolean;
}

export interface TimelineMarker {
  id: string;
  time: number;
  label: string;
  color: string;
}

export interface ProjectSettings {
  name: string;
  width: number;
  height: number;
  fps: number;
  duration: number; // timeline total duration in seconds
  aspectRatio: '16:9' | '9:16' | '1:1' | '4:5' | '21:9';
  markers?: TimelineMarker[];
}

export type ToolMode = 
  | 'select'       // V
  | 'track-select' // A
  | 'ripple-edit'  // B
  | 'razor'        // C
  | 'slip'         // Y
  | 'pen'          // P
  | 'hand'         // H
  | 'text'         // T
  | 'ripple'
  | 'slide'
  | 'zoom';

export type ActiveTool = ToolMode;
export type WorkspaceType = 'editing' | 'color' | 'effects' | 'audio' | 'graphics' | 'export';
export type WorkspaceMode = WorkspaceType;
export type Marker = TimelineMarker;

export interface HistoryState {
  clips: Clip[];
  tracks: Track[];
  description: string;
  timestamp: number;
}
