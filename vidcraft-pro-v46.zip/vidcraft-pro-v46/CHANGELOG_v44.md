# VidCraft Pro — v44 Update: Android/Mobile Usability Refinement

Base: v43 (`vidcraft-pro-v43.zip`) — every file not listed below is
byte-for-byte unchanged from v43.

Scope, exactly as requested: touch target/spacing/scrolling/compact-layout
refinement for `ProjectMediaBin`, `EffectsLibrary`, `AudioMixerPanel`,
`ExportModal`, and the other dense desktop-sized panels, plus a further
performance/memory pass — nothing else. No AdMob, Play Billing,
subscriptions, Google Sign-In/Firebase, or any monetization/auth logic was
added or changed. v43's device-tier preview scaling, safe-area handling,
background auto-pause, and touch improvements were verified intact, not
regressed.

## Correction from the v43 report

The v43 changelog listed `ProjectMediaBin.tsx` as a "known follow-up" still
needing touch-target work. On closer inspection this turn, it actually
already had full `isMobile` support shipped in v43 — that line in the
previous changelog was a documentation mistake, not a functional gap. The
one real gap: `App.tsx` never actually passed `isMobile` to it, so that
existing mobile styling was dead code. Fixed below. Apologies for the
confusion this caused.

## Changed — `src/App.tsx`

- `isMobile` is now passed to all six workspace panels
  (`ProjectMediaBin`, `LumetriColorPanel`, `EffectsLibrary`,
  `EssentialGraphicsPanel`, `AudioMixerPanel`, `EffectControls`) and to
  `ExportModal` — previously only `HeaderMenuBar` and `Timeline` (from
  v43) received it.

## Changed — `src/components/ProjectMediaBin.tsx`

- No behavioral change. Relabeled a comment that incorrectly said "v44"
  for something already shipped in v43 (see correction above).

## Changed — `src/components/EffectsLibrary.tsx`

- Mobile tab bar (`Video Transitions` / `Video Filters & FX`) gets taller
  tap targets.
- Transition and filter cards stack into a column with a full-width Apply/
  Add button on mobile instead of a cramped side-by-side row.
- Applied-filter checkbox and slider are bigger on mobile.

## Changed — `src/components/AudioMixerPanel.tsx`

- Fader strips widen (96px → 112px) and the vertical volume slider gets a
  larger touch area on mobile; Mute/Solo buttons get real tap padding
  instead of a ~24×18px hitbox.
- **Performance**: the VU-meter poll was a fixed 50ms (20fps) regardless
  of device. It now throttles to 90ms (mid-tier) or 150ms (low-tier) using
  `deviceTier.ts` from v43 — one less thing competing with video
  compositing on the main thread of weaker Android hardware. High-end/
  desktop keeps the original 50ms.

## Changed — `src/components/ExportModal.tsx`

Layout-only. **Not touched**: the DEV/TEST license-tier switch, the 4K
Pro-gate messaging, `PremiumBadge`, or any of the actual export/encoding
logic (`exportVideo`, `pickVideoMimeType`, `driveTimelineTo`, etc.) —
verified by diff to be identical to v43.

- Modal now clamps to `max-h-[92vh]` with internal scrolling on mobile, so
  it can't run off the bottom of a short/landscape phone screen (v43's
  known gap, now fixed).
- Header/footer are taller with `.safe-top` / `.safe-bottom` padding;
  format/resolution/quality/fps dropdowns and all footer buttons (Cancel,
  Start Export, Download) get real touch padding.
- The Format/Resolution and Quality/Framerate option pairs stack to a
  single column on mobile instead of a tight 2-up grid.

## Changed — `src/components/EffectControls.tsx`, `LumetriColorPanel.tsx`, `EssentialGraphicsPanel.tsx`

- Added an `isMobile` prop to each (required once `App.tsx` started
  passing it — see above) and taller headers/sub-tabs on `LumetriColorPanel`
  and `EssentialGraphicsPanel` where mobile is active.
- **Not touched**: `LumetriColorPanel`'s and `EssentialGraphicsPanel`'s
  Pro-gated LUT/feature logic (`canUseFeature`, `PremiumBadge`, lock
  notices) — only header/tab layout classes were edited.
- These three panels between them have ~20 `<input type="range">`
  sliders (position/scale/rotation/opacity/mask/color-wheel/font-size,
  etc.). Rather than hand-editing every one, they're all covered by one
  new rule below.

## Changed — `src/index.css`

- New `@media (pointer: coarse)` rule enlarges every range-slider's thumb
  (`::-webkit-slider-thumb` / `::-moz-range-thumb`) to 20×20px app-wide.
  This can only match a touch-primary device, never a mouse/desktop
  session, so it's a zero-risk way to fix slider grabbability across every
  dense panel in the app (including the three above) without threading
  `isMobile` classes through dozens of individual sliders.

## Verified unchanged (regression check against v43)

- `capacitor.config.ts`, `deviceTier.ts`, `ProgramMonitor.tsx`'s
  device-tier preview cap, `Timeline.tsx`'s trim-handle/zoom sizing,
  `HeaderMenuBar.tsx`'s mobile toolbar and outside-tap-to-close, the
  `.safe-top`/`.safe-bottom`/`.safe-x` utilities, the global
  `overflow-y-auto`/`overflow-x-auto` momentum-scroll rule, and the
  background auto-pause effect in `App.tsx` — all diffed identical to v43,
  none regressed.
- `license.ts`, `licenseVerification.ts`, `payment.ts`,
  `paymentBackendContract.ts`, `premiumFeatures.ts`, `razorpayConfig.ts`,
  `watermark.ts`, `auth.ts`, `googleAuthAdapter.ts`, `firebaseConfig.ts`,
  `LicensePanel.tsx`, `PremiumBadge.tsx` — untouched (confirmed by diff:
  only the 9 files listed above changed between v43 and v44).

## Known follow-ups (not done in this pass)

- `ProjectMediaBin`'s list/grid view toggle, category filter dropdown, and
  drag-and-drop-to-timeline gesture haven't been tested on an actual
  low-end Android device yet — only reasoned about from code.
- No real-device profiling was possible in this sandbox (no Android
  hardware or emulator here); the device-tier thresholds in `deviceTier.ts`
  and the meter-throttle values above are informed estimates, worth
  revisiting once you can test on real low/mid-end hardware.
- `android/` native project generation still requires your own machine —
  unchanged from v43, see `MOBILE_BUILD.md`.
