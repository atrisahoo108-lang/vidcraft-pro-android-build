# APK বানানো — ধাপে ধাপে (Capacitor দিয়ে)

এই কাজটুকু তোমার নিজের কম্পিউটারে করতে হবে — এখানকার sandbox-এ ইন্টারনেট আর Android SDK
কোনোটাই নেই, তাই আমি config ফাইলগুলো বানিয়ে দিয়েছি, বাকি কমান্ডগুলো তোমাকে চালাতে হবে।

## যা আগে থেকে লাগবে (একবার ইনস্টল করলেই হবে)
1. **Node.js** (v18+) — [nodejs.org](https://nodejs.org) থেকে
2. **Android Studio** — [developer.android.com/studio](https://developer.android.com/studio) থেকে
   (এটার সাথেই Android SDK, emulator সব চলে আসবে)
3. **Java JDK 17** — সাধারণত Android Studio-এর সাথেই বান্ডল থাকে, আলাদা করে লাগে না

## ধাপ ১ — Dependencies ইনস্টল
প্রজেক্ট ফোল্ডারে টার্মিনাল খুলে:
```bash
npm install
```
এতে `@capacitor/core`, `@capacitor/cli`, `@capacitor/android` — এই তিনটাও ইনস্টল হয়ে যাবে
(package.json-এ যোগ করে দিয়েছি)।

## ধাপ ২ — Android প্ল্যাটফর্ম যোগ করা (শুধু প্রথমবার)
```bash
npm run cap:add:android
```
এটা একটা নতুন `android/` ফোল্ডার বানাবে — এটাই আসল নেটিভ Android প্রজেক্ট।

## ধাপ ৩ — ওয়েব কোড বিল্ড করে Android প্রজেক্টে সিঙ্ক করা
```bash
npm run cap:sync
```
এটা `vite build` চালিয়ে `dist/` বানাবে, তারপর সেটা `android/` প্রজেক্টের ভেতরে কপি করে দেবে।
**যখনই তুমি কোড বদলাবে, এই কমান্ডটা আবার চালাতে হবে।**

## ধাপ ৪ — Android Studio-তে খোলা
```bash
npm run cap:open:android
```
এটা সরাসরি Android Studio খুলে দেবে তোমার প্রজেক্ট নিয়ে। প্রথমবার Gradle sync হতে কিছুক্ষণ
সময় লাগবে (ইন্টারনেট লাগবে, Android Studio নিজে থেকেই dependency নামাবে) — ধৈর্য ধরে অপেক্ষা করো।

## ধাপ ৫ — APK বানানো
Android Studio-র ভেতরে:
- মেনু থেকে **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- বিল্ড শেষ হলে নিচে একটা নোটিফিকেশনে "locate" লিংক আসবে — ওখানে ক্লিক করলে APK ফাইলটা
  পাবে (`android/app/build/outputs/apk/debug/app-debug.apk`)
- এই APK ফোনে কপি করে ইনস্টল করা যাবে (ফোনে "Unknown sources" থেকে ইনস্টল অনুমতি দিতে হতে পারে)

## টেস্ট করার সহজ উপায় (APK ছাড়াই)
Android Studio-তে একটা **Emulator** চালিয়ে সরাসরি Run বাটনে চাপলেই অ্যাপটা এমুলেটরে চলবে —
প্রতিবার APK বিল্ড না করেই দ্রুত টেস্ট করা যায়।

## AI ফিচার নিয়ে মনে রাখার কথা
`server.ts` (AI ফিচারের ব্যাকএন্ড) মোবাইল অ্যাপের ভেতরে থাকবে না। AI ফিচার কাজ করাতে হলে:
1. `server.ts`-টা কোথাও হোস্ট করো (Render/Railway ইত্যাদি — ফ্রি টিয়ার আছে)
2. `.env` ফাইলে `VITE_API_BASE_URL="https://তোমার-সার্ভার-ইউআরএল"` বসাও
3. `npm run cap:sync` আবার চালাও

AI ছাড়াই বাকি সব ফিচার (এডিটিং, এক্সপোর্ট, টাইমলাইন) স্বাভাবিকভাবেই চলবে।

## v43 আপডেট — যা নতুন যোগ হয়েছে
এই ধাপগুলো (উপরে) অপরিবর্তিত আছে — v43-এও ঠিক একই কমান্ড দিয়ে APK বানাতে হবে।
নতুন যা যোগ হয়েছে শুধু **web কোডের ভেতরে** (responsive layout, touch handling,
safe-area, low-end ডিভাইসের জন্য preview resolution কমানো, background-এ গেলে
playback অটো-পজ) — কোনো নতুন নেটিভ প্লাগিন বা `android/` ফোল্ডার পরিবর্তন লাগেনি,
তাই বিল্ড প্রসেস একই থাকছে।

### Edge-to-edge (status bar/notch-এর নিচে UI না লুকানো) — ঐচ্ছিক, একবারের কাজ
`npm run cap:add:android` চালানোর পর, Android 15-এর নিচের ভার্সনে সত্যিকারের
edge-to-edge পেতে (তাতে `safe-top`/`safe-bottom` CSS আসল মান পায়) একটা লাইন
native কোডে যোগ করতে হবে — বিস্তারিত `capacitor.config.ts`-এর কমেন্টে আছে।
এটা বাদ দিলেও অ্যাপ সঠিকভাবেই চলবে, শুধু safe-area padding তখন 0px থাকবে
(v42-এ যেমন ছিল)।

### এই sandbox-এ যা করা যায়নি (আগের মতোই)
এখানে ইন্টারনেট ও Android SDK কোনোটাই নেই, তাই `android/` নেটিভ প্রজেক্ট
জেনারেট করা (ধাপ ২), Gradle sync, বা আসল APK বিল্ড — এসব তোমার নিজের
কম্পিউটারে করতে হবে, ঠিক উপরের ধাপগুলো অনুসরণ করে। বাকি সবকিছু —
Capacitor config, responsive UI, touch/performance অপ্টিমাইজেশন — কোডে
প্রস্তুত করে দেওয়া আছে।

## v45 আপডেট — Native foundation hardening

### App icon ও Splash screen
এখনো real app icon/splash যোগ করা হয়নি — `assets/` ফোল্ডার খালি। এগুলো
বানাতে `@capacitor/assets` টুল লাগে (একটা সোর্স আইকন/স্প্ল্যাশ ছবি থেকে
সব Android density-র জন্য mipmap রিসোর্স অটো-জেনারেট করে), যেটা চালাতে
ইন্টারনেট লাগবে — এই sandbox-এ নেই। তোমার কম্পিউটারে, একটা 1024×1024
আইকন PNG (`assets/icon.png`) আর একটা splash PNG বানিয়ে রাখলে:
```
npm install --save-dev @capacitor/assets
npx @capacitor/assets generate --android
npm run cap:sync
```
এটা `android/app/src/main/res/`-এ সব mipmap/drawable resource বানিয়ে দেবে।
এটা না করলে অ্যাপ ডিফল্ট Capacitor আইকন নিয়েই চলবে — build ভাঙবে না।

### Back button
Export/Shortcuts/Project-manager মডাল খোলা থাকা অবস্থায় হার্ডওয়্যার/জেসচার
back চাপলে এখন থেকে পুরো অ্যাপ থেকে বেরিয়ে না গিয়ে শুধু মডালটা বন্ধ হবে
(`src/App.tsx`-এ plain History API দিয়ে করা — নতুন কোনো native প্লাগিন
লাগেনি)। **এটা real ডিভাইসে টেস্ট করা যায়নি** — Capacitor-এর ডকুমেন্টেড
ডিফল্ট আচরণের উপর ভিত্তি করে লেখা, তোমার ফোনে একবার যাচাই করে নিও।

### Orientation, largeHeap, permissions checklist
`android/` জেনারেট করার পর ঠিক কী কী চেক/যোগ করতে হবে তার একটা ছোট
checklist `capacitor.config.ts`-এর একদম শেষের কমেন্টে লেখা আছে —
portrait+landscape দুটোই যেন চালু থাকে, low-end ডিভাইসে export/preview-এর
মেমোরির জন্য `largeHeap`, আর কোন permission লাগবে না তার নিশ্চয়তা।

### এই sandbox-এ যা verify করা যায়নি
নেটওয়ার্ক বা Android SDK/emulator কোনোটাই না থাকায় — `android/` প্রজেক্ট
জেনারেট করা, `npm install` (নতুন কোনো ডিপেন্ডেন্সি লাগলে), আসল Gradle
build, বা ফোনে ইনস্টল করে হাতে-কলমে টেস্ট (back button, keyboard, rotation,
splash/icon চেহারা) — এর কোনোটাই আমি এখানে চালিয়ে দেখতে পারিনি। যা যা
কোডে/কনফিগে প্রস্তুত করা হয়েছে তা যুক্তিসঙ্গত ও ডকুমেন্টেড ধরে নেওয়া হলেও,
তোমার নিজের ডিভাইসে একবার চালিয়ে দেখাটাই একমাত্র আসল নিশ্চয়তা।

## যদি কোনো ধাপে আটকে যাও
Gradle build error, "SDK not found", signing/keystore নিয়ে প্রশ্ন — যেটাই হোক, error message-টা
কপি করে আমাকে দিও, একসাথে বসে ঠিক করে ফেলব। তাড়াহুড়ো নেই 😊

